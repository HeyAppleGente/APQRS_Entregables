-- ============================================================
-- MIGRACIÓN: agrega tipo_ocupante y fecha_registro a Usuario
-- Ejecuta este script SOLO si tu base de datos "mydb" ya existía
-- (creada con una versión anterior de BD.sql) y no quieres
-- borrarla. Si vas a correr BD.sql desde cero, NO necesitas esto,
-- porque BD.sql ya incluye estas columnas.
-- ============================================================

USE mydb;

ALTER TABLE Usuario
  ADD COLUMN tipo_ocupante VARCHAR(20) NOT NULL DEFAULT 'Propietario' AFTER NOTIFICACIONES_id_notificaciones,
  ADD COLUMN fecha_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER tipo_ocupante;

-- Opcional: si quieres que tus usuarios de prueba se vean variados
-- como en la demo, puedes ajustar algunos manualmente, por ejemplo:
-- UPDATE Usuario SET tipo_ocupante = 'Arrendatario' WHERE idUsuario IN (3, 6);
