-- ============================================================
-- MIGRACIÓN: plazos de atención (SLA) por tipo de PQRS
-- ============================================================
-- Ejecuta este script SOLO si tu base de datos "mydb" ya existía.
-- Si vas a correr BD.sql desde cero, NO lo necesitas.
--
-- Agrega cuántos días hábiles tiene administración para responder cada
-- tipo de PQRS (por defecto 15, el estándar usado comúnmente en Colombia
-- para peticiones, quejas y reclamos). Se puede ajustar por tipo desde
-- "Configurar Plazos" en el panel de administración.
-- ============================================================

USE mydb;

ALTER TABLE TipoPqrs
  ADD COLUMN dias_plazo INT NOT NULL DEFAULT 15;
