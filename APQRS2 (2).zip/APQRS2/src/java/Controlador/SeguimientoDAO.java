package Controlador;

import Modelo.Seguimiento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SeguimientoDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Seguimiento seguimiento) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO Seguimiento (comentario, fecha_registro, Citas_id_citas, Usuario_idUsuario, PQRS_id_pqrs) "
                    + "VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, seguimiento.getComentario());
            ps.setTimestamp(2, seguimiento.getFechaRegistro());
            ps.setInt(3, seguimiento.getIdCitas());
            ps.setInt(4, seguimiento.getIdUsuario());
            ps.setInt(5, seguimiento.getIdPqrs());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Seguimiento consultar(int idSeguimiento) {
        Connection conn = conect.getconn();
        Seguimiento seguimiento = null;
        try {
            String sql = "SELECT id_seguimiento, comentario, fecha_registro, Citas_id_citas, Usuario_idUsuario, PQRS_id_pqrs "
                    + "FROM Seguimiento WHERE id_seguimiento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idSeguimiento);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                seguimiento = mapear(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return seguimiento;
    }

    public boolean actualizar(Seguimiento seguimiento) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Seguimiento SET comentario = ?, fecha_registro = ?, Citas_id_citas = ?, Usuario_idUsuario = ?, "
                    + "PQRS_id_pqrs = ? WHERE id_seguimiento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, seguimiento.getComentario());
            ps.setTimestamp(2, seguimiento.getFechaRegistro());
            ps.setInt(3, seguimiento.getIdCitas());
            ps.setInt(4, seguimiento.getIdUsuario());
            ps.setInt(5, seguimiento.getIdPqrs());
            ps.setInt(6, seguimiento.getIdSeguimiento());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idSeguimiento) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM Seguimiento WHERE id_seguimiento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idSeguimiento);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /**
     * Historial de seguimiento (bitácora) de una cita específica: incluye tanto
     * el agendamiento como cualquier nota posterior (confirmaciones, cambios).
     */
    public List<Seguimiento> listarPorCitas(int idCitas) {
        Connection conn = conect.getconn();
        List<Seguimiento> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_seguimiento, comentario, fecha_registro, Citas_id_citas, Usuario_idUsuario, PQRS_id_pqrs "
                    + "FROM Seguimiento WHERE Citas_id_citas = ? ORDER BY fecha_registro ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCitas);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Seguimiento> listarTodos() {
        Connection conn = conect.getconn();
        List<Seguimiento> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_seguimiento, comentario, fecha_registro, Citas_id_citas, Usuario_idUsuario, PQRS_id_pqrs FROM Seguimiento ORDER BY fecha_registro ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * Historial de seguimiento (bitácora) de una PQRS específica: cada vez que
     * se agenda una cita para atenderla o se le da respuesta, queda un registro
     * aquí, para poder ver la trazabilidad completa.
     */
    public List<Seguimiento> listarPorPqrs(int idPqrs) {
        Connection conn = conect.getconn();
        List<Seguimiento> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_seguimiento, comentario, fecha_registro, Citas_id_citas, Usuario_idUsuario, PQRS_id_pqrs "
                    + "FROM Seguimiento WHERE PQRS_id_pqrs = ? ORDER BY fecha_registro ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idPqrs);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Seguimiento mapear(ResultSet rs) throws SQLException {
        Seguimiento seguimiento = new Seguimiento();
        seguimiento.setIdSeguimiento(rs.getInt("id_seguimiento"));
        seguimiento.setComentario(rs.getString("comentario"));
        seguimiento.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        seguimiento.setIdCitas(rs.getInt("Citas_id_citas"));
        seguimiento.setIdUsuario(rs.getInt("Usuario_idUsuario"));
        seguimiento.setIdPqrs(rs.getInt("PQRS_id_pqrs"));
        return seguimiento;
    }
}
