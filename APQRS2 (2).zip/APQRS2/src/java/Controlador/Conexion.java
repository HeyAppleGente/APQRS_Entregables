package Controlador;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * Proveedor de conexiones a la base de datos.
 *
 * Las credenciales YA NO están escritas en este archivo: se leen de
 * db.properties (ver ese archivo, ubicado junto a este paquete). Así el
 * usuario/contraseña de la base de datos se pueden cambiar sin tener que
 * volver a compilar el proyecto, y no quedan expuestos dentro del código
 * fuente ni del .class compilado.
 *
 * IMPORTANTE — por qué existe el pool de conexiones:
 * Ninguno de los DAO de este proyecto llama a Connection.close() después de
 * usar la conexión (se revisó: cero llamadas a close() en todo Controlador/).
 * Antes, cada getconn() abría una conexión física nueva a MySQL que quedaba
 * abierta para siempre. Después de suficientes clics en la aplicación, se
 * agotaba el límite de conexiones de MySQL y todo empezaba a fallar con error
 * 500 hasta reiniciar el servidor.
 *
 * Esta clase soluciona el problema en un solo lugar, sin tener que modificar
 * los ~97 lugares que llaman a conect.getconn():
 *   1. Mantiene un pool fijo de conexiones reales, reutilizables.
 *   2. Envuelve cada conexión entregada en un proxy: si algún código SÍ llama
 *      a close(), la conexión regresa al pool en vez de cerrarse de verdad.
 *   3. Un hilo en segundo plano reclama automáticamente las conexiones que
 *      quedaron "prestadas" más tiempo del razonable (porque nadie las cerró),
 *      devolviéndolas al pool para que no se agoten.
 */
public class Conexion {

    private static final String URL;
    private static final String USER;
    private static final String PASSWORD;

    static {
        Properties props = new Properties();
        String url = "jdbc:mysql://localhost:3307/mydb?useSSL=false&serverTimezone=UTC";
        String user = "root";
        String password = "";
        try (InputStream in = Conexion.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) {
                props.load(in);
                url = props.getProperty("db.url", url);
                user = props.getProperty("db.user", user);
                password = props.getProperty("db.password", password);
            } else {
                System.err.println("Conexion: no se encontró db.properties en el classpath; "
                        + "usando valores por defecto (localhost:3307/mydb, root sin contraseña).");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        URL = url;
        USER = user;
        PASSWORD = password;
    }

    private static final int TAMANO_POOL = 20;
    private static final long TIEMPO_MAX_PRESTADA_MS = 20_000; // recicla conexiones "olvidadas" tras 20s

    private static final Deque<Connection> disponibles = new ArrayDeque<>();
    private static final Map<Connection, Long> prestadas = new HashMap<>();
    private static final Object lock = new Object();
    private static boolean inicializado = false;

    private static void inicializarPool() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < TAMANO_POOL; i++) {
            Connection c = crearConexionFisica();
            if (c != null) {
                disponibles.add(c);
            }
        }
        inicializado = true;
        iniciarReaper();
    }

    private static void iniciarReaper() {
        Thread reaper = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException ignored) {
                    return;
                }
                synchronized (lock) {
                    long ahora = System.currentTimeMillis();
                    prestadas.entrySet().removeIf(entry -> {
                        if (ahora - entry.getValue() <= TIEMPO_MAX_PRESTADA_MS) {
                            return false;
                        }
                        Connection real = entry.getKey();
                        try {
                            if (!real.isClosed()) {
                                disponibles.add(real);
                            } else {
                                agregarRespaldoSiHayEspacio();
                            }
                        } catch (SQLException e) {
                            agregarRespaldoSiHayEspacio();
                        }
                        return true;
                    });
                }
            }
        }, "pool-conexiones-reaper");
        reaper.setDaemon(true);
        reaper.start();
    }

    private static void agregarRespaldoSiHayEspacio() {
        if (disponibles.size() + prestadas.size() < TAMANO_POOL) {
            Connection nueva = crearConexionFisica();
            if (nueva != null) {
                disponibles.add(nueva);
            }
        }
    }

    private static Connection crearConexionFisica() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Connection getconn() {
        synchronized (lock) {
            if (!inicializado) {
                inicializarPool();
            }
            Connection real = disponibles.pollFirst();
            try {
                if (real == null || real.isClosed() || !real.isValid(2)) {
                    real = crearConexionFisica();
                }
            } catch (SQLException e) {
                real = crearConexionFisica();
            }
            if (real == null) {
                return null;
            }
            prestadas.put(real, System.currentTimeMillis());
            return envolverConProxy(real);
        }
    }

    /**
     * Envuelve la conexión real en un proxy transparente: se comporta igual a
     * una Connection normal, excepto que close() la regresa al pool en vez de
     * cerrarla de verdad.
     */
    private Connection envolverConProxy(final Connection real) {
        InvocationHandler handler = (Object proxy, Method method, Object[] args) -> {
            if ("close".equals(method.getName())) {
                synchronized (lock) {
                    prestadas.remove(real);
                    try {
                        if (!real.isClosed()) {
                            disponibles.add(real);
                        }
                    } catch (SQLException e) {
                        // conexión dañada: simplemente no se reintegra al pool
                    }
                }
                return null;
            }
            try {
                return method.invoke(real, args);
            } catch (InvocationTargetException e) {
                throw e.getCause() != null ? e.getCause() : e;
            }
        };
        return (Connection) Proxy.newProxyInstance(
                Connection.class.getClassLoader(),
                new Class[]{Connection.class},
                handler);
    }
}
