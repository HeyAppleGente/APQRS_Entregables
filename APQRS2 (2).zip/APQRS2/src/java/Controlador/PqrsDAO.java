package Controlador;

import Modelo.Pqrs;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PqrsDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Pqrs pqrs) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO PQRS (asunto, descripcion, respuesta, fecha_registro, fecha_respuesta, "
                    + "TipoPqrs_id_tipo_pqrs, Usuario_idUsuario) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, pqrs.getAsunto());
            ps.setString(2, pqrs.getDescripcion());
            ps.setString(3, pqrs.getRespuesta());
            ps.setTimestamp(4, pqrs.getFechaRegistro());
            ps.setTimestamp(5, pqrs.getFechaRespuesta());
            ps.setInt(6, pqrs.getIdTipoPqrs());
            ps.setInt(7, pqrs.getIdUsuario());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Pqrs consultar(int idPqrs) {
        Connection conn = conect.getconn();
        Pqrs pqrs = null;
        try {
            String sql = "SELECT id_pqrs, asunto, descripcion, respuesta, fecha_registro, fecha_respuesta, "
                    + "TipoPqrs_id_tipo_pqrs, Usuario_idUsuario FROM PQRS WHERE id_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idPqrs);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                pqrs = mapear(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pqrs;
    }

    public boolean actualizar(Pqrs pqrs) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE PQRS SET asunto = ?, descripcion = ?, respuesta = ?, fecha_registro = ?, fecha_respuesta = ?, "
                    + "TipoPqrs_id_tipo_pqrs = ?, Usuario_idUsuario = ? WHERE id_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, pqrs.getAsunto());
            ps.setString(2, pqrs.getDescripcion());
            ps.setString(3, pqrs.getRespuesta());
            ps.setTimestamp(4, pqrs.getFechaRegistro());
            ps.setTimestamp(5, pqrs.getFechaRespuesta());
            ps.setInt(6, pqrs.getIdTipoPqrs());
            ps.setInt(7, pqrs.getIdUsuario());
            ps.setInt(8, pqrs.getIdPqrs());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idPqrs) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM PQRS WHERE id_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idPqrs);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Pqrs> listarTodos() {
        Connection conn = conect.getconn();
        List<Pqrs> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_pqrs, asunto, descripcion, respuesta, fecha_registro, fecha_respuesta, "
                    + "TipoPqrs_id_tipo_pqrs, Usuario_idUsuario FROM PQRS";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Pqrs> listarPorUsuario(int idUsuario) {
        Connection conn = conect.getconn();
        List<Pqrs> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_pqrs, asunto, descripcion, respuesta, fecha_registro, fecha_respuesta, "
                    + "TipoPqrs_id_tipo_pqrs, Usuario_idUsuario FROM PQRS WHERE Usuario_idUsuario = ? "
                    + "ORDER BY fecha_registro DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public boolean responder(int idPqrs, String respuesta) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE PQRS SET respuesta = ?, fecha_respuesta = ? WHERE id_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, respuesta);
            ps.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
            ps.setInt(3, idPqrs);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    private Pqrs mapear(ResultSet rs) throws SQLException {
        Pqrs pqrs = new Pqrs();
        pqrs.setIdPqrs(rs.getInt("id_pqrs"));
        pqrs.setAsunto(rs.getString("asunto"));
        pqrs.setDescripcion(rs.getString("descripcion"));
        pqrs.setRespuesta(rs.getString("respuesta"));
        pqrs.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        pqrs.setFechaRespuesta(rs.getTimestamp("fecha_respuesta"));
        pqrs.setIdTipoPqrs(rs.getInt("TipoPqrs_id_tipo_pqrs"));
        pqrs.setIdUsuario(rs.getInt("Usuario_idUsuario"));
        return pqrs;
    }
}
