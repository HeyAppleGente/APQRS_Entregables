package Controlador;

import Modelo.Apartamento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ApartamentoDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Apartamento apartamento) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO Apartamento (numero, Bloque_id_bloque) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, apartamento.getNumero());
            ps.setInt(2, apartamento.getIdBloque());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Apartamento consultar(int idApartamento) {
        Connection conn = conect.getconn();
        Apartamento apartamento = null;
        try {
            String sql = "SELECT id_apartamento, numero, Bloque_id_bloque FROM Apartamento WHERE id_apartamento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idApartamento);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                apartamento = new Apartamento();
                apartamento.setIdApartamento(rs.getInt("id_apartamento"));
                apartamento.setNumero(rs.getString("numero"));
                apartamento.setIdBloque(rs.getInt("Bloque_id_bloque"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return apartamento;
    }

    public boolean actualizar(Apartamento apartamento) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Apartamento SET numero = ?, Bloque_id_bloque = ? WHERE id_apartamento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, apartamento.getNumero());
            ps.setInt(2, apartamento.getIdBloque());
            ps.setInt(3, apartamento.getIdApartamento());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idApartamento) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM Apartamento WHERE id_apartamento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idApartamento);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Apartamento> listarTodos() {
        Connection conn = conect.getconn();
        List<Apartamento> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_apartamento, numero, Bloque_id_bloque FROM Apartamento";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Apartamento apartamento = new Apartamento();
                apartamento.setIdApartamento(rs.getInt("id_apartamento"));
                apartamento.setNumero(rs.getString("numero"));
                apartamento.setIdBloque(rs.getInt("Bloque_id_bloque"));
                lista.add(apartamento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Apartamento consultarPorNumeroYBloque(String numero, int idBloque) {
        Connection conn = conect.getconn();
        Apartamento apartamento = null;
        try {
            String sql = "SELECT id_apartamento, numero, Bloque_id_bloque FROM Apartamento WHERE numero = ? AND Bloque_id_bloque = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, numero);
            ps.setInt(2, idBloque);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                apartamento = new Apartamento();
                apartamento.setIdApartamento(rs.getInt("id_apartamento"));
                apartamento.setNumero(rs.getString("numero"));
                apartamento.setIdBloque(rs.getInt("Bloque_id_bloque"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return apartamento;
    }

    /**
     * Busca un apartamento por número dentro de una torre/bloque; si no existe
     * todavía, lo crea. Complementa a BloqueDAO.buscarOcrear para poder dar de
     * alta residentes en unidades nuevas sin tener que precargarlas antes.
     */
    public int buscarOcrear(String numero, int idBloque) {
        Apartamento existente = consultarPorNumeroYBloque(numero, idBloque);
        if (existente != null) {
            return existente.getIdApartamento();
        }
        Connection conn = conect.getconn();
        try {
            String sql = "INSERT INTO Apartamento (numero, Bloque_id_bloque) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, numero);
            ps.setInt(2, idBloque);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                return keys.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
