package Controlador;

import Modelo.TipoPqrs;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoPqrsDAO {

    // OJO: la columna en la BD se llama " nombre_tipo_pqrs" (con espacio inicial).
    // Se usa entre backticks tal cual está definida en el esquema.
    private static final String COLUMNAS = "id_tipo_pqrs, ` nombre_tipo_pqrs`, dias_plazo";

    private Conexion conect = new Conexion();

    public boolean insertar(TipoPqrs tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO TipoPqrs (` nombre_tipo_pqrs`, dias_plazo) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombreTipoPqrs());
            ps.setInt(2, tipo.getDiasPlazo() > 0 ? tipo.getDiasPlazo() : 15);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public TipoPqrs consultar(int idTipoPqrs) {
        Connection conn = conect.getconn();
        TipoPqrs tipo = null;
        try {
            String sql = "SELECT " + COLUMNAS + " FROM TipoPqrs WHERE id_tipo_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoPqrs);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                tipo = mapear(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tipo;
    }

    public boolean actualizar(TipoPqrs tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE TipoPqrs SET ` nombre_tipo_pqrs` = ?, dias_plazo = ? WHERE id_tipo_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombreTipoPqrs());
            ps.setInt(2, tipo.getDiasPlazo());
            ps.setInt(3, tipo.getIdTipoPqrs());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /** Actualiza solo el plazo (días hábiles) de un tipo, sin tocar su nombre. */
    public boolean actualizarPlazo(int idTipoPqrs, int diasPlazo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE TipoPqrs SET dias_plazo = ? WHERE id_tipo_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, diasPlazo);
            ps.setInt(2, idTipoPqrs);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idTipoPqrs) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM TipoPqrs WHERE id_tipo_pqrs = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoPqrs);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<TipoPqrs> listarTodos() {
        Connection conn = conect.getconn();
        List<TipoPqrs> lista = new ArrayList<>();
        try {
            String sql = "SELECT " + COLUMNAS + " FROM TipoPqrs";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private TipoPqrs mapear(ResultSet rs) throws SQLException {
        TipoPqrs tipo = new TipoPqrs();
        tipo.setIdTipoPqrs(rs.getInt("id_tipo_pqrs"));
        tipo.setNombreTipoPqrs(rs.getString(" nombre_tipo_pqrs"));
        tipo.setDiasPlazo(rs.getInt("dias_plazo"));
        return tipo;
    }
}
