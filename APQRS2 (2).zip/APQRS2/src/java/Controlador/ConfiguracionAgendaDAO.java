package Controlador;

import Modelo.ConfiguracionAgenda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Maneja la configuración de disponibilidad del administrador para agendar
 * citas (horario de atención, duración de cada cupo, días laborales). Es un
 * único registro global (id_configuracion = 1).
 */
public class ConfiguracionAgendaDAO {

    private Conexion conect = new Conexion();

    public ConfiguracionAgenda obtener() {
        Connection conn = conect.getconn();
        ConfiguracionAgenda config = null;
        try {
            String sql = "SELECT id_configuracion, hora_inicio, hora_fin, duracion_slot_minutos, dias_laborales "
                    + "FROM ConfiguracionAgenda WHERE id_configuracion = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                config = new ConfiguracionAgenda();
                config.setIdConfiguracion(rs.getInt("id_configuracion"));
                config.setHoraInicio(rs.getTime("hora_inicio"));
                config.setHoraFin(rs.getTime("hora_fin"));
                config.setDuracionSlotMinutos(rs.getInt("duracion_slot_minutos"));
                config.setDiasLaborales(rs.getString("dias_laborales"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // Si por alguna razón no existe el registro (BD antigua sin migrar aún),
        // se devuelve un valor por defecto razonable para que la app no se caiga.
        if (config == null) {
            config = new ConfiguracionAgenda();
            config.setIdConfiguracion(1);
            config.setHoraInicio(java.sql.Time.valueOf("08:00:00"));
            config.setHoraFin(java.sql.Time.valueOf("17:00:00"));
            config.setDuracionSlotMinutos(30);
            config.setDiasLaborales("1,2,3,4,5,6");
        }
        return config;
    }

    public boolean actualizar(ConfiguracionAgenda config) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE ConfiguracionAgenda SET hora_inicio = ?, hora_fin = ?, duracion_slot_minutos = ?, "
                    + "dias_laborales = ? WHERE id_configuracion = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setTime(1, config.getHoraInicio());
            ps.setTime(2, config.getHoraFin());
            ps.setInt(3, config.getDuracionSlotMinutos());
            ps.setString(4, config.getDiasLaborales());
            exito = ps.executeUpdate() > 0;
            if (exito) {
                return true;
            }
            // Si no existía el registro todavía (BD recién migrada), se crea.
            String sqlInsert = "INSERT INTO ConfiguracionAgenda (id_configuracion, hora_inicio, hora_fin, "
                    + "duracion_slot_minutos, dias_laborales) VALUES (1, ?, ?, ?, ?)";
            PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
            psInsert.setTime(1, config.getHoraInicio());
            psInsert.setTime(2, config.getHoraFin());
            psInsert.setInt(3, config.getDuracionSlotMinutos());
            psInsert.setString(4, config.getDiasLaborales());
            exito = psInsert.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }
}
