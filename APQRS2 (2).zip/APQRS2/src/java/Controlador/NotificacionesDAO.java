package Controlador;

import Modelo.Notificaciones;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class NotificacionesDAO {

    private static final String COLUMNAS = "id_notificaciones, titulo, mensaje, leido, fecha_envio, Citas_id_citas, "
            + "TIPONOTIFICACION_id_tipo_notificacion, PQRS_id_pqrs, Usuario_idUsuario";

    private Conexion conect = new Conexion();

    public boolean insertar(Notificaciones noti) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO NOTIFICACIONES (titulo, mensaje, leido, fecha_envio, Citas_id_citas, "
                    + "TIPONOTIFICACION_id_tipo_notificacion, PQRS_id_pqrs, Usuario_idUsuario) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, noti.getTitulo());
            ps.setString(2, noti.getMensaje());
            ps.setBoolean(3, noti.isLeido());
            ps.setTimestamp(4, noti.getFechaEnvio());
            setNullableInt(ps, 5, noti.getIdCitas());
            ps.setInt(6, noti.getIdTipoNotificacion());
            setNullableInt(ps, 7, noti.getIdPqrs());
            setNullableInt(ps, 8, noti.getIdUsuario());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean marcarLeida(int idNotificaciones) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE NOTIFICACIONES SET leido = 1 WHERE id_notificaciones = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idNotificaciones);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /**
     * Marca como leídas todas las notificaciones dirigidas a administradores
     * (Usuario_idUsuario es NULL = para todos los admins) o a un usuario puntual.
     */
    public boolean marcarTodasLeidasParaAdmin() {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE NOTIFICACIONES SET leido = 1 WHERE Usuario_idUsuario IS NULL AND leido = 0";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.executeUpdate();
            exito = true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /**
     * Últimas notificaciones para el administrador (las globales, sin usuario
     * puntual asignado), más recientes primero.
     */
    public List<Notificaciones> listarParaAdmin(int limite) {
        Connection conn = conect.getconn();
        List<Notificaciones> lista = new ArrayList<>();
        try {
            String sql = "SELECT " + COLUMNAS + " FROM NOTIFICACIONES WHERE Usuario_idUsuario IS NULL "
                    + "ORDER BY fecha_envio DESC LIMIT ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, limite);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public int contarNoLeidasParaAdmin() {
        Connection conn = conect.getconn();
        int total = 0;
        try {
            String sql = "SELECT COUNT(*) AS total FROM NOTIFICACIONES WHERE Usuario_idUsuario IS NULL AND leido = 0";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                total = rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }

    /** Atajo para crear una notificación global (visible a los administradores). */
    public boolean crear(String titulo, String mensaje, int idTipoNotificacion, Integer idCitas, Integer idPqrs) {
        Notificaciones noti = new Notificaciones();
        noti.setTitulo(titulo);
        noti.setMensaje(mensaje);
        noti.setLeido(false);
        noti.setFechaEnvio(new java.sql.Timestamp(System.currentTimeMillis()));
        noti.setIdTipoNotificacion(idTipoNotificacion);
        noti.setIdCitas(idCitas);
        noti.setIdPqrs(idPqrs);
        noti.setIdUsuario(null); // global para administradores
        return insertar(noti);
    }

    private void setNullableInt(PreparedStatement ps, int index, Integer valor) throws SQLException {
        if (valor != null && valor > 0) {
            ps.setInt(index, valor);
        } else {
            ps.setNull(index, Types.INTEGER);
        }
    }

    private Notificaciones mapear(ResultSet rs) throws SQLException {
        Notificaciones noti = new Notificaciones();
        noti.setIdNotificaciones(rs.getInt("id_notificaciones"));
        noti.setTitulo(rs.getString("titulo"));
        noti.setMensaje(rs.getString("mensaje"));
        noti.setLeido(rs.getBoolean("leido"));
        noti.setFechaEnvio(rs.getTimestamp("fecha_envio"));
        int idCitas = rs.getInt("Citas_id_citas");
        noti.setIdCitas(rs.wasNull() ? null : idCitas);
        noti.setIdTipoNotificacion(rs.getInt("TIPONOTIFICACION_id_tipo_notificacion"));
        int idPqrs = rs.getInt("PQRS_id_pqrs");
        noti.setIdPqrs(rs.wasNull() ? null : idPqrs);
        int idUsuario = rs.getInt("Usuario_idUsuario");
        noti.setIdUsuario(rs.wasNull() ? null : idUsuario);
        return noti;
    }

    public Notificaciones consultar(int busqueda) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean actualizar(Notificaciones notificaciones) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public boolean eliminar(int busqueda) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Notificaciones> listarTodos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
