package Controlador;

import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Usuario usuario) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO Usuario (nombre, apellido, documento, telefono, correo, contrasena, Rol_idRol, "
                    + "Tipo_Documento_id_tipo_documento, Apartamento_id_apartamento, NOTIFICACIONES_id_notificaciones, "
                    + "tipo_ocupante, fecha_registro) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setString(3, usuario.getDocumento());
            ps.setString(4, usuario.getTelefono());
            ps.setString(5, usuario.getCorreo());
            ps.setString(6, usuario.getContrasena());
            ps.setInt(7, usuario.getIdRol());
            ps.setInt(8, usuario.getIdTipoDocumento());
            ps.setInt(9, usuario.getIdApartamento());
            ps.setInt(10, usuario.getIdNotificaciones());
            ps.setString(11, usuario.getTipoOcupante() != null ? usuario.getTipoOcupante() : "Propietario");
            ps.setTimestamp(12, usuario.getFechaRegistro() != null
                    ? usuario.getFechaRegistro() : new java.sql.Timestamp(System.currentTimeMillis()));
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Usuario consultar(int idUsuario) {
        Connection conn = conect.getconn();
        Usuario usuario = null;
        try {
            String sql = "SELECT idUsuario, nombre, apellido, documento, telefono, correo, contrasena, Rol_idRol, "
                    + "Tipo_Documento_id_tipo_documento, Apartamento_id_apartamento, NOTIFICACIONES_id_notificaciones, "
                    + "tipo_ocupante, fecha_registro "
                    + "FROM Usuario WHERE idUsuario = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                usuario = mapear(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuario;
    }

    public Usuario consultarPorCorreo(String correo) {
        Connection conn = conect.getconn();
        Usuario usuario = null;
        try {
            String sql = "SELECT idUsuario, nombre, apellido, documento, telefono, correo, contrasena, Rol_idRol, "
                    + "Tipo_Documento_id_tipo_documento, Apartamento_id_apartamento, NOTIFICACIONES_id_notificaciones, "
                    + "tipo_ocupante, fecha_registro "
                    + "FROM Usuario WHERE correo = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, correo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                usuario = mapear(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuario;
    }

    public boolean actualizar(Usuario usuario) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Usuario SET nombre = ?, apellido = ?, documento = ?, telefono = ?, correo = ?, "
                    + "contrasena = ?, Rol_idRol = ?, Tipo_Documento_id_tipo_documento = ?, Apartamento_id_apartamento = ?, "
                    + "NOTIFICACIONES_id_notificaciones = ?, tipo_ocupante = ? WHERE idUsuario = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usuario.getNombre());
            ps.setString(2, usuario.getApellido());
            ps.setString(3, usuario.getDocumento());
            ps.setString(4, usuario.getTelefono());
            ps.setString(5, usuario.getCorreo());
            ps.setString(6, usuario.getContrasena());
            ps.setInt(7, usuario.getIdRol());
            ps.setInt(8, usuario.getIdTipoDocumento());
            ps.setInt(9, usuario.getIdApartamento());
            ps.setInt(10, usuario.getIdNotificaciones());
            ps.setString(11, usuario.getTipoOcupante() != null ? usuario.getTipoOcupante() : "Propietario");
            ps.setInt(12, usuario.getIdUsuario());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idUsuario) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM Usuario WHERE idUsuario = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Usuario> listarTodos() {
        Connection conn = conect.getconn();
        List<Usuario> lista = new ArrayList<>();
        try {
            String sql = "SELECT idUsuario, nombre, apellido, documento, telefono, correo, contrasena, Rol_idRol, "
                    + "Tipo_Documento_id_tipo_documento, Apartamento_id_apartamento, NOTIFICACIONES_id_notificaciones, "
                    + "tipo_ocupante, fecha_registro FROM Usuario";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Usuario mapear(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(rs.getInt("idUsuario"));
        usuario.setNombre(rs.getString("nombre"));
        usuario.setApellido(rs.getString("apellido"));
        usuario.setDocumento(rs.getString("documento"));
        usuario.setTelefono(rs.getString("telefono"));
        usuario.setCorreo(rs.getString("correo"));
        usuario.setContrasena(rs.getString("contrasena"));
        usuario.setIdRol(rs.getInt("Rol_idRol"));
        usuario.setIdTipoDocumento(rs.getInt("Tipo_Documento_id_tipo_documento"));
        usuario.setIdApartamento(rs.getInt("Apartamento_id_apartamento"));
        usuario.setIdNotificaciones(rs.getInt("NOTIFICACIONES_id_notificaciones"));
        usuario.setTipoOcupante(rs.getString("tipo_ocupante"));
        usuario.setFechaRegistro(rs.getTimestamp("fecha_registro"));
        return usuario;
    }

    /**
     * Lista los usuarios que tienen un rol específico (1 = Administrador, 2 = Residente).
     */
    public List<Usuario> listarPorRol(int idRol) {
        Connection conn = conect.getconn();
        List<Usuario> lista = new ArrayList<>();
        try {
            String sql = "SELECT idUsuario, nombre, apellido, documento, telefono, correo, contrasena, Rol_idRol, "
                    + "Tipo_Documento_id_tipo_documento, Apartamento_id_apartamento, NOTIFICACIONES_id_notificaciones, "
                    + "tipo_ocupante, fecha_registro FROM Usuario WHERE Rol_idRol = ? ORDER BY idUsuario ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idRol);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * Cuenta cuántos usuarios existen con un rol específico.
     */
    public int contarPorRol(int idRol) {
        Connection conn = conect.getconn();
        int total = 0;
        try {
            String sql = "SELECT COUNT(*) AS total FROM Usuario WHERE Rol_idRol = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idRol);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                total = rs.getInt("total");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }

    /**
     * Restablece la contraseña de un usuario a un valor dado (usado por el
     * administrador desde el módulo de Usuarios y Unidades).
     */
    public boolean resetearContrasena(int idUsuario, String nuevaContrasenaPlano) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Usuario SET contrasena = ? WHERE idUsuario = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, PasswordUtil.hash(nuevaContrasenaPlano));
            ps.setInt(2, idUsuario);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean existeCorreoODocumento(String correo, String numeroDocumento) {
        Connection conn = conect.getconn();
        boolean existe = false;
        try {
            String sql = "SELECT idUsuario FROM Usuario WHERE correo = ? OR documento = ? LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, correo);
            ps.setString(2, numeroDocumento);
            ResultSet rs = ps.executeQuery();
            existe = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return existe;
    }

    public boolean registroUsuario(Usuario usuario) {
        return insertar(usuario);
    }
}
