package Controlador;

import Modelo.Tiponotificacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TiponotificacionDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Tiponotificacion tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO TIPONOTIFICACION (nombre_tipo_notificacion) VALUES (?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombreTipoNotificacion());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Tiponotificacion consultar(int idTipoNotificacion) {
        Connection conn = conect.getconn();
        Tiponotificacion tipo = null;
        try {
            String sql = "SELECT id_tipo_notificacion, nombre_tipo_notificacion FROM TIPONOTIFICACION WHERE id_tipo_notificacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoNotificacion);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                tipo = new Tiponotificacion();
                tipo.setIdTipoNotificacion(rs.getInt("id_tipo_notificacion"));
                tipo.setNombreTipoNotificacion(rs.getString("nombre_tipo_notificacion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tipo;
    }

    public boolean actualizar(Tiponotificacion tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE TIPONOTIFICACION SET nombre_tipo_notificacion = ? WHERE id_tipo_notificacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombreTipoNotificacion());
            ps.setInt(2, tipo.getIdTipoNotificacion());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idTipoNotificacion) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM TIPONOTIFICACION WHERE id_tipo_notificacion = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoNotificacion);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Tiponotificacion> listarTodos() {
        Connection conn = conect.getconn();
        List<Tiponotificacion> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_tipo_notificacion, nombre_tipo_notificacion FROM TIPONOTIFICACION";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Tiponotificacion tipo = new Tiponotificacion();
                tipo.setIdTipoNotificacion(rs.getInt("id_tipo_notificacion"));
                tipo.setNombreTipoNotificacion(rs.getString("nombre_tipo_notificacion"));
                lista.add(tipo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
