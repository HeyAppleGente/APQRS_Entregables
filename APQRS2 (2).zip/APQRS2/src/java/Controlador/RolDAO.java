package Controlador;

import Modelo.Rol;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RolDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Rol rol) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO Rol (nombre_rol) VALUES (?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, rol.getNombreRol());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Rol consultar(int idRol) {
        Connection conn = conect.getconn();
        Rol rol = null;
        try {
            String sql = "SELECT idRol, nombre_rol FROM Rol WHERE idRol = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idRol);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                rol = new Rol();
                rol.setIdRol(rs.getInt("idRol"));
                rol.setNombreRol(rs.getString("nombre_rol"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rol;
    }

    public boolean actualizar(Rol rol) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Rol SET nombre_rol = ? WHERE idRol = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, rol.getNombreRol());
            ps.setInt(2, rol.getIdRol());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idRol) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM Rol WHERE idRol = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idRol);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Rol> listarTodos() {
        Connection conn = conect.getconn();
        List<Rol> lista = new ArrayList<>();
        try {
            String sql = "SELECT idRol, nombre_rol FROM Rol";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Rol rol = new Rol();
                rol.setIdRol(rs.getInt("idRol"));
                rol.setNombreRol(rs.getString("nombre_rol"));
                lista.add(rol);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
