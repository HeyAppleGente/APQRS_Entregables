package Controlador;

import Modelo.Citas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CitasDAO {

    private static final String COLUMNAS = "id_citas, fecha, hora, observaciones, respuesta, fecha_creacion, "
            + "fecha_respuesta, Usuario_idUsuario, TIPOCITA_id_tipo_cita, PQRS_id_pqrs, notificada_residente, cancelada, asistencia, "
            + "reprogramacion_solicitada, mensaje_reprogramacion";

    private Conexion conect = new Conexion();

    public boolean insertar(Citas cita) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO Citas (fecha, hora, observaciones, respuesta, fecha_creacion, fecha_respuesta, "
                    + "Usuario_idUsuario, TIPOCITA_id_tipo_cita, PQRS_id_pqrs, notificada_residente, cancelada, asistencia) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, cita.getFecha());
            ps.setTime(2, cita.getHora());
            ps.setString(3, cita.getObservaciones());
            ps.setString(4, cita.getRespuesta());
            ps.setTimestamp(5, cita.getFechaCreacion());
            ps.setTimestamp(6, cita.getFechaRespuesta());
            ps.setInt(7, cita.getIdUsuario());
            ps.setInt(8, cita.getIdTipoCita());
            if (cita.getIdPqrs() != null && cita.getIdPqrs() > 0) {
                ps.setInt(9, cita.getIdPqrs());
            } else {
                ps.setNull(9, java.sql.Types.INTEGER);
            }
            ps.setBoolean(10, cita.isNotificadaResidente());
            ps.setBoolean(11, cita.isCancelada());
            ps.setString(12, cita.getAsistencia());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Citas consultar(int idCitas) {
        Connection conn = conect.getconn();
        Citas cita = null;
        try {
            String sql = "SELECT " + COLUMNAS + " FROM Citas WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCitas);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                cita = mapear(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cita;
    }

    public boolean actualizar(Citas cita) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Citas SET fecha = ?, hora = ?, observaciones = ?, respuesta = ?, fecha_creacion = ?, "
                    + "fecha_respuesta = ?, Usuario_idUsuario = ?, TIPOCITA_id_tipo_cita = ?, PQRS_id_pqrs = ?, "
                    + "notificada_residente = ?, cancelada = ?, asistencia = ? WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, cita.getFecha());
            ps.setTime(2, cita.getHora());
            ps.setString(3, cita.getObservaciones());
            ps.setString(4, cita.getRespuesta());
            ps.setTimestamp(5, cita.getFechaCreacion());
            ps.setTimestamp(6, cita.getFechaRespuesta());
            ps.setInt(7, cita.getIdUsuario());
            ps.setInt(8, cita.getIdTipoCita());
            if (cita.getIdPqrs() != null && cita.getIdPqrs() > 0) {
                ps.setInt(9, cita.getIdPqrs());
            } else {
                ps.setNull(9, java.sql.Types.INTEGER);
            }
            ps.setBoolean(10, cita.isNotificadaResidente());
            ps.setBoolean(11, cita.isCancelada());
            ps.setString(12, cita.getAsistencia());
            ps.setInt(13, cita.getIdCitas());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idCitas) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM Citas WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCitas);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Citas> listarTodos() {
        Connection conn = conect.getconn();
        List<Citas> lista = new ArrayList<>();
        try {
            String sql = "SELECT " + COLUMNAS + " FROM Citas ORDER BY fecha DESC, hora DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Citas> listarPorUsuario(int idUsuario) {
        Connection conn = conect.getconn();
        List<Citas> lista = new ArrayList<>();
        try {
            String sql = "SELECT " + COLUMNAS + " FROM Citas WHERE Usuario_idUsuario = ? "
                    + "ORDER BY fecha DESC, hora DESC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * Todas las citas agendadas en una fecha exacta (para la vista de día del
     * calendario del administrador). Incluye canceladas para que se vean en el
     * historial del día, marcadas como tal por la vista.
     */
    /**
     * Citas asociadas a una PQRS específica (para mostrarle al residente y al
     * admin la trazabilidad completa: PQRS → cita(s) agendadas para atenderla).
     */
    public List<Citas> listarPorPqrs(int idPqrs) {
        Connection conn = conect.getconn();
        List<Citas> lista = new ArrayList<>();
        try {
            String sql = "SELECT " + COLUMNAS + " FROM Citas WHERE PQRS_id_pqrs = ? ORDER BY fecha ASC, hora ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idPqrs);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public List<Citas> listarPorFecha(java.sql.Date fecha) {
        Connection conn = conect.getconn();
        List<Citas> lista = new ArrayList<>();
        try {
            String sql = "SELECT " + COLUMNAS + " FROM Citas WHERE fecha = ? ORDER BY hora ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, fecha);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    /**
     * Horas ya ocupadas en una fecha dada (para excluirlas al agendar). Las
     * citas canceladas NO cuentan como ocupadas: su horario vuelve a quedar libre.
     */
    public List<java.sql.Time> horasOcupadas(java.sql.Date fecha) {
        Connection conn = conect.getconn();
        List<java.sql.Time> horas = new ArrayList<>();
        try {
            String sql = "SELECT hora FROM Citas WHERE fecha = ? AND cancelada = 0";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, fecha);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                horas.add(rs.getTime("hora"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return horas;
    }

    /**
     * Verificación puntual (para evitar condiciones de carrera) de si una
     * fecha+hora exacta ya está tomada por una cita activa (no cancelada).
     * excluirIdCitas permite ignorar la propia cita al reprogramarla.
     */
    public boolean horaOcupada(java.sql.Date fecha, java.sql.Time hora, int excluirIdCitas) {
        Connection conn = conect.getconn();
        boolean ocupada = false;
        try {
            String sql = "SELECT id_citas FROM Citas WHERE fecha = ? AND hora = ? AND cancelada = 0 AND id_citas <> ? LIMIT 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setDate(1, fecha);
            ps.setTime(2, hora);
            ps.setInt(3, excluirIdCitas);
            ResultSet rs = ps.executeQuery();
            ocupada = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ocupada;
    }

    public boolean horaOcupada(java.sql.Date fecha, java.sql.Time hora) {
        return horaOcupada(fecha, hora, -1);
    }

    public boolean responder(int idCitas, String respuesta) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Citas SET respuesta = ?, fecha_respuesta = ? WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, respuesta);
            ps.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
            ps.setInt(3, idCitas);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /**
     * Cancela una cita sin borrarla (se conserva para la trazabilidad). Libera
     * automáticamente su horario porque horasOcupadas() ya excluye canceladas.
     */
    public boolean cancelar(int idCitas) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Citas SET cancelada = 1, respuesta = ?, fecha_respuesta = ?, notificada_residente = 0 WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "Cita cancelada por administración.");
            ps.setTimestamp(2, new java.sql.Timestamp(System.currentTimeMillis()));
            ps.setInt(3, idCitas);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /**
     * Marca como "ya vistas por el residente" todas sus citas pendientes de
     * notificación. Se llama cuando el residente visita su panel o su lista
     * de citas, para que la alerta de "cita nueva/actualizada" no se repita.
     */
    public boolean marcarNotificadas(int idUsuario) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Citas SET notificada_residente = 1 WHERE Usuario_idUsuario = ? AND notificada_residente = 0";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idUsuario);
            ps.executeUpdate();
            exito = true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    private Citas mapear(ResultSet rs) throws SQLException {
        Citas cita = new Citas();
        cita.setIdCitas(rs.getInt("id_citas"));
        cita.setFecha(rs.getDate("fecha"));
        cita.setHora(rs.getTime("hora"));
        cita.setObservaciones(rs.getString("observaciones"));
        cita.setRespuesta(rs.getString("respuesta"));
        cita.setFechaCreacion(rs.getTimestamp("fecha_creacion"));
        cita.setFechaRespuesta(rs.getTimestamp("fecha_respuesta"));
        cita.setIdUsuario(rs.getInt("Usuario_idUsuario"));
        cita.setIdTipoCita(rs.getInt("TIPOCITA_id_tipo_cita"));
        int idPqrs = rs.getInt("PQRS_id_pqrs");
        cita.setIdPqrs(rs.wasNull() ? null : idPqrs);
        cita.setNotificadaResidente(rs.getBoolean("notificada_residente"));
        cita.setCancelada(rs.getBoolean("cancelada"));
        cita.setAsistencia(rs.getString("asistencia"));
        cita.setReprogramacionSolicitada(rs.getBoolean("reprogramacion_solicitada"));
        cita.setMensajeReprogramacion(rs.getString("mensaje_reprogramacion"));
        return cita;
    }

    /** El residente pide reprogramar una cita ya agendada (no puede asistir). */
    public boolean solicitarReprogramacion(int idCitas, String mensaje) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Citas SET reprogramacion_solicitada = 1, mensaje_reprogramacion = ?, "
                    + "notificada_residente = 1 WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, mensaje);
            ps.setInt(2, idCitas);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /** El administrador ya atendió la solicitud (reprogramó, o decidió dejarla igual). */
    public boolean limpiarSolicitudReprogramacion(int idCitas) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Citas SET reprogramacion_solicitada = 0, mensaje_reprogramacion = NULL WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idCitas);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    /** Todas las citas con una solicitud de reprogramación pendiente (para el admin). */
    public List<Citas> listarConReprogramacionPendiente() {
        Connection conn = conect.getconn();
        List<Citas> lista = new ArrayList<>();
        try {
            String sql = "SELECT " + COLUMNAS + " FROM Citas WHERE reprogramacion_solicitada = 1 AND cancelada = 0 "
                    + "ORDER BY fecha ASC, hora ASC";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    /** Marca si el residente asistió o no a una cita ya pasada. */
    public boolean marcarAsistencia(int idCitas, String asistencia) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Citas SET asistencia = ? WHERE id_citas = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, asistencia);
            ps.setInt(2, idCitas);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }
}
