package Controlador;

/**
 * Utilidades generales de la aplicación.
 *
 * esc(): escapa HTML antes de mostrar texto que escribió un usuario
 * (asunto de una PQRS, descripción, observaciones de una cita, comentarios
 * de seguimiento, etc.). Sin esto, alguien podría escribir por ejemplo
 * "&lt;script&gt;...&lt;/script&gt;" como asunto de su PQRS y ese código se
 * ejecutaría en el navegador de cualquiera que lo vea (XSS almacenado) —
 * incluido el administrador. Se usa así en los JSP: <%= Utilidades.esc(texto) %>
 * en vez de <%= texto %> directo, en cualquier campo que el usuario escribió.
 */
public class Utilidades {

    private Utilidades() {
    }

    public static String esc(String texto) {
        if (texto == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(texto.length());
        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            switch (c) {
                case '&': sb.append("&amp;"); break;
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                case '"': sb.append("&quot;"); break;
                case '\'': sb.append("&#39;"); break;
                default: sb.append(c);
            }
        }
        return sb.toString();
    }
}
