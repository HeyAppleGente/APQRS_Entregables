package Controlador;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Cálculo de plazos de atención (SLA) de las PQRS, en días hábiles
 * (de lunes a viernes; no se descuentan festivos, ya que este sistema no
 * tiene un calendario de festivos configurado — es una aproximación
 * razonable para un conjunto residencial, no una certificación legal).
 */
public class PlazoUtil {

    private PlazoUtil() {
    }

    /** Suma N días hábiles (lunes a viernes) a una fecha de inicio. */
    public static LocalDate sumarDiasHabiles(LocalDate inicio, int diasHabiles) {
        LocalDate fecha = inicio;
        int sumados = 0;
        while (sumados < diasHabiles) {
            fecha = fecha.plusDays(1);
            if (fecha.getDayOfWeek() != DayOfWeek.SATURDAY && fecha.getDayOfWeek() != DayOfWeek.SUNDAY) {
                sumados++;
            }
        }
        return fecha;
    }

    /** Días hábiles completos entre hoy y una fecha límite (negativo si ya venció). */
    public static int diasHabilesRestantes(LocalDate fechaLimite) {
        LocalDate hoy = LocalDate.now();
        if (fechaLimite.isEqual(hoy)) {
            return 0;
        }
        int signo = fechaLimite.isAfter(hoy) ? 1 : -1;
        LocalDate desde = signo == 1 ? hoy : fechaLimite;
        LocalDate hasta = signo == 1 ? fechaLimite : hoy;
        int contados = 0;
        LocalDate cursor = desde;
        while (cursor.isBefore(hasta)) {
            cursor = cursor.plusDays(1);
            if (cursor.getDayOfWeek() != DayOfWeek.SATURDAY && cursor.getDayOfWeek() != DayOfWeek.SUNDAY) {
                contados++;
            }
        }
        return contados * signo;
    }

    /** Resumen calculado del estado del plazo de una PQRS pendiente. */
    public static class EstadoPlazo {
        public final LocalDate fechaLimite;
        public final int diasRestantes; // negativo = vencida
        public final boolean vencida;
        public final boolean porVencer; // vence en 2 días hábiles o menos

        public EstadoPlazo(LocalDate fechaLimite, int diasRestantes) {
            this.fechaLimite = fechaLimite;
            this.diasRestantes = diasRestantes;
            this.vencida = diasRestantes < 0;
            this.porVencer = !vencida && diasRestantes <= 2;
        }
    }

    /** Calcula el estado de plazo de una PQRS según su fecha de radicación y los días hábiles asignados a su tipo. */
    public static EstadoPlazo calcularEstado(LocalDateTime fechaRegistro, int diasPlazoHabiles) {
        LocalDate fechaLimite = sumarDiasHabiles(fechaRegistro.toLocalDate(), diasPlazoHabiles);
        int restantes = diasHabilesRestantes(fechaLimite);
        return new EstadoPlazo(fechaLimite, restantes);
    }
}
