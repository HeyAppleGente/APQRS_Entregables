package Controlador;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Envío de correos reales (bienvenida al crear una cuenta, código de
 * verificación para recuperar contraseña).
 *
 * La configuración (servidor SMTP, usuario, contraseña) se lee de
 * mail.properties — NO está escrita en este archivo. Ver ese archivo para
 * las instrucciones de cómo configurarlo con una cuenta de correo real.
 *
 * IMPORTANTE: si mail.properties no está configurado (usuario/contraseña
 * vacíos) o el envío falla por cualquier razón (credenciales inválidas, sin
 * internet, etc.), este servicio NO lanza una excepción que rompa el flujo
 * que lo llamó (por ejemplo, el registro de un residente) — simplemente
 * registra el error en el log del servidor y continúa. Enviar el correo de
 * bienvenida es un "extra", no debe poder tumbar el registro de la cuenta.
 */
public class EmailService {

    private static String host;
    private static String port;
    private static String user;
    private static String password;
    private static String from;
    private static boolean auth;
    private static boolean starttls;
    private static boolean configurado;

    static {
        Properties props = new Properties();
        try (InputStream in = EmailService.class.getClassLoader().getResourceAsStream("mail.properties")) {
            if (in != null) {
                props.load(in);
                host = props.getProperty("mail.host", "");
                port = props.getProperty("mail.port", "587");
                user = props.getProperty("mail.user", "");
                password = props.getProperty("mail.password", "");
                from = props.getProperty("mail.from", user);
                auth = Boolean.parseBoolean(props.getProperty("mail.auth", "true"));
                starttls = Boolean.parseBoolean(props.getProperty("mail.starttls", "true"));
            } else {
                System.err.println("EmailService: no se encontró mail.properties en el classpath; "
                        + "el envío de correos quedará desactivado.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        configurado = user != null && !user.trim().isEmpty() && password != null && !password.trim().isEmpty();
        if (!configurado) {
            System.err.println("EmailService: mail.properties no tiene usuario/contraseña configurados. "
                    + "No se enviarán correos hasta que se complete esa configuración.");
        }
    }

    private EmailService() {
    }

    public static boolean estaConfigurado() {
        return configurado;
    }

    private static Session crearSesion() {
        Properties propsSmtp = new Properties();
        propsSmtp.put("mail.smtp.host", host);
        propsSmtp.put("mail.smtp.port", port);
        propsSmtp.put("mail.smtp.auth", String.valueOf(auth));
        propsSmtp.put("mail.smtp.starttls.enable", String.valueOf(starttls));

        return Session.getInstance(propsSmtp, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(user, password);
            }
        });
    }

    /**
     * Envía un correo en HTML. Devuelve true si se envió correctamente; si
     * falla o no está configurado, devuelve false y deja el detalle en el log
     * del servidor, sin lanzar excepción hacia quien lo llamó.
     */
    public static boolean enviarCorreo(String destinatario, String asunto, String cuerpoHtml) {
        if (!configurado) {
            System.err.println("EmailService: intento de enviar correo a " + destinatario
                    + " pero mail.properties no está configurado. Correo NO enviado.");
            return false;
        }
        try {
            Session session = crearSesion();
            MimeMessage mensaje = new MimeMessage(session);
            mensaje.setFrom(new InternetAddress(from));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            mensaje.setSubject(asunto);
            mensaje.setContent(cuerpoHtml, "text/html; charset=UTF-8");
            Transport.send(mensaje);
            return true;
        } catch (MessagingException e) {
            System.err.println("EmailService: no se pudo enviar el correo a " + destinatario + ": " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public static boolean enviarBienvenida(String destinatario, String nombre) {
        String asunto = "¡Bienvenido al Sistema APQRS!";
        String cuerpo = "<div style='font-family:Arial,sans-serif;max-width:480px;margin:0 auto;'>"
                + "<h2 style='color:#1e3a8a;'>¡Hola, " + escapar(nombre) + "!</h2>"
                + "<p>Tu cuenta de residente en el <strong>Sistema APQRS</strong> se creó correctamente con este correo.</p>"
                + "<p>Ya puedes iniciar sesión para radicar PQRS y ver tus citas.</p>"
                + "<p style='color:#64748b;font-size:0.85rem;margin-top:24px;'>Si tú no creaste esta cuenta, por favor ignora este mensaje.</p>"
                + "</div>";
        return enviarCorreo(destinatario, asunto, cuerpo);
    }

    public static boolean enviarCodigoVerificacion(String destinatario, String nombre, String codigo) {
        String asunto = "Código para recuperar tu contraseña - APQRS";
        String cuerpo = "<div style='font-family:Arial,sans-serif;max-width:480px;margin:0 auto;'>"
                + "<h2 style='color:#1e3a8a;'>Recuperación de contraseña</h2>"
                + "<p>Hola" + (nombre != null && !nombre.isEmpty() ? ", " + escapar(nombre) : "") + ",</p>"
                + "<p>Tu código de verificación es:</p>"
                + "<div style='background:#f1f5f9;border-radius:10px;padding:16px;text-align:center;"
                + "font-size:1.8rem;font-weight:700;letter-spacing:6px;color:#1e3a8a;margin:16px 0;'>" + codigo + "</div>"
                + "<p>Este código vence en 10 minutos. Si tú no pediste recuperar tu contraseña, ignora este correo.</p>"
                + "</div>";
        return enviarCorreo(destinatario, asunto, cuerpo);
    }

    private static String escapar(String texto) {
        if (texto == null) return "";
        return texto.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
