package Controlador;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Hash de contraseñas con PBKDF2WithHmacSHA256 (parte estándar del JDK, no
 * requiere ninguna librería externa). Cada contraseña se guarda como
 * "sal$hash", ambos en Base64, dentro del mismo campo `contrasena` que ya
 * existía — no se necesita una columna nueva.
 *
 * Migración de contraseñas antiguas (texto plano): ver LoginServlet, que
 * detecta si una contraseña guardada NO tiene este formato, valida contra el
 * texto plano por compatibilidad, y si es correcta la re-guarda ya cifrada.
 * Así los usuarios existentes quedan migrados automáticamente la primera vez
 * que inician sesión, sin que nadie tenga que reescribir la base de datos a mano.
 */
public class PasswordUtil {

    private static final int ITERACIONES = 65536;
    private static final int LONGITUD_LLAVE_BITS = 256;
    private static final int LONGITUD_SAL_BYTES = 16;
    private static final String ALGORITMO = "PBKDF2WithHmacSHA256";

    private PasswordUtil() {
    }

    /** Genera "sal$hash" a partir de una contraseña en texto plano. */
    public static String hash(String passwordPlano) {
        try {
            byte[] sal = new byte[LONGITUD_SAL_BYTES];
            new SecureRandom().nextBytes(sal);
            byte[] hash = derivar(passwordPlano.toCharArray(), sal);
            return Base64.getEncoder().encodeToString(sal) + "$" + Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("No se pudo cifrar la contraseña", e);
        }
    }

    /** Verifica una contraseña en texto plano contra un valor "sal$hash" guardado. */
    public static boolean matches(String passwordPlano, String salHash) {
        try {
            String[] partes = salHash.split("\\$");
            if (partes.length != 2) {
                return false;
            }
            byte[] sal = Base64.getDecoder().decode(partes[0]);
            byte[] hashEsperado = Base64.getDecoder().decode(partes[1]);
            byte[] hashCalculado = derivar(passwordPlano.toCharArray(), sal);
            return constantTimeEquals(hashEsperado, hashCalculado);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * true si el valor guardado ya tiene el formato "sal$hash" de este
     * esquema (en vez de ser una contraseña vieja en texto plano).
     */
    public static boolean pareceHasheada(String valorGuardado) {
        if (valorGuardado == null || !valorGuardado.contains("$")) {
            return false;
        }
        String[] partes = valorGuardado.split("\\$");
        if (partes.length != 2) {
            return false;
        }
        try {
            Base64.getDecoder().decode(partes[0]);
            Base64.getDecoder().decode(partes[1]);
            return true;
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    private static byte[] derivar(char[] passwordChars, byte[] sal) throws NoSuchAlgorithmException, InvalidKeySpecException {
        PBEKeySpec spec = new PBEKeySpec(passwordChars, sal, ITERACIONES, LONGITUD_LLAVE_BITS);
        SecretKeyFactory factory = SecretKeyFactory.getInstance(ALGORITMO);
        return factory.generateSecret(spec).getEncoded();
    }

    /** Comparación en tiempo constante, para no filtrar información por timing attacks. */
    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a.length != b.length) {
            return false;
        }
        int resultado = 0;
        for (int i = 0; i < a.length; i++) {
            resultado |= a[i] ^ b[i];
        }
        return resultado == 0;
    }
}
