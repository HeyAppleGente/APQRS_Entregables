package Controlador;

import Modelo.TipoDocumento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoDocumentoDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(TipoDocumento tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO Tipo_Documento (nombre_tipo_documento) VALUES (?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombreTipoDocumento());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public TipoDocumento consultar(int idTipoDocumento) {
        Connection conn = conect.getconn();
        TipoDocumento tipo = null;
        try {
            String sql = "SELECT id_tipo_documento, nombre_tipo_documento FROM Tipo_Documento WHERE id_tipo_documento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoDocumento);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                tipo = new TipoDocumento();
                tipo.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                tipo.setNombreTipoDocumento(rs.getString("nombre_tipo_documento"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tipo;
    }

    public boolean actualizar(TipoDocumento tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Tipo_Documento SET nombre_tipo_documento = ? WHERE id_tipo_documento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombreTipoDocumento());
            ps.setInt(2, tipo.getIdTipoDocumento());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idTipoDocumento) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM Tipo_Documento WHERE id_tipo_documento = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoDocumento);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<TipoDocumento> listarTodos() {
        Connection conn = conect.getconn();
        List<TipoDocumento> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_tipo_documento, nombre_tipo_documento FROM Tipo_Documento";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                TipoDocumento tipo = new TipoDocumento();
                tipo.setIdTipoDocumento(rs.getInt("id_tipo_documento"));
                tipo.setNombreTipoDocumento(rs.getString("nombre_tipo_documento"));
                lista.add(tipo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
