package Controlador;

import Modelo.Bloque;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BloqueDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Bloque bloque) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO Bloque (nombre_bloque) VALUES (?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, bloque.getNombreBloque());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Bloque consultar(int idBloque) {
        Connection conn = conect.getconn();
        Bloque bloque = null;
        try {
            String sql = "SELECT id_bloque, nombre_bloque FROM Bloque WHERE id_bloque = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idBloque);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                bloque = new Bloque();
                bloque.setIdBloque(rs.getInt("id_bloque"));
                bloque.setNombreBloque(rs.getString("nombre_bloque"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bloque;
    }

    public boolean actualizar(Bloque bloque) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE Bloque SET nombre_bloque = ? WHERE id_bloque = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, bloque.getNombreBloque());
            ps.setInt(2, bloque.getIdBloque());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idBloque) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM Bloque WHERE id_bloque = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idBloque);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Bloque> listarTodos() {
        Connection conn = conect.getconn();
        List<Bloque> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_bloque, nombre_bloque FROM Bloque";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Bloque bloque = new Bloque();
                bloque.setIdBloque(rs.getInt("id_bloque"));
                bloque.setNombreBloque(rs.getString("nombre_bloque"));
                lista.add(bloque);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public Bloque consultarPorNombre(String nombreBloque) {
        Connection conn = conect.getconn();
        Bloque bloque = null;
        try {
            String sql = "SELECT id_bloque, nombre_bloque FROM Bloque WHERE nombre_bloque = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, nombreBloque);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                bloque = new Bloque();
                bloque.setIdBloque(rs.getInt("id_bloque"));
                bloque.setNombreBloque(rs.getString("nombre_bloque"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bloque;
    }

    /**
     * Busca una torre/bloque por nombre; si no existe todavía en la base de
     * datos, la crea. Así el administrador puede escribir "Torre 15" aunque
     * esa torre nunca se haya registrado antes.
     */
    public int buscarOcrear(String nombreBloque) {
        Bloque existente = consultarPorNombre(nombreBloque);
        if (existente != null) {
            return existente.getIdBloque();
        }
        Connection conn = conect.getconn();
        try {
            String sql = "INSERT INTO Bloque (nombre_bloque) VALUES (?)";
            PreparedStatement ps = conn.prepareStatement(sql, java.sql.Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, nombreBloque);
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                return keys.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}
