package Controlador;

import Modelo.Tipocita;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipocitaDAO {

    private Conexion conect = new Conexion();

    public boolean insertar(Tipocita tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "INSERT INTO TIPOCITA (nombre, duracion) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombre());
            ps.setInt(2, tipo.getDuracion());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public Tipocita consultar(int idTipoCita) {
        Connection conn = conect.getconn();
        Tipocita tipo = null;
        try {
            String sql = "SELECT id_tipo_cita, nombre, duracion FROM TIPOCITA WHERE id_tipo_cita = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoCita);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                tipo = new Tipocita();
                tipo.setIdTipoCita(rs.getInt("id_tipo_cita"));
                tipo.setNombre(rs.getString("nombre"));
                tipo.setDuracion(rs.getInt("duracion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tipo;
    }

    public boolean actualizar(Tipocita tipo) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "UPDATE TIPOCITA SET nombre = ?, duracion = ? WHERE id_tipo_cita = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, tipo.getNombre());
            ps.setInt(2, tipo.getDuracion());
            ps.setInt(3, tipo.getIdTipoCita());
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public boolean eliminar(int idTipoCita) {
        Connection conn = conect.getconn();
        boolean exito = false;
        try {
            String sql = "DELETE FROM TIPOCITA WHERE id_tipo_cita = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idTipoCita);
            exito = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exito;
    }

    public List<Tipocita> listarTodos() {
        Connection conn = conect.getconn();
        List<Tipocita> lista = new ArrayList<>();
        try {
            String sql = "SELECT id_tipo_cita, nombre, duracion FROM TIPOCITA";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Tipocita tipo = new Tipocita();
                tipo.setIdTipoCita(rs.getInt("id_tipo_cita"));
                tipo.setNombre(rs.getString("nombre"));
                tipo.setDuracion(rs.getInt("duracion"));
                lista.add(tipo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
