package Pruebas;

import Controlador.SeguimientoDAO;
import Modelo.Seguimiento;
import java.util.Scanner;

public class PruebaInsertarSeguimiento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SeguimientoDAO dao = new SeguimientoDAO();

        System.out.print("Ingrese comentario: ");
        String comentario = sc.nextLine();

        System.out.print("Ingrese ID de la cita: ");
        int idCitas = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del usuario: ");
        int idUsuario = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del PQRS: ");
        int idPqrs = sc.nextInt();
        sc.nextLine();

        Seguimiento seguimiento = new Seguimiento();
        seguimiento.setComentario(comentario);
        seguimiento.setIdCitas(idCitas);
        seguimiento.setIdUsuario(idUsuario);
        seguimiento.setIdPqrs(idPqrs);
        seguimiento.setFechaRegistro(new java.sql.Timestamp(System.currentTimeMillis())); // fecha/hora generada automáticamente para la prueba

        boolean exito = dao.insertar(seguimiento);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
