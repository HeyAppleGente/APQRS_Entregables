package Pruebas;

import Controlador.TipoPqrsDAO;
import Modelo.TipoPqrs;
import java.util.Scanner;

public class PruebaConsultarTipoPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoPqrsDAO dao = new TipoPqrsDAO();

        System.out.print("Ingrese el ID del tipo de PQRS a consultar: ");
        int busqueda = sc.nextInt();

        TipoPqrs tipoPqrs = dao.consultar(busqueda);

        if (tipoPqrs != null) {
            System.out.println("ID: " + tipoPqrs.getIdTipoPqrs());
            System.out.println("Nombre: " + tipoPqrs.getNombreTipoPqrs());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
