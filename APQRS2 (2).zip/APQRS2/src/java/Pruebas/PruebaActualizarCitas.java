package Pruebas;

import Controlador.CitasDAO;
import Modelo.Citas;
import java.util.Scanner;

public class PruebaActualizarCitas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CitasDAO dao = new CitasDAO();

        System.out.print("Ingrese el ID de la cita a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Citas citas = dao.consultar(busqueda);

        if (citas == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a observaciones: ");
            String observaciones = sc.nextLine();

            System.out.print("Ingrese nuevo/a respuesta: ");
            String respuesta = sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del usuario: ");
            int idUsuario = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del tipo de cita: ");
            int idTipoCita = sc.nextInt();
            sc.nextLine();

            citas.setObservaciones(observaciones);
            citas.setRespuesta(respuesta);
            citas.setIdUsuario(idUsuario);
            citas.setIdTipoCita(idTipoCita);

            boolean exito = dao.actualizar(citas);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
