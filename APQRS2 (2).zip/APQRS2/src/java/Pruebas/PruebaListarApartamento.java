package Pruebas;

import Controlador.ApartamentoDAO;
import Modelo.Apartamento;
import java.util.List;

public class PruebaListarApartamento {

    public static void main(String[] args) {
        ApartamentoDAO dao = new ApartamentoDAO();

        List<Apartamento> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Apartamento apartamento : lista) {
                System.out.println("ID: " + apartamento.getIdApartamento() + " | " + "Numero: " + apartamento.getNumero() + " | " + "ID Bloque: " + apartamento.getIdBloque());
            }
        }
    }
}
