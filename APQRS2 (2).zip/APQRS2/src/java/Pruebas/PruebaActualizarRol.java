package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaActualizarRol {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RolDAO dao = new RolDAO();

        System.out.print("Ingrese el ID del rol a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Rol rol = dao.consultar(busqueda);

        if (rol == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a nombre del rol: ");
            String nombreRol = sc.nextLine();

            rol.setNombreRol(nombreRol);

            boolean exito = dao.actualizar(rol);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
