package Pruebas;

import Controlador.NotificacionesDAO;
import java.util.Scanner;

public class PruebaEliminarNotificaciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NotificacionesDAO dao = new NotificacionesDAO();

        System.out.print("Ingrese el ID de la notificación a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
