package Pruebas;

import Controlador.TipocitaDAO;
import Modelo.Tipocita;
import java.util.Scanner;

public class PruebaConsultarTipocita {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipocitaDAO dao = new TipocitaDAO();

        System.out.print("Ingrese el ID del tipo de cita a consultar: ");
        int busqueda = sc.nextInt();

        Tipocita tipocita = dao.consultar(busqueda);

        if (tipocita != null) {
            System.out.println("ID: " + tipocita.getIdTipoCita());
            System.out.println("Nombre: " + tipocita.getNombre());
            System.out.println("Duracion: " + tipocita.getDuracion());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
