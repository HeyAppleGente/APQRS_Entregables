package Pruebas;

import Controlador.PqrsDAO;
import Modelo.Pqrs;
import java.util.List;

public class PruebaListarPqrs {

    public static void main(String[] args) {
        PqrsDAO dao = new PqrsDAO();

        List<Pqrs> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Pqrs pqrs : lista) {
                System.out.println("ID: " + pqrs.getIdPqrs() + " | " + "Asunto: " + pqrs.getAsunto() + " | " + "Descripcion: " + pqrs.getDescripcion() + " | " + "Respuesta: " + pqrs.getRespuesta() + " | " + "Fecha Registro: " + pqrs.getFechaRegistro() + " | " + "Fecha Respuesta: " + pqrs.getFechaRespuesta() + " | " + "ID Tipo Pqrs: " + pqrs.getIdTipoPqrs() + " | " + "ID Usuario: " + pqrs.getIdUsuario());
            }
        }
    }
}
