package Pruebas;

import Controlador.ApartamentoDAO;
import Modelo.Apartamento;
import java.util.Scanner;

public class PruebaInsertarApartamento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ApartamentoDAO dao = new ApartamentoDAO();

        System.out.print("Ingrese número del apartamento: ");
        String numero = sc.nextLine();

        System.out.print("Ingrese ID del bloque: ");
        int idBloque = sc.nextInt();
        sc.nextLine();

        Apartamento apartamento = new Apartamento();
        apartamento.setNumero(numero);
        apartamento.setIdBloque(idBloque);

        boolean exito = dao.insertar(apartamento);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
