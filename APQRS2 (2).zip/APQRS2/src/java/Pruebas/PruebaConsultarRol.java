package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaConsultarRol {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RolDAO dao = new RolDAO();

        System.out.print("Ingrese el ID del rol a consultar: ");
        int busqueda = sc.nextInt();

        Rol rol = dao.consultar(busqueda);

        if (rol != null) {
            System.out.println("ID: " + rol.getIdRol());
            System.out.println("Nombre: " + rol.getNombreRol());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
