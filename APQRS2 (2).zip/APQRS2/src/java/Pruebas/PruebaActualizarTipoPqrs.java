package Pruebas;

import Controlador.TipoPqrsDAO;
import Modelo.TipoPqrs;
import java.util.Scanner;

public class PruebaActualizarTipoPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoPqrsDAO dao = new TipoPqrsDAO();

        System.out.print("Ingrese el ID del tipo de PQRS a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        TipoPqrs tipoPqrs = dao.consultar(busqueda);

        if (tipoPqrs == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a nombre del tipo de PQRS: ");
            String nombreTipoPqrs = sc.nextLine();

            tipoPqrs.setNombreTipoPqrs(nombreTipoPqrs);

            boolean exito = dao.actualizar(tipoPqrs);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
