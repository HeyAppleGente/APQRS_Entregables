package Pruebas;

import Controlador.SeguimientoDAO;
import java.util.Scanner;

public class PruebaEliminarSeguimiento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SeguimientoDAO dao = new SeguimientoDAO();

        System.out.print("Ingrese el ID del seguimiento a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
