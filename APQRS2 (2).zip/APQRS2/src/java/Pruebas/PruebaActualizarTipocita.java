package Pruebas;

import Controlador.TipocitaDAO;
import Modelo.Tipocita;
import java.util.Scanner;

public class PruebaActualizarTipocita {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipocitaDAO dao = new TipocitaDAO();

        System.out.print("Ingrese el ID del tipo de cita a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Tipocita tipocita = dao.consultar(busqueda);

        if (tipocita == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a nombre del tipo de cita: ");
            String nombre = sc.nextLine();

            System.out.print("Ingrese nuevo/a duración en minutos: ");
            int duracion = sc.nextInt();
            sc.nextLine();

            tipocita.setNombre(nombre);
            tipocita.setDuracion(duracion);

            boolean exito = dao.actualizar(tipocita);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
