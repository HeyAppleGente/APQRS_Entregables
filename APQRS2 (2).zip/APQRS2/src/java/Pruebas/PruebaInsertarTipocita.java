package Pruebas;

import Controlador.TipocitaDAO;
import Modelo.Tipocita;
import java.util.Scanner;

public class PruebaInsertarTipocita {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipocitaDAO dao = new TipocitaDAO();

        System.out.print("Ingrese nombre del tipo de cita: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese duración en minutos: ");
        int duracion = sc.nextInt();
        sc.nextLine();

        Tipocita tipocita = new Tipocita();
        tipocita.setNombre(nombre);
        tipocita.setDuracion(duracion);

        boolean exito = dao.insertar(tipocita);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
