package Pruebas;

import Controlador.BloqueDAO;
import Modelo.Bloque;
import java.util.Scanner;

public class PruebaActualizarBloque {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BloqueDAO dao = new BloqueDAO();

        System.out.print("Ingrese el ID del bloque a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Bloque bloque = dao.consultar(busqueda);

        if (bloque == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a nombre del bloque: ");
            String nombreBloque = sc.nextLine();

            bloque.setNombreBloque(nombreBloque);

            boolean exito = dao.actualizar(bloque);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
