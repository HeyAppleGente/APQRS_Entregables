package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;

public class PruebaInsertarUsuario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();

        System.out.print("Ingrese nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Ingrese apellido: ");
        String apellido = sc.nextLine();

        System.out.print("Ingrese documento: ");
        String documento = sc.nextLine();

        System.out.print("Ingrese teléfono: ");
        String telefono = sc.nextLine();

        System.out.print("Ingrese correo: ");
        String correo = sc.nextLine();

        System.out.print("Ingrese contraseña: ");
        String contrasena = sc.nextLine();

        System.out.print("Ingrese ID del rol: ");
        int idRol = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del tipo de documento: ");
        int idTipoDocumento = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del apartamento: ");
        int idApartamento = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID de la notificación: ");
        int idNotificaciones = sc.nextInt();
        sc.nextLine();

        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setApellido(apellido);
        usuario.setDocumento(documento);
        usuario.setTelefono(telefono);
        usuario.setCorreo(correo);
        usuario.setContrasena(contrasena);
        usuario.setIdRol(idRol);
        usuario.setIdTipoDocumento(idTipoDocumento);
        usuario.setIdApartamento(idApartamento);
        usuario.setIdNotificaciones(idNotificaciones);

        boolean exito = dao.insertar(usuario);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
