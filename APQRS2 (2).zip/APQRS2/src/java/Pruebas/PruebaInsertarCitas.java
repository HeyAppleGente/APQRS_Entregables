package Pruebas;

import Controlador.CitasDAO;
import Modelo.Citas;
import java.util.Scanner;

public class PruebaInsertarCitas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CitasDAO dao = new CitasDAO();

        System.out.print("Ingrese observaciones: ");
        String observaciones = sc.nextLine();

        System.out.print("Ingrese respuesta: ");
        String respuesta = sc.nextLine();

        System.out.print("Ingrese ID del usuario: ");
        int idUsuario = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del tipo de cita: ");
        int idTipoCita = sc.nextInt();
        sc.nextLine();

        Citas citas = new Citas();
        citas.setObservaciones(observaciones);
        citas.setRespuesta(respuesta);
        citas.setIdUsuario(idUsuario);
        citas.setIdTipoCita(idTipoCita);
        citas.setFecha(java.sql.Date.valueOf(java.time.LocalDate.now().plusDays(1))); // fecha/hora generada automáticamente para la prueba
        citas.setHora(java.sql.Time.valueOf("10:00:00")); // fecha/hora generada automáticamente para la prueba
        citas.setFechaCreacion(new java.sql.Timestamp(System.currentTimeMillis())); // fecha/hora generada automáticamente para la prueba
        citas.setFechaRespuesta(new java.sql.Timestamp(System.currentTimeMillis())); // fecha/hora generada automáticamente para la prueba

        boolean exito = dao.insertar(citas);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
