package Pruebas;

import Controlador.TipocitaDAO;
import java.util.Scanner;

public class PruebaEliminarTipocita {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipocitaDAO dao = new TipocitaDAO();

        System.out.print("Ingrese el ID del tipo de cita a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
