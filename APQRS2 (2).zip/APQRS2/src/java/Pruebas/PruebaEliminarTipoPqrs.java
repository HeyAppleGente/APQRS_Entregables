package Pruebas;

import Controlador.TipoPqrsDAO;
import java.util.Scanner;

public class PruebaEliminarTipoPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoPqrsDAO dao = new TipoPqrsDAO();

        System.out.print("Ingrese el ID del tipo de PQRS a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
