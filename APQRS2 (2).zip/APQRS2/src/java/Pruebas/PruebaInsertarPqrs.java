package Pruebas;

import Controlador.PqrsDAO;
import Modelo.Pqrs;
import java.util.Scanner;

public class PruebaInsertarPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PqrsDAO dao = new PqrsDAO();

        System.out.print("Ingrese asunto: ");
        String asunto = sc.nextLine();

        System.out.print("Ingrese descripción: ");
        String descripcion = sc.nextLine();

        System.out.print("Ingrese respuesta: ");
        String respuesta = sc.nextLine();

        System.out.print("Ingrese ID del tipo de PQRS: ");
        int idTipoPqrs = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del usuario: ");
        int idUsuario = sc.nextInt();
        sc.nextLine();

        Pqrs pqrs = new Pqrs();
        pqrs.setAsunto(asunto);
        pqrs.setDescripcion(descripcion);
        pqrs.setRespuesta(respuesta);
        pqrs.setIdTipoPqrs(idTipoPqrs);
        pqrs.setIdUsuario(idUsuario);
        pqrs.setFechaRegistro(new java.sql.Timestamp(System.currentTimeMillis())); // fecha/hora generada automáticamente para la prueba
        pqrs.setFechaRespuesta(new java.sql.Timestamp(System.currentTimeMillis())); // fecha/hora generada automáticamente para la prueba

        boolean exito = dao.insertar(pqrs);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
