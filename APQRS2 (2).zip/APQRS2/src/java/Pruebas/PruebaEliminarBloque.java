package Pruebas;

import Controlador.BloqueDAO;
import java.util.Scanner;

public class PruebaEliminarBloque {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BloqueDAO dao = new BloqueDAO();

        System.out.print("Ingrese el ID del bloque a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
