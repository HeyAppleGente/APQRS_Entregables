package Pruebas;

import Controlador.TiponotificacionDAO;
import Modelo.Tiponotificacion;
import java.util.Scanner;

public class PruebaActualizarTiponotificacion {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TiponotificacionDAO dao = new TiponotificacionDAO();

        System.out.print("Ingrese el ID del tipo de notificación a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Tiponotificacion tiponotificacion = dao.consultar(busqueda);

        if (tiponotificacion == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a nombre del tipo de notificación: ");
            String nombreTipoNotificacion = sc.nextLine();

            tiponotificacion.setNombreTipoNotificacion(nombreTipoNotificacion);

            boolean exito = dao.actualizar(tiponotificacion);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
