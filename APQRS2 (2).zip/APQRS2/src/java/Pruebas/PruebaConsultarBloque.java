package Pruebas;

import Controlador.BloqueDAO;
import Modelo.Bloque;
import java.util.Scanner;

public class PruebaConsultarBloque {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BloqueDAO dao = new BloqueDAO();

        System.out.print("Ingrese el ID del bloque a consultar: ");
        int busqueda = sc.nextInt();

        Bloque bloque = dao.consultar(busqueda);

        if (bloque != null) {
            System.out.println("ID: " + bloque.getIdBloque());
            System.out.println("Nombre: " + bloque.getNombreBloque());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
