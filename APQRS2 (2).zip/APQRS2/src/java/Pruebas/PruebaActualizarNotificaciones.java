package Pruebas;

import Controlador.NotificacionesDAO;
import Modelo.Notificaciones;
import java.util.Scanner;

public class PruebaActualizarNotificaciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NotificacionesDAO dao = new NotificacionesDAO();

        System.out.print("Ingrese el ID de la notificación a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Notificaciones notificaciones = dao.consultar(busqueda);

        if (notificaciones == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a título: ");
            String titulo = sc.nextLine();

            System.out.print("Ingrese nuevo/a mensaje: ");
            String mensaje = sc.nextLine();

            System.out.print("Ingrese nuevo/a ¿ya fue leído? (s/n): ");
            String leidoStr = sc.nextLine();
            boolean leido = leidoStr.trim().equalsIgnoreCase("s");

            System.out.print("Ingrese nuevo/a ID de la cita: ");
            int idCitas = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del tipo de notificación: ");
            int idTipoNotificacion = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del PQRS: ");
            int idPqrs = sc.nextInt();
            sc.nextLine();

            notificaciones.setTitulo(titulo);
            notificaciones.setMensaje(mensaje);
            notificaciones.setLeido(leido);
            notificaciones.setIdCitas(idCitas);
            notificaciones.setIdTipoNotificacion(idTipoNotificacion);
            notificaciones.setIdPqrs(idPqrs);

            boolean exito = dao.actualizar(notificaciones);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
