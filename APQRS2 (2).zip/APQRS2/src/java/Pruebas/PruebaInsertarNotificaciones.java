package Pruebas;

import Controlador.NotificacionesDAO;
import Modelo.Notificaciones;
import java.util.Scanner;

public class PruebaInsertarNotificaciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NotificacionesDAO dao = new NotificacionesDAO();

        System.out.print("Ingrese título: ");
        String titulo = sc.nextLine();

        System.out.print("Ingrese mensaje: ");
        String mensaje = sc.nextLine();

        System.out.print("Ingrese ¿ya fue leído? (s/n): ");
        String leidoStr = sc.nextLine();
        boolean leido = leidoStr.trim().equalsIgnoreCase("s");

        System.out.print("Ingrese ID de la cita: ");
        int idCitas = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del tipo de notificación: ");
        int idTipoNotificacion = sc.nextInt();
        sc.nextLine();

        System.out.print("Ingrese ID del PQRS: ");
        int idPqrs = sc.nextInt();
        sc.nextLine();

        Notificaciones notificaciones = new Notificaciones();
        notificaciones.setTitulo(titulo);
        notificaciones.setMensaje(mensaje);
        notificaciones.setLeido(leido);
        notificaciones.setIdCitas(idCitas);
        notificaciones.setIdTipoNotificacion(idTipoNotificacion);
        notificaciones.setIdPqrs(idPqrs);
        notificaciones.setFechaEnvio(new java.sql.Timestamp(System.currentTimeMillis())); // fecha/hora generada automáticamente para la prueba

        boolean exito = dao.insertar(notificaciones);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
