package Pruebas;

import Controlador.CitasDAO;
import Modelo.Citas;
import java.util.List;

public class PruebaListarCitas {

    public static void main(String[] args) {
        CitasDAO dao = new CitasDAO();

        List<Citas> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Citas citas : lista) {
                System.out.println("ID: " + citas.getIdCitas() + " | " + "Fecha: " + citas.getFecha() + " | " + "Hora: " + citas.getHora() + " | " + "Observaciones: " + citas.getObservaciones() + " | " + "Respuesta: " + citas.getRespuesta() + " | " + "Fecha Creacion: " + citas.getFechaCreacion() + " | " + "Fecha Respuesta: " + citas.getFechaRespuesta() + " | " + "ID Usuario: " + citas.getIdUsuario() + " | " + "ID Tipo Cita: " + citas.getIdTipoCita());
            }
        }
    }
}
