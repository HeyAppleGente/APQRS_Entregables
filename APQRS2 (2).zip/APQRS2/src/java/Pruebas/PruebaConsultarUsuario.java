package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;

public class PruebaConsultarUsuario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();

        System.out.print("Ingrese el ID del usuario a consultar: ");
        int busqueda = sc.nextInt();

        Usuario usuario = dao.consultar(busqueda);

        if (usuario != null) {
            System.out.println("ID: " + usuario.getIdUsuario());
            System.out.println("Nombre: " + usuario.getNombre());
            System.out.println("Apellido: " + usuario.getApellido());
            System.out.println("Documento: " + usuario.getDocumento());
            System.out.println("Telefono: " + usuario.getTelefono());
            System.out.println("Correo: " + usuario.getCorreo());
            System.out.println("ID Rol: " + usuario.getIdRol());
            System.out.println("ID Tipo Documento: " + usuario.getIdTipoDocumento());
            System.out.println("ID Apartamento: " + usuario.getIdApartamento());
            System.out.println("ID Notificaciones: " + usuario.getIdNotificaciones());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
