package Pruebas;

import Controlador.NotificacionesDAO;
import Modelo.Notificaciones;
import java.util.List;

public class PruebaListarNotificaciones {

    public static void main(String[] args) {
        NotificacionesDAO dao = new NotificacionesDAO();

        List<Notificaciones> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Notificaciones notificaciones : lista) {
                System.out.println("ID: " + notificaciones.getIdNotificaciones() + " | " + "Titulo: " + notificaciones.getTitulo() + " | " + "Mensaje: " + notificaciones.getMensaje() + " | " + "Leido: " + notificaciones.isLeido() + " | " + "Fecha Envio: " + notificaciones.getFechaEnvio() + " | " + "ID Citas: " + notificaciones.getIdCitas() + " | " + "ID Tipo Notificacion: " + notificaciones.getIdTipoNotificacion() + " | " + "ID Pqrs: " + notificaciones.getIdPqrs());
            }
        }
    }
}
