package Pruebas;

import Controlador.ApartamentoDAO;
import Modelo.Apartamento;
import java.util.Scanner;

public class PruebaConsultarApartamento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ApartamentoDAO dao = new ApartamentoDAO();

        System.out.print("Ingrese el ID del apartamento a consultar: ");
        int busqueda = sc.nextInt();

        Apartamento apartamento = dao.consultar(busqueda);

        if (apartamento != null) {
            System.out.println("ID: " + apartamento.getIdApartamento());
            System.out.println("Numero: " + apartamento.getNumero());
            System.out.println("ID Bloque: " + apartamento.getIdBloque());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
