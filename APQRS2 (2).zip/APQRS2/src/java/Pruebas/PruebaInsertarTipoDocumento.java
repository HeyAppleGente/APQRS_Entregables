package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebaInsertarTipoDocumento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoDocumentoDAO dao = new TipoDocumentoDAO();

        System.out.print("Ingrese nombre del tipo de documento: ");
        String nombreTipoDocumento = sc.nextLine();

        TipoDocumento tipoDocumento = new TipoDocumento();
        tipoDocumento.setNombreTipoDocumento(nombreTipoDocumento);

        boolean exito = dao.insertar(tipoDocumento);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
