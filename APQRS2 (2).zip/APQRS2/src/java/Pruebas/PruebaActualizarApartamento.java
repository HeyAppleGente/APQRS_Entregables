package Pruebas;

import Controlador.ApartamentoDAO;
import Modelo.Apartamento;
import java.util.Scanner;

public class PruebaActualizarApartamento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ApartamentoDAO dao = new ApartamentoDAO();

        System.out.print("Ingrese el ID del apartamento a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Apartamento apartamento = dao.consultar(busqueda);

        if (apartamento == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a número del apartamento: ");
            String numero = sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del bloque: ");
            int idBloque = sc.nextInt();
            sc.nextLine();

            apartamento.setNumero(numero);
            apartamento.setIdBloque(idBloque);

            boolean exito = dao.actualizar(apartamento);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
