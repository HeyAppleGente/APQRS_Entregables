package Pruebas;

import Controlador.RolDAO;
import java.util.Scanner;

public class PruebaEliminarRol {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RolDAO dao = new RolDAO();

        System.out.print("Ingrese el ID del rol a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
