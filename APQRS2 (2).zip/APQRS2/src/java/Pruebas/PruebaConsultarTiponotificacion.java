package Pruebas;

import Controlador.TiponotificacionDAO;
import Modelo.Tiponotificacion;
import java.util.Scanner;

public class PruebaConsultarTiponotificacion {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TiponotificacionDAO dao = new TiponotificacionDAO();

        System.out.print("Ingrese el ID del tipo de notificación a consultar: ");
        int busqueda = sc.nextInt();

        Tiponotificacion tiponotificacion = dao.consultar(busqueda);

        if (tiponotificacion != null) {
            System.out.println("ID: " + tiponotificacion.getIdTipoNotificacion());
            System.out.println("Nombre: " + tiponotificacion.getNombreTipoNotificacion());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
