package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;

public class PruebaConexion {
    public static void main(String[] args) {
        UsuarioDAO dao = new UsuarioDAO();
        // Reemplaza por un correo existente en tu BD
        Usuario user = dao.consultarPorCorreo("admin@pqrs.local");

        if (user != null) {
            System.out.println("Conexión exitosa a BD");
            System.out.println("Usuario: " + user.getNombre());
            System.out.println("Rol ID: " + user.getIdRol());
        } else {
            System.out.println(" No se encontró el usuario o falla en conexión.");
        }
    }
}