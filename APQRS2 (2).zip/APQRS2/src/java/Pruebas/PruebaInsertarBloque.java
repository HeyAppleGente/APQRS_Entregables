package Pruebas;

import Controlador.BloqueDAO;
import Modelo.Bloque;
import java.util.Scanner;

public class PruebaInsertarBloque {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        BloqueDAO dao = new BloqueDAO();

        System.out.print("Ingrese nombre del bloque: ");
        String nombreBloque = sc.nextLine();

        Bloque bloque = new Bloque();
        bloque.setNombreBloque(nombreBloque);

        boolean exito = dao.insertar(bloque);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
