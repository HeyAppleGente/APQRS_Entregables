package Pruebas;

import Controlador.TipocitaDAO;
import Modelo.Tipocita;
import java.util.List;

public class PruebaListarTipocita {

    public static void main(String[] args) {
        TipocitaDAO dao = new TipocitaDAO();

        List<Tipocita> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Tipocita tipocita : lista) {
                System.out.println("ID: " + tipocita.getIdTipoCita() + " | " + "Nombre: " + tipocita.getNombre() + " | " + "Duracion: " + tipocita.getDuracion());
            }
        }
    }
}
