package Pruebas;

import Controlador.ApartamentoDAO;
import java.util.Scanner;

public class PruebaEliminarApartamento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ApartamentoDAO dao = new ApartamentoDAO();

        System.out.print("Ingrese el ID del apartamento a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
