package Pruebas;

import Controlador.TipoPqrsDAO;
import Modelo.TipoPqrs;
import java.util.List;

public class PruebaListarTipoPqrs {

    public static void main(String[] args) {
        TipoPqrsDAO dao = new TipoPqrsDAO();

        List<TipoPqrs> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (TipoPqrs tipoPqrs : lista) {
                System.out.println("ID: " + tipoPqrs.getIdTipoPqrs() + " | " + "Nombre: " + tipoPqrs.getNombreTipoPqrs());
            }
        }
    }
}
