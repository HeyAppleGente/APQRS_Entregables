package Pruebas;

import Controlador.PqrsDAO;
import java.util.Scanner;

public class PruebaEliminarPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PqrsDAO dao = new PqrsDAO();

        System.out.print("Ingrese el ID del PQRS a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
