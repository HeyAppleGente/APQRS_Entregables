package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebaConsultarTipoDocumento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoDocumentoDAO dao = new TipoDocumentoDAO();

        System.out.print("Ingrese el ID del tipo de documento a consultar: ");
        int busqueda = sc.nextInt();

        TipoDocumento tipoDocumento = dao.consultar(busqueda);

        if (tipoDocumento != null) {
            System.out.println("ID: " + tipoDocumento.getIdTipoDocumento());
            System.out.println("Nombre: " + tipoDocumento.getNombreTipoDocumento());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
