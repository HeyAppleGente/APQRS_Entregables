package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.List;

public class PruebaListarTipoDocumento {

    public static void main(String[] args) {
        TipoDocumentoDAO dao = new TipoDocumentoDAO();

        List<TipoDocumento> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (TipoDocumento tipoDocumento : lista) {
                System.out.println("ID: " + tipoDocumento.getIdTipoDocumento() + " | " + "Nombre: " + tipoDocumento.getNombreTipoDocumento());
            }
        }
    }
}
