package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.List;

public class PruebaListarUsuario {

    public static void main(String[] args) {
        UsuarioDAO dao = new UsuarioDAO();

        List<Usuario> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Usuario usuario : lista) {
                System.out.println("ID: " + usuario.getIdUsuario() + " | " + "Nombre: " + usuario.getNombre() + " | " + "Apellido: " + usuario.getApellido() + " | " + "Documento: " + usuario.getDocumento() + " | " + "Telefono: " + usuario.getTelefono() + " | " + "Correo: " + usuario.getCorreo() + " | " + "ID Rol: " + usuario.getIdRol() + " | " + "ID Tipo Documento: " + usuario.getIdTipoDocumento() + " | " + "ID Apartamento: " + usuario.getIdApartamento() + " | " + "ID Notificaciones: " + usuario.getIdNotificaciones());
            }
        }
    }
}
