package Pruebas;

import Controlador.SeguimientoDAO;
import Modelo.Seguimiento;
import java.util.List;

public class PruebaListarSeguimiento {

    public static void main(String[] args) {
        SeguimientoDAO dao = new SeguimientoDAO();

        List<Seguimiento> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Seguimiento seguimiento : lista) {
                System.out.println("ID: " + seguimiento.getIdSeguimiento() + " | " + "Comentario: " + seguimiento.getComentario() + " | " + "Fecha Registro: " + seguimiento.getFechaRegistro() + " | " + "ID Citas: " + seguimiento.getIdCitas() + " | " + "ID Usuario: " + seguimiento.getIdUsuario() + " | " + "ID Pqrs: " + seguimiento.getIdPqrs());
            }
        }
    }
}
