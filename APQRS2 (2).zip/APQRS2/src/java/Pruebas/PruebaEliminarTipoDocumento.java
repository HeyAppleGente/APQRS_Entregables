package Pruebas;

import Controlador.TipoDocumentoDAO;
import java.util.Scanner;

public class PruebaEliminarTipoDocumento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoDocumentoDAO dao = new TipoDocumentoDAO();

        System.out.print("Ingrese el ID del tipo de documento a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
