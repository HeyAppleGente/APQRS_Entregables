package Pruebas;

import Controlador.TipoDocumentoDAO;
import Modelo.TipoDocumento;
import java.util.Scanner;

public class PruebaActualizarTipoDocumento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoDocumentoDAO dao = new TipoDocumentoDAO();

        System.out.print("Ingrese el ID del tipo de documento a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        TipoDocumento tipoDocumento = dao.consultar(busqueda);

        if (tipoDocumento == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a nombre del tipo de documento: ");
            String nombreTipoDocumento = sc.nextLine();

            tipoDocumento.setNombreTipoDocumento(nombreTipoDocumento);

            boolean exito = dao.actualizar(tipoDocumento);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
