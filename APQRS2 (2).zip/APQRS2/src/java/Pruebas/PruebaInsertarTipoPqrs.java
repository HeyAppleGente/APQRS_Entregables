package Pruebas;

import Controlador.TipoPqrsDAO;
import Modelo.TipoPqrs;
import java.util.Scanner;

public class PruebaInsertarTipoPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TipoPqrsDAO dao = new TipoPqrsDAO();

        System.out.print("Ingrese nombre del tipo de PQRS: ");
        String nombreTipoPqrs = sc.nextLine();

        TipoPqrs tipoPqrs = new TipoPqrs();
        tipoPqrs.setNombreTipoPqrs(nombreTipoPqrs);

        boolean exito = dao.insertar(tipoPqrs);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
