package Pruebas;

import Controlador.TiponotificacionDAO;
import Modelo.Tiponotificacion;
import java.util.Scanner;

public class PruebaInsertarTiponotificacion {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TiponotificacionDAO dao = new TiponotificacionDAO();

        System.out.print("Ingrese nombre del tipo de notificación: ");
        String nombreTipoNotificacion = sc.nextLine();

        Tiponotificacion tiponotificacion = new Tiponotificacion();
        tiponotificacion.setNombreTipoNotificacion(nombreTipoNotificacion);

        boolean exito = dao.insertar(tiponotificacion);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
