package Pruebas;

import Controlador.CitasDAO;
import java.util.Scanner;

public class PruebaEliminarCitas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CitasDAO dao = new CitasDAO();

        System.out.print("Ingrese el ID de la cita a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
