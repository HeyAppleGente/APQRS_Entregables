package Pruebas;

import Controlador.PqrsDAO;
import Modelo.Pqrs;
import java.util.Scanner;

public class PruebaConsultarPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PqrsDAO dao = new PqrsDAO();

        System.out.print("Ingrese el ID del PQRS a consultar: ");
        int busqueda = sc.nextInt();

        Pqrs pqrs = dao.consultar(busqueda);

        if (pqrs != null) {
            System.out.println("ID: " + pqrs.getIdPqrs());
            System.out.println("Asunto: " + pqrs.getAsunto());
            System.out.println("Descripcion: " + pqrs.getDescripcion());
            System.out.println("Respuesta: " + pqrs.getRespuesta());
            System.out.println("Fecha Registro: " + pqrs.getFechaRegistro());
            System.out.println("Fecha Respuesta: " + pqrs.getFechaRespuesta());
            System.out.println("ID Tipo Pqrs: " + pqrs.getIdTipoPqrs());
            System.out.println("ID Usuario: " + pqrs.getIdUsuario());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
