package Pruebas;

import Controlador.TiponotificacionDAO;
import java.util.Scanner;

public class PruebaEliminarTiponotificacion {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TiponotificacionDAO dao = new TiponotificacionDAO();

        System.out.print("Ingrese el ID del tipo de notificación a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
