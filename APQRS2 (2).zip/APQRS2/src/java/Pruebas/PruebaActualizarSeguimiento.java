package Pruebas;

import Controlador.SeguimientoDAO;
import Modelo.Seguimiento;
import java.util.Scanner;

public class PruebaActualizarSeguimiento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SeguimientoDAO dao = new SeguimientoDAO();

        System.out.print("Ingrese el ID del seguimiento a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Seguimiento seguimiento = dao.consultar(busqueda);

        if (seguimiento == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a comentario: ");
            String comentario = sc.nextLine();

            System.out.print("Ingrese nuevo/a ID de la cita: ");
            int idCitas = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del usuario: ");
            int idUsuario = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del PQRS: ");
            int idPqrs = sc.nextInt();
            sc.nextLine();

            seguimiento.setComentario(comentario);
            seguimiento.setIdCitas(idCitas);
            seguimiento.setIdUsuario(idUsuario);
            seguimiento.setIdPqrs(idPqrs);

            boolean exito = dao.actualizar(seguimiento);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
