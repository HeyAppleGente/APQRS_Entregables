package Pruebas;

import Controlador.CitasDAO;
import Modelo.Citas;
import java.util.Scanner;

public class PruebaConsultarCitas {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CitasDAO dao = new CitasDAO();

        System.out.print("Ingrese el ID de la cita a consultar: ");
        int busqueda = sc.nextInt();

        Citas citas = dao.consultar(busqueda);

        if (citas != null) {
            System.out.println("ID: " + citas.getIdCitas());
            System.out.println("Fecha: " + citas.getFecha());
            System.out.println("Hora: " + citas.getHora());
            System.out.println("Observaciones: " + citas.getObservaciones());
            System.out.println("Respuesta: " + citas.getRespuesta());
            System.out.println("Fecha Creacion: " + citas.getFechaCreacion());
            System.out.println("Fecha Respuesta: " + citas.getFechaRespuesta());
            System.out.println("ID Usuario: " + citas.getIdUsuario());
            System.out.println("ID Tipo Cita: " + citas.getIdTipoCita());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
