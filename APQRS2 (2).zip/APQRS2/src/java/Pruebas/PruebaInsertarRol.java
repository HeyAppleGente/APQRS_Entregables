package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.Scanner;

public class PruebaInsertarRol {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        RolDAO dao = new RolDAO();

        System.out.print("Ingrese nombre del rol: ");
        String nombreRol = sc.nextLine();

        Rol rol = new Rol();
        rol.setNombreRol(nombreRol);

        boolean exito = dao.insertar(rol);
        System.out.println(exito ? "Registro insertado correctamente." : "No se pudo insertar el registro.");

        sc.close();
    }
}
