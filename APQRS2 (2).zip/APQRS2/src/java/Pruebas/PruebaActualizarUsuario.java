package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuario;
import java.util.Scanner;

public class PruebaActualizarUsuario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();

        System.out.print("Ingrese el ID del usuario a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Usuario usuario = dao.consultar(busqueda);

        if (usuario == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Ingrese nuevo/a apellido: ");
            String apellido = sc.nextLine();

            System.out.print("Ingrese nuevo/a documento: ");
            String documento = sc.nextLine();

            System.out.print("Ingrese nuevo/a teléfono: ");
            String telefono = sc.nextLine();

            System.out.print("Ingrese nuevo/a correo: ");
            String correo = sc.nextLine();

            System.out.print("Ingrese nuevo/a contraseña: ");
            String contrasena = sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del rol: ");
            int idRol = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del tipo de documento: ");
            int idTipoDocumento = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del apartamento: ");
            int idApartamento = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID de la notificación: ");
            int idNotificaciones = sc.nextInt();
            sc.nextLine();

            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setDocumento(documento);
            usuario.setTelefono(telefono);
            usuario.setCorreo(correo);
            usuario.setContrasena(contrasena);
            usuario.setIdRol(idRol);
            usuario.setIdTipoDocumento(idTipoDocumento);
            usuario.setIdApartamento(idApartamento);
            usuario.setIdNotificaciones(idNotificaciones);

            boolean exito = dao.actualizar(usuario);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
