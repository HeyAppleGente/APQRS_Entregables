package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaEliminarUsuario {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();

        System.out.print("Ingrese el ID del usuario a eliminar: ");
        int busqueda = sc.nextInt();

        boolean exito = dao.eliminar(busqueda);
        System.out.println(exito ? "Registro eliminado correctamente." : "No se pudo eliminar el registro.");

        sc.close();
    }
}
