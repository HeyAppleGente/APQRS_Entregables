package Pruebas;

import Controlador.BloqueDAO;
import Modelo.Bloque;
import java.util.List;

public class PruebaListarBloque {

    public static void main(String[] args) {
        BloqueDAO dao = new BloqueDAO();

        List<Bloque> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Bloque bloque : lista) {
                System.out.println("ID: " + bloque.getIdBloque() + " | " + "Nombre: " + bloque.getNombreBloque());
            }
        }
    }
}
