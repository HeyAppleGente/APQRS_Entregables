package Pruebas;

import Controlador.NotificacionesDAO;
import Modelo.Notificaciones;
import java.util.Scanner;

public class PruebaConsultarNotificaciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NotificacionesDAO dao = new NotificacionesDAO();

        System.out.print("Ingrese el ID de la notificación a consultar: ");
        int busqueda = sc.nextInt();

        Notificaciones notificaciones = dao.consultar(busqueda);

        if (notificaciones != null) {
            System.out.println("ID: " + notificaciones.getIdNotificaciones());
            System.out.println("Titulo: " + notificaciones.getTitulo());
            System.out.println("Mensaje: " + notificaciones.getMensaje());
            System.out.println("Leido: " + notificaciones.isLeido());
            System.out.println("Fecha Envio: " + notificaciones.getFechaEnvio());
            System.out.println("ID Citas: " + notificaciones.getIdCitas());
            System.out.println("ID Tipo Notificacion: " + notificaciones.getIdTipoNotificacion());
            System.out.println("ID Pqrs: " + notificaciones.getIdPqrs());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
