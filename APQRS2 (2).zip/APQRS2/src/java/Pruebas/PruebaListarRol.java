package Pruebas;

import Controlador.RolDAO;
import Modelo.Rol;
import java.util.List;

public class PruebaListarRol {

    public static void main(String[] args) {
        RolDAO dao = new RolDAO();

        List<Rol> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Rol rol : lista) {
                System.out.println("ID: " + rol.getIdRol() + " | " + "Nombre: " + rol.getNombreRol());
            }
        }
    }
}
