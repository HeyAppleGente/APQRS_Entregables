package Pruebas;

import Controlador.PqrsDAO;
import Modelo.Pqrs;
import java.util.Scanner;

public class PruebaActualizarPqrs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        PqrsDAO dao = new PqrsDAO();

        System.out.print("Ingrese el ID del PQRS a actualizar: ");
        int busqueda = sc.nextInt();
        sc.nextLine();

        Pqrs pqrs = dao.consultar(busqueda);

        if (pqrs == null) {
            System.out.println("No se encontró el registro a actualizar.");
        } else {
            System.out.print("Ingrese nuevo/a asunto: ");
            String asunto = sc.nextLine();

            System.out.print("Ingrese nuevo/a descripción: ");
            String descripcion = sc.nextLine();

            System.out.print("Ingrese nuevo/a respuesta: ");
            String respuesta = sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del tipo de PQRS: ");
            int idTipoPqrs = sc.nextInt();
            sc.nextLine();

            System.out.print("Ingrese nuevo/a ID del usuario: ");
            int idUsuario = sc.nextInt();
            sc.nextLine();

            pqrs.setAsunto(asunto);
            pqrs.setDescripcion(descripcion);
            pqrs.setRespuesta(respuesta);
            pqrs.setIdTipoPqrs(idTipoPqrs);
            pqrs.setIdUsuario(idUsuario);

            boolean exito = dao.actualizar(pqrs);
            System.out.println(exito ? "Registro actualizado correctamente." : "No se pudo actualizar el registro.");
        }

        sc.close();
    }
}
