package Pruebas;

import Controlador.SeguimientoDAO;
import Modelo.Seguimiento;
import java.util.Scanner;

public class PruebaConsultarSeguimiento {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SeguimientoDAO dao = new SeguimientoDAO();

        System.out.print("Ingrese el ID del seguimiento a consultar: ");
        int busqueda = sc.nextInt();

        Seguimiento seguimiento = dao.consultar(busqueda);

        if (seguimiento != null) {
            System.out.println("ID: " + seguimiento.getIdSeguimiento());
            System.out.println("Comentario: " + seguimiento.getComentario());
            System.out.println("Fecha Registro: " + seguimiento.getFechaRegistro());
            System.out.println("ID Citas: " + seguimiento.getIdCitas());
            System.out.println("ID Usuario: " + seguimiento.getIdUsuario());
            System.out.println("ID Pqrs: " + seguimiento.getIdPqrs());
        } else {
            System.out.println("No se encontró el registro consultado.");
        }

        sc.close();
    }
}
