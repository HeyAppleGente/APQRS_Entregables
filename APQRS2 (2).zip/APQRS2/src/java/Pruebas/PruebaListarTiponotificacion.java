package Pruebas;

import Controlador.TiponotificacionDAO;
import Modelo.Tiponotificacion;
import java.util.List;

public class PruebaListarTiponotificacion {

    public static void main(String[] args) {
        TiponotificacionDAO dao = new TiponotificacionDAO();

        List<Tiponotificacion> lista = dao.listarTodos();

        if (lista.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Tiponotificacion tiponotificacion : lista) {
                System.out.println("ID: " + tiponotificacion.getIdTipoNotificacion() + " | " + "Nombre: " + tiponotificacion.getNombreTipoNotificacion());
            }
        }
    }
}
