package Modelo;

public class Tiponotificacion {

    private int idTipoNotificacion;
    private String nombreTipoNotificacion;

    public int getIdTipoNotificacion() {
        return idTipoNotificacion;
    }

    public void setIdTipoNotificacion(int idTipoNotificacion) {
        this.idTipoNotificacion = idTipoNotificacion;
    }

    public String getNombreTipoNotificacion() {
        return nombreTipoNotificacion;
    }

    public void setNombreTipoNotificacion(String nombreTipoNotificacion) {
        this.nombreTipoNotificacion = nombreTipoNotificacion;
    }
}
