package Modelo;

public class TipoPqrs {

    private int idTipoPqrs;
    // OJO: en la tabla la columna se llama " nombre_tipo_pqrs" (con espacio inicial),
    // así viene definida en el esquema. Revisa BD.sql si quieres corregirla.
    private String nombreTipoPqrs;
    private int diasPlazo; // días hábiles que tiene administración para responder

    public int getIdTipoPqrs() {
        return idTipoPqrs;
    }

    public void setIdTipoPqrs(int idTipoPqrs) {
        this.idTipoPqrs = idTipoPqrs;
    }

    public String getNombreTipoPqrs() {
        return nombreTipoPqrs;
    }

    public void setNombreTipoPqrs(String nombreTipoPqrs) {
        this.nombreTipoPqrs = nombreTipoPqrs;
    }

    public int getDiasPlazo() {
        return diasPlazo;
    }

    public void setDiasPlazo(int diasPlazo) {
        this.diasPlazo = diasPlazo;
    }
}
