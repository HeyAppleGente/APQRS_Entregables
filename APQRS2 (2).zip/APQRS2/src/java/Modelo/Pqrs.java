package Modelo;

import java.sql.Timestamp;

public class Pqrs {

    private int idPqrs;
    private String asunto;
    private String descripcion;
    private String respuesta;
    private Timestamp fechaRegistro;
    private Timestamp fechaRespuesta;
    private int idTipoPqrs; // TipoPqrs_id_tipo_pqrs
    private int idUsuario;  // Usuario_idUsuario

    public int getIdPqrs() {
        return idPqrs;
    }

    public void setIdPqrs(int idPqrs) {
        this.idPqrs = idPqrs;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public Timestamp getFechaRespuesta() {
        return fechaRespuesta;
    }

    public void setFechaRespuesta(Timestamp fechaRespuesta) {
        this.fechaRespuesta = fechaRespuesta;
    }

    public int getIdTipoPqrs() {
        return idTipoPqrs;
    }

    public void setIdTipoPqrs(int idTipoPqrs) {
        this.idTipoPqrs = idTipoPqrs;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}
