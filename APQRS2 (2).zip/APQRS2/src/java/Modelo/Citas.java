package Modelo;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

public class Citas {

    private int idCitas;
    private Date fecha;
    private Time hora;
    private String observaciones;
    private String respuesta;
    private Timestamp fechaCreacion;
    private Timestamp fechaRespuesta;
    private int idUsuario;   // Usuario_idUsuario
    private int idTipoCita;  // TIPOCITA_id_tipo_cita
    private Integer idPqrs;          // PQRS_id_pqrs (nullable: la cita puede no estar ligada a ninguna PQRS)
    private boolean notificadaResidente; // si el residente ya vio esta cita en su panel
    private boolean cancelada;
    private String asistencia; // null = sin marcar, "Asistio", "Inasistencia"
    private boolean reprogramacionSolicitada;
    private String mensajeReprogramacion;

    public int getIdCitas() {
        return idCitas;
    }

    public void setIdCitas(int idCitas) {
        this.idCitas = idCitas;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Time getHora() {
        return hora;
    }

    public void setHora(Time hora) {
        this.hora = hora;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public Timestamp getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Timestamp fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Timestamp getFechaRespuesta() {
        return fechaRespuesta;
    }

    public void setFechaRespuesta(Timestamp fechaRespuesta) {
        this.fechaRespuesta = fechaRespuesta;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdTipoCita() {
        return idTipoCita;
    }

    public void setIdTipoCita(int idTipoCita) {
        this.idTipoCita = idTipoCita;
    }

    public Integer getIdPqrs() {
        return idPqrs;
    }

    public void setIdPqrs(Integer idPqrs) {
        this.idPqrs = idPqrs;
    }

    public boolean isNotificadaResidente() {
        return notificadaResidente;
    }

    public void setNotificadaResidente(boolean notificadaResidente) {
        this.notificadaResidente = notificadaResidente;
    }

    public boolean isCancelada() {
        return cancelada;
    }

    public void setCancelada(boolean cancelada) {
        this.cancelada = cancelada;
    }

    public String getAsistencia() {
        return asistencia;
    }

    public void setAsistencia(String asistencia) {
        this.asistencia = asistencia;
    }

    public boolean isReprogramacionSolicitada() {
        return reprogramacionSolicitada;
    }

    public void setReprogramacionSolicitada(boolean reprogramacionSolicitada) {
        this.reprogramacionSolicitada = reprogramacionSolicitada;
    }

    public String getMensajeReprogramacion() {
        return mensajeReprogramacion;
    }

    public void setMensajeReprogramacion(String mensajeReprogramacion) {
        this.mensajeReprogramacion = mensajeReprogramacion;
    }
}
