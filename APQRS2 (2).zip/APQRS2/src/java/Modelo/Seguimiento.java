package Modelo;

import java.sql.Timestamp;

public class Seguimiento {

    private int idSeguimiento;
    private String comentario;
    private Timestamp fechaRegistro;
    private int idCitas;   // Citas_id_citas
    private int idUsuario; // Usuario_idUsuario
    private int idPqrs;    // PQRS_id_pqrs

    public int getIdSeguimiento() {
        return idSeguimiento;
    }

    public void setIdSeguimiento(int idSeguimiento) {
        this.idSeguimiento = idSeguimiento;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Timestamp getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(Timestamp fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public int getIdCitas() {
        return idCitas;
    }

    public void setIdCitas(int idCitas) {
        this.idCitas = idCitas;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public int getIdPqrs() {
        return idPqrs;
    }

    public void setIdPqrs(int idPqrs) {
        this.idPqrs = idPqrs;
    }
}
