package Modelo;

import java.sql.Time;

public class ConfiguracionAgenda {

    private int idConfiguracion;
    private Time horaInicio;
    private Time horaFin;
    private int duracionSlotMinutos;
    private String diasLaborales; // ej: "1,2,3,4,5,6" (1=lunes ... 7=domingo)

    public int getIdConfiguracion() {
        return idConfiguracion;
    }

    public void setIdConfiguracion(int idConfiguracion) {
        this.idConfiguracion = idConfiguracion;
    }

    public Time getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Time horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Time getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Time horaFin) {
        this.horaFin = horaFin;
    }

    public int getDuracionSlotMinutos() {
        return duracionSlotMinutos;
    }

    public void setDuracionSlotMinutos(int duracionSlotMinutos) {
        this.duracionSlotMinutos = duracionSlotMinutos;
    }

    public String getDiasLaborales() {
        return diasLaborales;
    }

    public void setDiasLaborales(String diasLaborales) {
        this.diasLaborales = diasLaborales;
    }

    /** true si el día (1=lunes...7=domingo, como java.time.DayOfWeek.getValue()) es laboral. */
    public boolean esDiaLaboral(int diaSemana) {
        if (diasLaborales == null) {
            return true;
        }
        for (String d : diasLaborales.split(",")) {
            if (d.trim().equals(String.valueOf(diaSemana))) {
                return true;
            }
        }
        return false;
    }
}
