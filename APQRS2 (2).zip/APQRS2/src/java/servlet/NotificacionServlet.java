package servlet;

import Controlador.NotificacionesDAO;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "NotificacionServlet", urlPatterns = {"/NotificacionServlet"})
public class NotificacionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (usuario == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }

        if ("marcarTodas".equals(request.getParameter("accion")) && usuario.getIdRol() == 1) {
            new NotificacionesDAO().marcarTodasLeidasParaAdmin();
        }

        // Vuelve a la página desde la que se llamó (o al panel general si no hay referer).
        String referer = request.getHeader("Referer");
        response.sendRedirect(referer != null ? referer : contextPath + "/Vista/menuAdmin.jsp");
    }
}
