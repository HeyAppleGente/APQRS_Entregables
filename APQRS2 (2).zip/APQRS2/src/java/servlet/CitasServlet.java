package servlet;

import Controlador.CitasDAO;
import Controlador.PqrsDAO;
import Controlador.SeguimientoDAO;
import Controlador.UsuarioDAO;
import Modelo.Citas;
import Modelo.Pqrs;
import Modelo.Seguimiento;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


 
@WebServlet(name = "CitasServlet", urlPatterns = {"/CitasServlet"})
public class CitasServlet extends HttpServlet {

    // Franja de atención configurable (ver Modelo.ConfiguracionAgenda / accion=disponibilidad)

    private List<Time> generarSlots() {
        Modelo.ConfiguracionAgenda config = new Controlador.ConfiguracionAgendaDAO().obtener();
        List<Time> slots = new ArrayList<>();
        LocalTime actual = config.getHoraInicio().toLocalTime();
        LocalTime fin = config.getHoraFin().toLocalTime();
        int intervalo = config.getDuracionSlotMinutos();
        while (actual.isBefore(fin)) {
            slots.add(Time.valueOf(actual.toString().length() == 5 ? actual + ":00" : actual.toString()));
            actual = actual.plusMinutes(intervalo);
        }
        return slots;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (usuario == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }

        CitasDAO dao = new CitasDAO();
        String accion = request.getParameter("accion");
        boolean esAdmin = usuario.getIdRol() == 1;

        // ---------- Calendario mensual (solo administrador) ----------
        if ("calendario".equals(accion)) {
            if (!esAdmin) {
                response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
                return;
            }
            YearMonth mes;
            try {
                mes = (request.getParameter("mes") != null)
                        ? YearMonth.parse(request.getParameter("mes")) : YearMonth.now();
            } catch (Exception e) {
                mes = YearMonth.now();
            }

            Map<Integer, Integer> citasPorDia = new HashMap<>();
            for (Citas c : dao.listarTodos()) {
                if (c.getFecha() == null || c.isCancelada()) continue;
                LocalDate f = c.getFecha().toLocalDate();
                if (f.getYear() == mes.getYear() && f.getMonthValue() == mes.getMonthValue()) {
                    citasPorDia.merge(f.getDayOfMonth(), 1, Integer::sum);
                }
            }

            request.setAttribute("mesActual", mes);
            request.setAttribute("citasPorDia", citasPorDia);
            request.setAttribute("idPqrs", request.getParameter("idPqrs"));
            request.getRequestDispatcher("/Vista/calendarioCitas.jsp").forward(request, response);
            return;
        }

        // ---------- Editar una cita existente (solo administrador) ----------
        if ("editar".equals(accion)) {
            if (!esAdmin) {
                response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
                return;
            }
            int idCitas;
            try {
                idCitas = Integer.parseInt(request.getParameter("id"));
            } catch (Exception e) {
                response.sendRedirect(contextPath + "/CitasServlet?vista=admin");
                return;
            }
            Citas cita = dao.consultar(idCitas);
            if (cita == null || cita.isCancelada()) {
                response.sendRedirect(contextPath + "/CitasServlet?vista=admin");
                return;
            }

            // Se puede cambiar de fecha: si viene el parámetro "fecha" se usa esa
            // (para recalcular disponibilidad), si no, la fecha actual de la cita.
            LocalDate fechaConsulta;
            try {
                fechaConsulta = (request.getParameter("fecha") != null)
                        ? LocalDate.parse(request.getParameter("fecha")) : cita.getFecha().toLocalDate();
            } catch (Exception e) {
                fechaConsulta = cita.getFecha().toLocalDate();
            }
            Date fechaSql = Date.valueOf(fechaConsulta);

            List<Time> ocupadas = dao.horasOcupadas(fechaSql);
            List<Time> todosSlots = generarSlots();
            // Si la fecha consultada es la misma que ya tenía la cita, su propia
            // hora actual no debe verse como "ocupada" (es ella misma).
            if (fechaConsulta.equals(cita.getFecha().toLocalDate())) {
                ocupadas = new ArrayList<>(ocupadas);
                ocupadas.remove(cita.getHora());
            }

            Usuario titular = new UsuarioDAO().consultar(cita.getIdUsuario());
            request.setAttribute("citaEditar", cita);
            request.setAttribute("titular", titular);
            request.setAttribute("fechaConsulta", fechaConsulta.toString());
            request.setAttribute("todosSlots", todosSlots);
            request.setAttribute("horasOcupadas", ocupadas);
            request.setAttribute("tiposCita", new Controlador.TipocitaDAO().listarTodos());
            request.getRequestDispatcher("/Vista/editarCita.jsp").forward(request, response);
            return;
        }

        // ---------- Vista de un día: ocupación + formulario para agendar (solo admin) ----------
        if ("dia".equals(accion)) {
            if (!esAdmin) {
                response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
                return;
            }
            String fechaStr = request.getParameter("fecha");
            LocalDate fechaLocal;
            try {
                fechaLocal = LocalDate.parse(fechaStr);
            } catch (Exception e) {
                response.sendRedirect(contextPath + "/CitasServlet?accion=calendario");
                return;
            }
            Date fecha = Date.valueOf(fechaLocal);

            List<Citas> citasDelDia = dao.listarPorFecha(fecha);
            List<Time> ocupadas = dao.horasOcupadas(fecha);
            List<Time> todosSlots = generarSlots();

            UsuarioDAO usuarioDAO = new UsuarioDAO();
            request.setAttribute("citasDelDia", citasDelDia);
            request.setAttribute("todosSlots", todosSlots);
            request.setAttribute("horasOcupadas", ocupadas);
            request.setAttribute("fechaSeleccionada", fechaStr);
            request.setAttribute("residentes", usuarioDAO.listarPorRol(2));
            request.setAttribute("tiposCita", new Controlador.TipocitaDAO().listarTodos());

            String idPqrsParam = request.getParameter("idPqrs");
            if (idPqrsParam != null && !idPqrsParam.isEmpty()) {
                try {
                    Pqrs pqrs = new PqrsDAO().consultar(Integer.parseInt(idPqrsParam));
                    request.setAttribute("pqrsAsociada", pqrs);
                } catch (Exception ignored) {
                }
            }

            request.getRequestDispatcher("/Vista/calendarioCitas.jsp").forward(request, response);
            return;
        }

        // ---------- Panel "Control de Citas Presenciales" (admin) ----------
        if ("admin".equals(request.getParameter("vista")) && esAdmin) {
            String msg = request.getParameter("msg");
            if ("actualizada".equals(msg)) {
                request.setAttribute("mensaje", "Cita reprogramada con éxito.");
            } else if ("cancelada".equals(msg)) {
                request.setAttribute("mensaje", "Cita cancelada.");
            } else if ("asistencia".equals(msg)) {
                request.setAttribute("mensaje", "Asistencia registrada.");
            } else if ("disponibilidad".equals(msg)) {
                request.setAttribute("mensaje", "Disponibilidad actualizada.");
            }

            String tab = request.getParameter("tab");
            if (tab == null) tab = "hoy";
            request.setAttribute("tab", tab);

            List<Citas> todas = dao.listarTodos();
            LocalDate hoy = LocalDate.now();

            List<Citas> citasHoy = new ArrayList<>();
            List<Citas> citasProximas = new ArrayList<>();
            int contadorSemana = 0;
            int asistieron = 0;
            int noAsistieron = 0;
            LocalDate finSemana = hoy.plusDays(7);

            for (Citas c : todas) {
                if (c.getFecha() == null || c.isCancelada()) continue;
                LocalDate f = c.getFecha().toLocalDate();
                if (f.isEqual(hoy)) {
                    citasHoy.add(c);
                } else if (f.isAfter(hoy)) {
                    citasProximas.add(c);
                }
                if (!f.isBefore(hoy) && f.isBefore(finSemana)) {
                    contadorSemana++;
                }
                if ("Asistio".equals(c.getAsistencia())) asistieron++;
                else if ("Inasistencia".equals(c.getAsistencia())) noAsistieron++;
            }
            citasHoy.sort((a, b) -> a.getHora().compareTo(b.getHora()));
            citasProximas.sort((a, b) -> a.getFecha().compareTo(b.getFecha()));

            int tasaAsistencia = (asistieron + noAsistieron) > 0
                    ? (int) Math.round((asistieron * 100.0) / (asistieron + noAsistieron)) : 100;

            request.setAttribute("citasHoy", citasHoy);
            request.setAttribute("citasProximas", citasProximas);
            request.setAttribute("totalCitasHoy", citasHoy.size());
            request.setAttribute("totalEstaSemana", contadorSemana);
            request.setAttribute("tasaAsistencia", tasaAsistencia);
            request.setAttribute("configAgenda", new Controlador.ConfiguracionAgendaDAO().obtener());
            request.getRequestDispatcher("/Vista/gestionCitas.jsp").forward(request, response);
            return;
        }

        // ---------- Configurar disponibilidad (admin) ----------
        if ("disponibilidad".equals(accion)) {
            if (!esAdmin) {
                response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
                return;
            }
            request.setAttribute("configAgenda", new Controlador.ConfiguracionAgendaDAO().obtener());
            request.getRequestDispatcher("/Vista/configurarDisponibilidad.jsp").forward(request, response);
            return;
        }

        // ---------- "Mis citas" del residente ----------
        List<Citas> misCitas = dao.listarPorUsuario(usuario.getIdUsuario());
        request.setAttribute("misCitas", misCitas);
        // Se marcan como vistas DESPUÉS de tomar la lista, así esta carga todavía
        // refleja cuáles eran nuevas (la vista se encarga de resaltarlas).
        dao.marcarNotificadas(usuario.getIdUsuario());
        request.getRequestDispatcher("/Vista/misCitas.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (usuario == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }

        String accion = request.getParameter("accion");
        CitasDAO dao = new CitasDAO();

        // ---------- El administrador agenda una cita ----------
        if ("crearAdmin".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
                return;
            }

            String fechaStr = request.getParameter("fecha");
            String horaStr = request.getParameter("hora");
            String observaciones = request.getParameter("observaciones");
            String idResidenteStr = request.getParameter("idUsuarioResidente");
            String idPqrsStr = request.getParameter("idPqrs");

            try {
                int idTipoCita = Integer.parseInt(request.getParameter("tipoCita"));
                Date fecha = Date.valueOf(fechaStr);
                Time hora = Time.valueOf(horaStr.length() == 5 ? horaStr + ":00" : horaStr);

                Integer idPqrs = null;
                Pqrs pqrs = null;
                if (idPqrsStr != null && !idPqrsStr.isEmpty()) {
                    idPqrs = Integer.parseInt(idPqrsStr);
                    pqrs = new PqrsDAO().consultar(idPqrs);
                }

                int idResidente;
                if (pqrs != null) {
                    idResidente = pqrs.getIdUsuario(); // la cita es para quien puso la PQRS
                } else if (idResidenteStr != null && !idResidenteStr.isEmpty()) {
                    idResidente = Integer.parseInt(idResidenteStr);
                } else {
                    request.setAttribute("error", "Debes seleccionar un residente o una PQRS.");
                    reenviarADia(request, response, dao, fechaStr);
                    return;
                }

                if (observaciones == null || observaciones.trim().isEmpty()) {
                    request.setAttribute("error", "Debes indicar el motivo de la cita.");
                    reenviarADia(request, response, dao, fechaStr);
                    return;
                }

                if (dao.horaOcupada(fecha, hora)) {
                    request.setAttribute("error", "Esa hora ya fue asignada a otra cita. Elige otra.");
                    reenviarADia(request, response, dao, fechaStr);
                    return;
                }

                Citas cita = new Citas();
                cita.setFecha(fecha);
                cita.setHora(hora);
                cita.setObservaciones(observaciones.trim());
                cita.setRespuesta("Cita confirmada por administración.");
                Timestamp ahora = new Timestamp(System.currentTimeMillis());
                cita.setFechaCreacion(ahora);
                cita.setFechaRespuesta(ahora);
                cita.setIdUsuario(idResidente);
                cita.setIdTipoCita(idTipoCita);
                cita.setIdPqrs(idPqrs);
                cita.setNotificadaResidente(false); // para que le aparezca la alerta al residente

                if (dao.insertar(cita)) {
                    // Trazabilidad: se registra en Seguimiento el agendamiento de esta cita
                    Citas creada = buscarCitaRecienCreada(dao, fecha, hora);
                    if (creada != null) {
                        Seguimiento seguimiento = new Seguimiento();
                        String motivo = (pqrs != null)
                                ? "Se agendó cita para atender la PQRS \"" + pqrs.getAsunto() + "\"."
                                : "Se agendó una cita general.";
                        seguimiento.setComentario(motivo.length() > 200 ? motivo.substring(0, 200) : motivo);
                        seguimiento.setFechaRegistro(ahora);
                        seguimiento.setIdCitas(creada.getIdCitas());
                        seguimiento.setIdUsuario(usuario.getIdUsuario());
                        seguimiento.setIdPqrs(idPqrs != null ? idPqrs : 0);
                        new SeguimientoDAO().insertar(seguimiento);
                    }
                    new Controlador.NotificacionesDAO().crear(
                            "Cita Agendada",
                            "Se agendó una cita para " + fecha + " a las " + horaStr.substring(0, 5)
                                    + (pqrs != null ? " (relacionada con PQRS: \"" + pqrs.getAsunto() + "\")." : "."),
                            2, creada != null ? creada.getIdCitas() : null, idPqrs);
                    response.sendRedirect(contextPath + "/CitasServlet?accion=dia&fecha=" + fechaStr + "&msg=agendada");
                } else {
                    request.setAttribute("error", "No se pudo guardar la cita. Inténtalo de nuevo.");
                    reenviarADia(request, response, dao, fechaStr);
                }
            } catch (Exception e) {
                request.setAttribute("error", "Datos de la cita no válidos: " + e.getMessage());
                reenviarADia(request, response, dao, fechaStr);
            }
            return;

        } else if ("actualizarAdmin".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/login.jsp");
                return;
            }
            int idCitas;
            try {
                idCitas = Integer.parseInt(request.getParameter("idCitas"));
            } catch (Exception e) {
                response.sendRedirect(contextPath + "/CitasServlet?vista=admin");
                return;
            }
            Citas cita = dao.consultar(idCitas);
            if (cita == null || cita.isCancelada()) {
                response.sendRedirect(contextPath + "/CitasServlet?vista=admin");
                return;
            }

            String fechaStr = request.getParameter("fecha");
            String horaStr = request.getParameter("hora");
            String observaciones = request.getParameter("observaciones");

            try {
                int idTipoCita = Integer.parseInt(request.getParameter("tipoCita"));
                Date fecha = Date.valueOf(fechaStr);
                Time hora = Time.valueOf(horaStr.length() == 5 ? horaStr + ":00" : horaStr);

                if (observaciones == null || observaciones.trim().isEmpty()) {
                    request.setAttribute("error", "Debes indicar el motivo de la cita.");
                    reenviarAEditar(request, response, dao, cita, fechaStr);
                    return;
                }
                if (dao.horaOcupada(fecha, hora, idCitas)) {
                    request.setAttribute("error", "Esa hora ya fue asignada a otra cita. Elige otra.");
                    reenviarAEditar(request, response, dao, cita, fechaStr);
                    return;
                }

                String fechaAnterior = cita.getFecha().toString();
                String horaAnterior = cita.getHora().toString().substring(0, 5);

                cita.setFecha(fecha);
                cita.setHora(hora);
                cita.setIdTipoCita(idTipoCita);
                cita.setObservaciones(observaciones.trim());
                cita.setNotificadaResidente(false); // para que el residente vea que cambió

                if (dao.actualizar(cita)) {
                    dao.limpiarSolicitudReprogramacion(idCitas);

                    Seguimiento seguimiento = new Seguimiento();
                    String comentario = "Se reprogramó la cita: de " + fechaAnterior + " " + horaAnterior
                            + " a " + fecha + " " + horaStr.substring(0, 5) + ".";
                    seguimiento.setComentario(comentario.length() > 200 ? comentario.substring(0, 200) : comentario);
                    seguimiento.setFechaRegistro(new Timestamp(System.currentTimeMillis()));
                    seguimiento.setIdCitas(idCitas);
                    seguimiento.setIdUsuario(usuario.getIdUsuario());
                    seguimiento.setIdPqrs(cita.getIdPqrs() != null ? cita.getIdPqrs() : 0);
                    new SeguimientoDAO().insertar(seguimiento);

                    response.sendRedirect(contextPath + "/CitasServlet?vista=admin&msg=actualizada");
                } else {
                    request.setAttribute("error", "No se pudo actualizar la cita.");
                    reenviarAEditar(request, response, dao, cita, fechaStr);
                }
            } catch (Exception e) {
                request.setAttribute("error", "Datos no válidos: " + e.getMessage());
                reenviarAEditar(request, response, dao, cita, fechaStr);
            }
            return;

        } else if ("cancelar".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/login.jsp");
                return;
            }
            try {
                int idCitas = Integer.parseInt(request.getParameter("idCitas"));
                Citas cita = dao.consultar(idCitas);
                if (dao.cancelar(idCitas)) {
                    dao.limpiarSolicitudReprogramacion(idCitas);
                    Seguimiento seguimiento = new Seguimiento();
                    seguimiento.setComentario("Cita cancelada por administración.");
                    seguimiento.setFechaRegistro(new Timestamp(System.currentTimeMillis()));
                    seguimiento.setIdCitas(idCitas);
                    seguimiento.setIdUsuario(usuario.getIdUsuario());
                    seguimiento.setIdPqrs(cita != null && cita.getIdPqrs() != null ? cita.getIdPqrs() : 0);
                    new SeguimientoDAO().insertar(seguimiento);
                }
                response.sendRedirect(contextPath + "/CitasServlet?vista=admin&msg=cancelada");
            } catch (NumberFormatException e) {
                response.sendRedirect(contextPath + "/CitasServlet?vista=admin");
            }
            return;

        } else if ("responder".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/login.jsp");
                return;
            }
            String msgResultado = "actualizada";
            try {
                int idCitas = Integer.parseInt(request.getParameter("idCitas"));
                String respuesta = request.getParameter("respuesta");
                if (respuesta == null || respuesta.trim().isEmpty()) {
                    response.sendRedirect(contextPath + "/CitasServlet?vista=admin");
                    return;
                } else if (dao.responder(idCitas, respuesta.trim())) {
                    // Trazabilidad: se registra el seguimiento de esta cita
                    Citas cita = dao.consultar(idCitas);
                    if (cita != null) {
                        Seguimiento seguimiento = new Seguimiento();
                        String comentario = respuesta.trim();
                        seguimiento.setComentario(comentario.length() > 200 ? comentario.substring(0, 200) : comentario);
                        seguimiento.setFechaRegistro(new Timestamp(System.currentTimeMillis()));
                        seguimiento.setIdCitas(idCitas);
                        seguimiento.setIdUsuario(usuario.getIdUsuario());
                        seguimiento.setIdPqrs(cita.getIdPqrs() != null ? cita.getIdPqrs() : 0);
                        new SeguimientoDAO().insertar(seguimiento);
                    }
                }
            } catch (NumberFormatException e) {
                // id no válido: se ignora y simplemente se vuelve al panel
            }
            response.sendRedirect(contextPath + "/CitasServlet?vista=admin&msg=" + msgResultado);
            return;

        } else if ("asistencia".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/login.jsp");
                return;
            }
            try {
                int idCitas = Integer.parseInt(request.getParameter("idCitas"));
                String valor = request.getParameter("valor"); // "Asistio" | "Inasistencia"
                dao.marcarAsistencia(idCitas, valor);

                Seguimiento seguimiento = new Seguimiento();
                Citas cita = dao.consultar(idCitas);
                seguimiento.setComentario("Asistio".equals(valor)
                        ? "El residente asistió a la cita." : "El residente NO asistió a la cita.");
                seguimiento.setFechaRegistro(new Timestamp(System.currentTimeMillis()));
                seguimiento.setIdCitas(idCitas);
                seguimiento.setIdUsuario(usuario.getIdUsuario());
                seguimiento.setIdPqrs(cita != null && cita.getIdPqrs() != null ? cita.getIdPqrs() : 0);
                new SeguimientoDAO().insertar(seguimiento);
            } catch (Exception ignored) {
            }
            String tabVolver = request.getParameter("tab");
            response.sendRedirect(contextPath + "/CitasServlet?vista=admin&msg=asistencia"
                    + (tabVolver != null ? "&tab=" + tabVolver : ""));
            return;

        } else if ("guardarDisponibilidad".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/login.jsp");
                return;
            }
            try {
                Modelo.ConfiguracionAgenda config = new Modelo.ConfiguracionAgenda();
                String horaInicioStr = request.getParameter("horaInicio");
                String horaFinStr = request.getParameter("horaFin");
                config.setHoraInicio(Time.valueOf(horaInicioStr.length() == 5 ? horaInicioStr + ":00" : horaInicioStr));
                config.setHoraFin(Time.valueOf(horaFinStr.length() == 5 ? horaFinStr + ":00" : horaFinStr));
                config.setDuracionSlotMinutos(Integer.parseInt(request.getParameter("duracionSlot")));

                String[] dias = request.getParameterValues("dias");
                config.setDiasLaborales(dias != null ? String.join(",", dias) : "1,2,3,4,5,6");

                new Controlador.ConfiguracionAgendaDAO().actualizar(config);
                response.sendRedirect(contextPath + "/CitasServlet?vista=admin&tab=horario&msg=disponibilidad");
            } catch (Exception e) {
                request.setAttribute("error", "Datos de disponibilidad no válidos: " + e.getMessage());
                request.setAttribute("configAgenda", new Controlador.ConfiguracionAgendaDAO().obtener());
                request.getRequestDispatcher("/Vista/configurarDisponibilidad.jsp").forward(request, response);
            }
            return;

        } else if ("solicitarReprogramacion".equals(accion)) {
            try {
                int idCitas = Integer.parseInt(request.getParameter("idCitas"));
                Citas cita = dao.consultar(idCitas);
                // Solo el dueño de la cita puede pedir reprogramarla, y solo si sigue vigente.
                if (cita == null || cita.getIdUsuario() != usuario.getIdUsuario() || cita.isCancelada()) {
                    response.sendRedirect(contextPath + "/CitasServlet");
                    return;
                }
                String mensaje = request.getParameter("mensaje");
                if (mensaje == null || mensaje.trim().isEmpty()) {
                    request.setAttribute("error", "Debes indicar el motivo por el que necesitas cambiar la cita.");
                    request.setAttribute("misCitas", dao.listarPorUsuario(usuario.getIdUsuario()));
                    dao.marcarNotificadas(usuario.getIdUsuario());
                    request.getRequestDispatcher("/Vista/misCitas.jsp").forward(request, response);
                    return;
                }

                String mensajeRecortado = mensaje.trim().length() > 300 ? mensaje.trim().substring(0, 300) : mensaje.trim();
                dao.solicitarReprogramacion(idCitas, mensajeRecortado);

                Seguimiento seguimiento = new Seguimiento();
                seguimiento.setComentario("El residente solicitó reprogramar esta cita: " + mensajeRecortado);
                seguimiento.setFechaRegistro(new Timestamp(System.currentTimeMillis()));
                seguimiento.setIdCitas(idCitas);
                seguimiento.setIdUsuario(usuario.getIdUsuario());
                seguimiento.setIdPqrs(cita.getIdPqrs() != null ? cita.getIdPqrs() : 0);
                new SeguimientoDAO().insertar(seguimiento);

                new Controlador.NotificacionesDAO().crear(
                        "Solicitud de reprogramación",
                        usuario.getNombre() + " " + usuario.getApellido() + " pidió reprogramar su cita del "
                                + cita.getFecha() + " a las " + cita.getHora().toString().substring(0, 5)
                                + ": \"" + mensajeRecortado + "\".",
                        2, idCitas, cita.getIdPqrs());

                request.setAttribute("mensaje", "Tu solicitud fue enviada. Administración se pondrá en contacto para reprogramar.");
                request.setAttribute("misCitas", dao.listarPorUsuario(usuario.getIdUsuario()));
                dao.marcarNotificadas(usuario.getIdUsuario());
                request.getRequestDispatcher("/Vista/misCitas.jsp").forward(request, response);
            } catch (Exception e) {
                response.sendRedirect(contextPath + "/CitasServlet");
            }
            return;
        }

        response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
    }

    /** Reenvía al formulario de edición tras un error, recalculando la disponibilidad. */
    private void reenviarAEditar(HttpServletRequest request, HttpServletResponse response, CitasDAO dao, Citas cita, String fechaStr)
            throws ServletException, IOException {
        try {
            LocalDate fechaConsulta = LocalDate.parse(fechaStr);
            Date fechaSql = Date.valueOf(fechaConsulta);
            List<Time> ocupadas = dao.horasOcupadas(fechaSql);
            if (fechaConsulta.equals(cita.getFecha().toLocalDate())) {
                ocupadas = new ArrayList<>(ocupadas);
                ocupadas.remove(cita.getHora());
            }
            request.setAttribute("citaEditar", cita);
            request.setAttribute("titular", new UsuarioDAO().consultar(cita.getIdUsuario()));
            request.setAttribute("fechaConsulta", fechaStr);
            request.setAttribute("todosSlots", generarSlots());
            request.setAttribute("horasOcupadas", ocupadas);
            request.setAttribute("tiposCita", new Controlador.TipocitaDAO().listarTodos());
        } catch (Exception ignored) {
        }
        request.getRequestDispatcher("/Vista/editarCita.jsp").forward(request, response);
    }

    /** Reenvía a la vista de día tras un error, recalculando la disponibilidad. */
    private void reenviarADia(HttpServletRequest request, HttpServletResponse response, CitasDAO dao, String fechaStr)
            throws ServletException, IOException {
        try {
            Date fecha = Date.valueOf(fechaStr);
            request.setAttribute("citasDelDia", dao.listarPorFecha(fecha));
            request.setAttribute("todosSlots", generarSlots());
            request.setAttribute("horasOcupadas", dao.horasOcupadas(fecha));
            request.setAttribute("fechaSeleccionada", fechaStr);
            request.setAttribute("residentes", new UsuarioDAO().listarPorRol(2));
            request.setAttribute("tiposCita", new Controlador.TipocitaDAO().listarTodos());
            String idPqrsStr = request.getParameter("idPqrs");
            if (idPqrsStr != null && !idPqrsStr.isEmpty()) {
                request.setAttribute("pqrsAsociada", new PqrsDAO().consultar(Integer.parseInt(idPqrsStr)));
            }
        } catch (Exception ignored) {
        }
        request.getRequestDispatcher("/Vista/calendarioCitas.jsp").forward(request, response);
    }

    /** Busca la cita recién insertada por fecha+hora (únicas por restricción de negocio). */
    private Citas buscarCitaRecienCreada(CitasDAO dao, Date fecha, Time hora) {
        for (Citas c : dao.listarPorFecha(fecha)) {
            if (c.getHora().equals(hora)) {
                return c;
            }
        }
        return null;
    }
}
