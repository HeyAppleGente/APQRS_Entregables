package servlet;

import Controlador.PasswordUtil;
import Controlador.UsuarioDAO;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "PerfilServlet", urlPatterns = {"/PerfilServlet"})
public class PerfilServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (usuario == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }

        UsuarioDAO dao = new UsuarioDAO();
        Usuario actual = dao.consultar(usuario.getIdUsuario());
        if (actual == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }

        String telefono = request.getParameter("telefono");
        String nuevaPassword = request.getParameter("nuevaPassword");
        String confirmarPassword = request.getParameter("confirmarPassword");

        if (telefono != null && !telefono.trim().isEmpty()) {
            actual.setTelefono(telefono.trim());
        }

        if (nuevaPassword != null && !nuevaPassword.trim().isEmpty()) {
            if (nuevaPassword.length() < 6) {
                request.setAttribute("error", "La nueva contraseña debe tener al menos 6 caracteres.");
                request.setAttribute("usuarioActual", actual);
                request.getRequestDispatcher("/Vista/perfil.jsp").forward(request, response);
                return;
            }
            if (!nuevaPassword.equals(confirmarPassword)) {
                request.setAttribute("error", "Las contraseñas no coinciden.");
                request.setAttribute("usuarioActual", actual);
                request.getRequestDispatcher("/Vista/perfil.jsp").forward(request, response);
                return;
            }
            actual.setContrasena(PasswordUtil.hash(nuevaPassword));
        }

        if (dao.actualizar(actual)) {
            session.setAttribute("usuario", actual); // refresca los datos en sesión
            request.setAttribute("mensaje", "Tus datos se actualizaron correctamente.");
        } else {
            request.setAttribute("error", "No se pudo actualizar tu perfil. Inténtalo de nuevo.");
        }
        request.setAttribute("usuarioActual", actual);
        request.getRequestDispatcher("/Vista/perfil.jsp").forward(request, response);
    }
}
