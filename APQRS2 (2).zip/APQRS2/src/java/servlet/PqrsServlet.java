package servlet;

import Controlador.PqrsDAO;
import Controlador.TipoPqrsDAO;
import Modelo.Pqrs;
import Modelo.TipoPqrs;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Timestamp;



@WebServlet(name = "PqrsServlet", urlPatterns = {"/PqrsServlet"})
public class PqrsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (usuario == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }

        String accion = request.getParameter("accion");
        PqrsDAO dao = new PqrsDAO();

        if ("crear".equals(accion)) {
            try {
                int idTipoPqrs = Integer.parseInt(request.getParameter("tipoPqrs"));
                String asunto = request.getParameter("asunto");
                String descripcion = request.getParameter("descripcion");

                if (asunto == null || asunto.trim().isEmpty()
                        || descripcion == null || descripcion.trim().isEmpty()) {
                    request.setAttribute("error", "Debes completar el asunto y la descripción.");
                } else {
                    Pqrs pqrs = new Pqrs();
                    pqrs.setAsunto(asunto.trim());
                    pqrs.setDescripcion(descripcion.trim());
                
                    pqrs.setRespuesta("");
                    Timestamp ahora = new Timestamp(System.currentTimeMillis());
                    pqrs.setFechaRegistro(ahora);
                    pqrs.setFechaRespuesta(ahora);
                    pqrs.setIdTipoPqrs(idTipoPqrs);
                    pqrs.setIdUsuario(usuario.getIdUsuario());

                    if (dao.insertar(pqrs)) {
                        request.setAttribute("mensaje", "Tu PQRS fue radicada con éxito.");
                        new Controlador.NotificacionesDAO().crear(
                                "Nueva PQRS",
                                usuario.getNombre() + " " + usuario.getApellido() + " ha registrado una nueva "
                                        + "solicitud: \"" + asunto.trim() + "\".",
                                1, null, null);
                    } else {
                        request.setAttribute("error", "No se pudo guardar la PQRS. Inténtalo de nuevo.");
                    }
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "Selecciona un tipo de PQRS válido.");
            } catch (Exception e) {
                request.setAttribute("error", "Ocurrió un error al radicar la PQRS: " + e.getMessage());
            }

            request.setAttribute("misPqrs", dao.listarPorUsuario(usuario.getIdUsuario()));
            request.getRequestDispatcher("/Vista/misPqrs.jsp").forward(request, response);
            return;

        } else if ("responder".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/login.jsp");
                return;
            }
            try {
                int idPqrs = Integer.parseInt(request.getParameter("idPqrs"));
                String respuesta = request.getParameter("respuesta");
                if (respuesta == null || respuesta.trim().isEmpty()) {
                    request.setAttribute("error", "La respuesta no puede estar vacía.");
                } else if (dao.responder(idPqrs, respuesta.trim())) {
                    request.setAttribute("mensaje", "Respuesta guardada correctamente.");
                } else {
                    request.setAttribute("error", "No se pudo guardar la respuesta.");
                }
            } catch (NumberFormatException e) {
                request.setAttribute("error", "PQRS no válida.");
            }

            request.setAttribute("todasPqrs", dao.listarTodos());
            request.getRequestDispatcher("/Vista/gestionPqrs.jsp").forward(request, response);
            return;

        } else if ("guardarPlazos".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/login.jsp");
                return;
            }
            TipoPqrsDAO tipoPqrsDAO = new TipoPqrsDAO();
            for (TipoPqrs tipo : tipoPqrsDAO.listarTodos()) {
                String diasParam = request.getParameter("dias_" + tipo.getIdTipoPqrs());
                try {
                    int dias = Integer.parseInt(diasParam);
                    if (dias > 0) {
                        tipoPqrsDAO.actualizarPlazo(tipo.getIdTipoPqrs(), dias);
                    }
                } catch (Exception ignored) {
                }
            }
            response.sendRedirect(contextPath + "/PqrsServlet?accion=plazos&msg=guardado");
            return;
        }

        response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Usuario usuario = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (usuario == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }

        PqrsDAO dao = new PqrsDAO();
        String vista = request.getParameter("vista");
        String accion = request.getParameter("accion");

        if ("plazos".equals(accion)) {
            if (usuario.getIdRol() != 1) {
                response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
                return;
            }
            if ("guardado".equals(request.getParameter("msg"))) {
                request.setAttribute("mensaje", "Plazos actualizados correctamente.");
            }
            request.setAttribute("tiposPqrs", new TipoPqrsDAO().listarTodos());
            request.getRequestDispatcher("/Vista/configurarPlazos.jsp").forward(request, response);
            return;
        }

        if ("admin".equals(vista) && usuario.getIdRol() == 1) {
            request.setAttribute("todasPqrs", dao.listarTodos());
            request.getRequestDispatcher("/Vista/gestionPqrs.jsp").forward(request, response);
        } else {
            request.setAttribute("misPqrs", dao.listarPorUsuario(usuario.getIdUsuario()));
            request.getRequestDispatcher("/Vista/misPqrs.jsp").forward(request, response);
        }
    }
}
