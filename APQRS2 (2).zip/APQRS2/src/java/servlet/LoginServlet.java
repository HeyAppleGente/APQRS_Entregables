package servlet;

import Controlador.PasswordUtil;
import Controlador.UsuarioDAO;
import Modelo.Usuario;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String contextPath = request.getContextPath();

        if (email == null || email.trim().isEmpty() || password == null || password.trim().isEmpty()) {
            response.sendRedirect(contextPath + "/Vista/login.jsp?error=vacio");
            return;
        }

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Usuario usuario = usuarioDAO.consultarPorCorreo(email.trim());

        boolean credencialesValidas = false;
        if (usuario != null) {
            if (PasswordUtil.pareceHasheada(usuario.getContrasena())) {
                credencialesValidas = PasswordUtil.matches(password, usuario.getContrasena());
            } else {
                // Contraseña antigua en texto plano (de antes de cifrar el sistema):
                // se valida como siempre, y si es correcta se migra a hash cifrado
                // de una vez, sin que el usuario tenga que hacer nada.
                credencialesValidas = usuario.getContrasena().equals(password);
                if (credencialesValidas) {
                    usuario.setContrasena(PasswordUtil.hash(password));
                    usuarioDAO.actualizar(usuario);
                }
            }
        }

        if (!credencialesValidas) {
            response.sendRedirect(contextPath + "/Vista/login.jsp?error=credenciales");
            return;
        }

        HttpSession session = request.getSession();
        session.setAttribute("usuario", usuario);

        
        if (usuario.getIdRol() == 1) {
            response.sendRedirect(contextPath + "/Vista/menuAdmin.jsp");
        } else {
            response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
    }
}
