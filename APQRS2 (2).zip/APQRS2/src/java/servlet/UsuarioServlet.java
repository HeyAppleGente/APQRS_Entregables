package servlet;

import Controlador.ApartamentoDAO;
import Controlador.BloqueDAO;
import Controlador.NotificacionesDAO;
import Controlador.UsuarioDAO;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * @author Aprendiz
 */
@WebServlet(name = "UsuarioServlet", urlPatterns = {"/UsuarioServlet"})
public class UsuarioServlet extends HttpServlet {

    // Torres 1, 10 y 32: solo tienen 2 apartamentos por piso (101, 102, 201, 202...
    // hasta el 5º piso), a diferencia del resto de torres.
    private static final List<String> TORRES_RESTRINGIDAS = Arrays.asList("1", "10", "32");
    private static final List<String> APARTAMENTOS_VALIDOS_RESTRINGIDOS = Arrays.asList(
            "101", "102", "201", "202", "301", "302", "401", "402", "501", "502");

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");

        try {
            int idTipoDocumento = Integer.parseInt(request.getParameter("tipoDocumento"));
            String documento = request.getParameter("numeroDocumento");
            String nombre = request.getParameter("nombre");
            String apellido = request.getParameter("apellido");
            String telefono = request.getParameter("telefono");
            String correo = request.getParameter("correo");
            String contrasena = request.getParameter("password");
            String tipoOcupante = request.getParameter("tipoOcupante");

            // La torre y el apartamento se escriben libremente (igual que en el
            // formulario del administrador): se buscan y, si no existen todavía
            // en la base de datos, se crean. Así queda guardada la unidad real
            // que el residente escribió, en vez de un índice fijo desconectado
            // de la tabla Apartamento.
            String torre = request.getParameter("torre");
            String numeroApartamento = request.getParameter("numeroApartamento");
            if (torre == null || torre.trim().isEmpty()
                    || numeroApartamento == null || numeroApartamento.trim().isEmpty()) {
                request.setAttribute("error", "Debes indicar la torre y el número de apartamento.");
                request.getRequestDispatcher("/Vista/registroUsuario.jsp").forward(request, response);
                return;
            }
            if (tipoOcupante == null || tipoOcupante.trim().isEmpty()) {
                tipoOcupante = "Propietario";
            }

            String torreNormalizada = torre.trim();
            String aptoNormalizado = numeroApartamento.trim();

            // Validación: las torres 1, 10 y 32 solo tienen 2 apartamentos por piso.
            if (TORRES_RESTRINGIDAS.contains(torreNormalizada)
                    && !APARTAMENTOS_VALIDOS_RESTRINGIDOS.contains(aptoNormalizado)) {
                request.setAttribute("error", "La torre " + torreNormalizada + " solo tiene 2 apartamentos por "
                        + "piso (101, 102, 201, 202, 301, 302, 401, 402, 501, 502). Revisa el número que ingresaste.");
                request.getRequestDispatcher("/Vista/registroUsuario.jsp").forward(request, response);
                return;
            }

            int idBloque = new BloqueDAO().buscarOcrear(torreNormalizada);
            int idApartamento = new ApartamentoDAO().buscarOcrear(aptoNormalizado, idBloque);

            Usuario usuario = new Usuario();
            usuario.setIdTipoDocumento(idTipoDocumento);
            usuario.setDocumento(documento);
            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setIdApartamento(idApartamento);
            usuario.setTelefono(telefono);
            usuario.setCorreo(correo);
            usuario.setContrasena(Controlador.PasswordUtil.hash(contrasena));
            usuario.setIdRol(2); // 2 = Residente (según tabla Rol: 1=Administrador, 2=Residente)
            usuario.setIdNotificaciones(1);
            usuario.setTipoOcupante(tipoOcupante);

            UsuarioDAO dao = new UsuarioDAO();

            if (dao.existeCorreoODocumento(correo, documento)) {
                request.setAttribute("error", "El correo o número de documento ya se encuentra registrado.");
            } else {
                boolean guardado = dao.registroUsuario(usuario);
                if (guardado) {
                    request.setAttribute("mensaje", "¡Cuenta de residente creada con éxito! Ya puedes iniciar sesión.");
                    Controlador.EmailService.enviarBienvenida(correo, nombre);
                    new NotificacionesDAO().crear(
                            "Nuevo Residente",
                            "Se ha registrado un nuevo residente: " + nombre + " " + apellido
                                    + " (Torre " + torreNormalizada + " - Apto " + aptoNormalizado + ", " + tipoOcupante + ").",
                            3, null, null);
                } else {
                    request.setAttribute("error", "Error interno al guardar los datos. Inténtalo de nuevo.");
                }
            }

        } catch (NumberFormatException e) {
            request.setAttribute("error", "Selección no válida en tipo de documento.");
        } catch (Exception e) {
            request.setAttribute("error", "Ocurrió un error al procesar la solicitud: " + e.getMessage());
        }

        // El JSP real está en Vista/registroUsuario.jsp
        request.getRequestDispatcher("/Vista/registroUsuario.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Redirección corregida al archivo real
        response.sendRedirect(request.getContextPath() + "/Vista/registroUsuario.jsp");
    }
}