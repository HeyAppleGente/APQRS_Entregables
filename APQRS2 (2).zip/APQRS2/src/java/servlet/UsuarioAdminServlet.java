package servlet;

import Controlador.ApartamentoDAO;
import Controlador.BloqueDAO;
import Controlador.CitasDAO;
import Controlador.PasswordUtil;
import Controlador.PqrsDAO;
import Controlador.TipoDocumentoDAO;
import Controlador.UsuarioDAO;
import Modelo.Apartamento;
import Modelo.Bloque;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Módulo de administración "Usuarios y Unidades".
 * Solo accesible para usuarios con rol de Administrador (idRol == 1).
 * Soporta CRUD completo sobre Usuario: crear, ver, editar y restablecer contraseña.
 */
@WebServlet(name = "UsuarioAdminServlet", urlPatterns = {"/UsuarioAdminServlet"})
public class UsuarioAdminServlet extends HttpServlet {

    private static final int RESULTADOS_POR_PAGINA = 5;
    private static final String CONTRASENA_POR_DEFECTO = "Residente123*";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Usuario admin = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (admin == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }
        if (admin.getIdRol() != 1) {
            response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
            return;
        }

        String accion = request.getParameter("accion");
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        if ("nuevo".equals(accion)) {
            cargarCatalogos(request);
            request.setAttribute("modo", "crear");
            request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
            return;
        }

        if ("editar".equals(accion)) {
            Usuario residente = obtenerUsuarioPorId(request, usuarioDAO);
            if (residente == null) {
                response.sendRedirect(contextPath + "/UsuarioAdminServlet");
                return;
            }
            cargarCatalogos(request);
            request.setAttribute("modo", "editar");
            request.setAttribute("residente", residente);
            request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
            return;
        }

        if ("ver".equals(accion)) {
            Usuario residente = obtenerUsuarioPorId(request, usuarioDAO);
            if (residente == null) {
                response.sendRedirect(contextPath + "/UsuarioAdminServlet");
                return;
            }
            Apartamento apto = new ApartamentoDAO().consultar(residente.getIdApartamento());
            Bloque bloque = (apto != null) ? new BloqueDAO().consultar(apto.getIdBloque()) : null;
            request.setAttribute("residente", residente);
            request.setAttribute("apto", apto);
            request.setAttribute("bloque", bloque);
            request.setAttribute("misPqrs", new PqrsDAO().listarPorUsuario(residente.getIdUsuario()));
            request.setAttribute("misCitas", new CitasDAO().listarPorUsuario(residente.getIdUsuario()));
            request.getRequestDispatcher("/Vista/verResidente.jsp").forward(request, response);
            return;
        }

        if ("exportar".equals(accion)) {
            exportarCSV(response, usuarioDAO);
            return;
        }

        // ---- Listado con búsqueda, filtro y paginación ----
        String q = request.getParameter("q");
        String estado = request.getParameter("estado");
        int pagina = 1;
        try {
            if (request.getParameter("pagina") != null) {
                pagina = Integer.parseInt(request.getParameter("pagina"));
            }
        } catch (NumberFormatException ignored) {
        }
        if (pagina < 1) {
            pagina = 1;
        }

        List<Usuario> residentes = usuarioDAO.listarPorRol(2);

        // Mapas de apoyo para no consultar la BD dentro del bucle de filtrado
        Map<Integer, Apartamento> apartamentos = new HashMap<>();
        for (Apartamento a : new ApartamentoDAO().listarTodos()) {
            apartamentos.put(a.getIdApartamento(), a);
        }
        Map<Integer, Bloque> bloques = new HashMap<>();
        for (Bloque b : new BloqueDAO().listarTodos()) {
            bloques.put(b.getIdBloque(), b);
        }

        List<Usuario> filtrados = new ArrayList<>();
        String qLower = (q != null) ? q.trim().toLowerCase() : "";
        for (Usuario u : residentes) {
            if (estado != null && !estado.isEmpty() && !"Todos".equalsIgnoreCase(estado)
                    && !estado.equalsIgnoreCase(u.getTipoOcupante())) {
                continue;
            }
            if (!qLower.isEmpty()) {
                Apartamento apto = apartamentos.get(u.getIdApartamento());
                Bloque bloque = (apto != null) ? bloques.get(apto.getIdBloque()) : null;
                String unidad = (bloque != null ? "Torre " + bloque.getNombreBloque() : "") + " Apto " + (apto != null ? apto.getNumero() : "");
                String haystack = (u.getNombre() + " " + u.getApellido() + " " + u.getCorreo() + " " + unidad).toLowerCase();
                if (!haystack.contains(qLower)) {
                    continue;
                }
            }
            filtrados.add(u);
        }

        int totalFiltrados = filtrados.size();
        int totalPaginas = Math.max(1, (int) Math.ceil(totalFiltrados / (double) RESULTADOS_POR_PAGINA));
        if (pagina > totalPaginas) {
            pagina = totalPaginas;
        }
        int desde = (pagina - 1) * RESULTADOS_POR_PAGINA;
        int hasta = Math.min(desde + RESULTADOS_POR_PAGINA, totalFiltrados);
        List<Usuario> pagina_residentes = (desde < hasta) ? filtrados.subList(desde, hasta) : new ArrayList<Usuario>();

        // ---- Métricas reales para las tarjetas superiores ----
        int totalResidentes = residentes.size();
        int propietarios = 0;
        int arrendatarios = 0;
        for (Usuario u : residentes) {
            if ("Arrendatario".equalsIgnoreCase(u.getTipoOcupante())) {
                arrendatarios++;
            } else {
                propietarios++;
            }
        }
        java.util.Set<Integer> apartamentosOcupados = new java.util.HashSet<>();
        for (Usuario u : residentes) {
            apartamentosOcupados.add(u.getIdApartamento());
        }
        int totalApartamentos = apartamentos.size();
        int porcentajeOcupacion = totalApartamentos > 0
                ? (int) Math.round((apartamentosOcupados.size() * 100.0) / totalApartamentos) : 0;

        request.setAttribute("residentes", pagina_residentes);
        request.setAttribute("apartamentos", apartamentos);
        request.setAttribute("bloques", bloques);
        request.setAttribute("totalResidentes", totalResidentes);
        request.setAttribute("propietarios", propietarios);
        request.setAttribute("arrendatarios", arrendatarios);
        request.setAttribute("porcentajeOcupacion", porcentajeOcupacion);
        request.setAttribute("q", q != null ? q : "");
        request.setAttribute("estado", estado != null ? estado : "Todos");
        request.setAttribute("pagina", pagina);
        request.setAttribute("totalPaginas", totalPaginas);
        request.setAttribute("desdeMostrado", totalFiltrados == 0 ? 0 : desde + 1);
        request.setAttribute("hastaMostrado", hasta);
        request.setAttribute("totalFiltrados", totalFiltrados);
        request.setAttribute("mensaje", mensajePorCodigo(request.getParameter("msg")));

        request.getRequestDispatcher("/Vista/gestionUsuarios.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        Usuario admin = (session != null) ? (Usuario) session.getAttribute("usuario") : null;
        String contextPath = request.getContextPath();

        if (admin == null) {
            response.sendRedirect(contextPath + "/Vista/login.jsp");
            return;
        }
        if (admin.getIdRol() != 1) {
            response.sendRedirect(contextPath + "/Vista/menuResidente.jsp");
            return;
        }

        String accion = request.getParameter("accion");
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        if ("crear".equals(accion)) {
            try {
                String errorTorre = validarTorreApartamento(request);
                if (errorTorre != null) {
                    request.setAttribute("error", errorTorre);
                    cargarCatalogos(request);
                    request.setAttribute("modo", "crear");
                    request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
                    return;
                }

                Usuario nuevo = leerFormulario(request, new Usuario());
                nuevo.setIdRol(2); // Siempre se crean residentes desde este módulo
                nuevo.setIdNotificaciones(1);
                nuevo.setFechaRegistro(new Timestamp(System.currentTimeMillis()));

                if (usuarioDAO.existeCorreoODocumento(nuevo.getCorreo(), nuevo.getDocumento())) {
                    request.setAttribute("error", "El correo o número de documento ya se encuentra registrado.");
                    cargarCatalogos(request);
                    request.setAttribute("modo", "crear");
                    request.setAttribute("residente", nuevo);
                    request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
                    return;
                }

                if (usuarioDAO.insertar(nuevo)) {
                    response.sendRedirect(contextPath + "/UsuarioAdminServlet?msg=creado");
                } else {
                    request.setAttribute("error", "No se pudo crear el residente. Inténtalo de nuevo.");
                    cargarCatalogos(request);
                    request.setAttribute("modo", "crear");
                    request.setAttribute("residente", nuevo);
                    request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
                }
            } catch (Exception e) {
                request.setAttribute("error", "Ocurrió un error al crear el residente: " + e.getMessage());
                cargarCatalogos(request);
                request.setAttribute("modo", "crear");
                request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
            }
            return;
        }

        if ("actualizar".equals(accion)) {
            try {
                String errorTorre = validarTorreApartamento(request);
                if (errorTorre != null) {
                    request.setAttribute("error", errorTorre);
                    cargarCatalogos(request);
                    request.setAttribute("modo", "editar");
                    request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
                    return;
                }

                int idUsuario = Integer.parseInt(request.getParameter("idUsuario"));
                Usuario existente = usuarioDAO.consultar(idUsuario);
                if (existente == null) {
                    response.sendRedirect(contextPath + "/UsuarioAdminServlet");
                    return;
                }
                Usuario actualizado = leerFormulario(request, existente);
                actualizado.setIdUsuario(idUsuario);
                actualizado.setIdRol(existente.getIdRol());
                actualizado.setIdNotificaciones(existente.getIdNotificaciones());
                actualizado.setFechaRegistro(existente.getFechaRegistro());

                // Si el admin dejó la contraseña en blanco, se conserva la actual
                String nuevaClave = request.getParameter("password");
                if (nuevaClave == null || nuevaClave.trim().isEmpty()) {
                    actualizado.setContrasena(existente.getContrasena());
                }

                if (usuarioDAO.actualizar(actualizado)) {
                    response.sendRedirect(contextPath + "/UsuarioAdminServlet?msg=actualizado");
                } else {
                    request.setAttribute("error", "No se pudo actualizar el residente.");
                    cargarCatalogos(request);
                    request.setAttribute("modo", "editar");
                    request.setAttribute("residente", actualizado);
                    request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
                }
            } catch (Exception e) {
                request.setAttribute("error", "Ocurrió un error al actualizar: " + e.getMessage());
                cargarCatalogos(request);
                request.getRequestDispatcher("/Vista/formResidente.jsp").forward(request, response);
            }
            return;
        }

        if ("resetear".equals(accion)) {
            try {
                int idUsuario = Integer.parseInt(request.getParameter("idUsuario"));
                usuarioDAO.resetearContrasena(idUsuario, CONTRASENA_POR_DEFECTO);
                response.sendRedirect(contextPath + "/UsuarioAdminServlet?msg=reset");
            } catch (NumberFormatException e) {
                response.sendRedirect(contextPath + "/UsuarioAdminServlet");
            }
            return;
        }

        response.sendRedirect(contextPath + "/UsuarioAdminServlet");
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private Usuario obtenerUsuarioPorId(HttpServletRequest request, UsuarioDAO dao) {
        try {
            int id = Integer.parseInt(request.getParameter("id"));
            return dao.consultar(id);
        } catch (Exception e) {
            return null;
        }
    }

    private Usuario leerFormulario(HttpServletRequest request, Usuario base) {
        base.setNombre(request.getParameter("nombre"));
        base.setApellido(request.getParameter("apellido"));
        base.setDocumento(request.getParameter("numeroDocumento"));
        base.setTelefono(request.getParameter("telefono"));
        base.setCorreo(request.getParameter("correo"));
        base.setTipoOcupante(request.getParameter("tipoOcupante"));

        String password = request.getParameter("password");
        if (password != null && !password.trim().isEmpty()) {
            base.setContrasena(PasswordUtil.hash(password));
        }

        String tipoDocumento = request.getParameter("tipoDocumento");
        if (tipoDocumento != null && !tipoDocumento.isEmpty()) {
            base.setIdTipoDocumento(Integer.parseInt(tipoDocumento));
        }

        // La torre/bloque y el apartamento se escriben libremente; si no existen
        // todavía en la base de datos, se crean (ver BloqueDAO/ApartamentoDAO#buscarOcrear).
        String torre = request.getParameter("torre");
        String numeroApartamento = request.getParameter("numeroApartamento");
        if (torre != null && !torre.trim().isEmpty() && numeroApartamento != null && !numeroApartamento.trim().isEmpty()) {
            int idBloque = new BloqueDAO().buscarOcrear(torre.trim());
            int idApartamento = new ApartamentoDAO().buscarOcrear(numeroApartamento.trim(), idBloque);
            base.setIdApartamento(idApartamento);
        }
        return base;
    }

    // Torres 1, 10 y 32: solo tienen 2 apartamentos por piso (101, 102, 201, 202...
    // hasta el 5º piso), a diferencia del resto de torres.
    private static final java.util.List<String> TORRES_RESTRINGIDAS = java.util.Arrays.asList("1", "10", "32");
    private static final java.util.List<String> APARTAMENTOS_VALIDOS_RESTRINGIDOS = java.util.Arrays.asList(
            "101", "102", "201", "202", "301", "302", "401", "402", "501", "502");

    /** Devuelve un mensaje de error si la torre/apartamento no es válida, o null si está bien. */
    private String validarTorreApartamento(HttpServletRequest request) {
        String torre = request.getParameter("torre");
        String numeroApartamento = request.getParameter("numeroApartamento");
        if (torre == null || torre.trim().isEmpty() || numeroApartamento == null || numeroApartamento.trim().isEmpty()) {
            return "Debes indicar la torre y el número de apartamento.";
        }
        String torreNormalizada = torre.trim();
        String aptoNormalizado = numeroApartamento.trim();
        if (TORRES_RESTRINGIDAS.contains(torreNormalizada)
                && !APARTAMENTOS_VALIDOS_RESTRINGIDOS.contains(aptoNormalizado)) {
            return "La torre " + torreNormalizada + " solo tiene 2 apartamentos por piso "
                    + "(101, 102, 201, 202, 301, 302, 401, 402, 501, 502). Revisa el número ingresado.";
        }
        return null;
    }

    private void cargarCatalogos(HttpServletRequest request) {
        request.setAttribute("tiposDocumento", new TipoDocumentoDAO().listarTodos());
    }

    private String mensajePorCodigo(String codigo) {
        if (codigo == null) {
            return null;
        }
        switch (codigo) {
            case "creado":
                return "Residente creado con éxito.";
            case "actualizado":
                return "Datos del residente actualizados.";
            case "reset":
                return "Contraseña restablecida a \"" + CONTRASENA_POR_DEFECTO + "\".";
            default:
                return null;
        }
    }

    private void exportarCSV(HttpServletResponse response, UsuarioDAO usuarioDAO) throws IOException {
        List<Usuario> residentes = usuarioDAO.listarPorRol(2);
        Map<Integer, Apartamento> apartamentos = new HashMap<>();
        for (Apartamento a : new ApartamentoDAO().listarTodos()) {
            apartamentos.put(a.getIdApartamento(), a);
        }
        Map<Integer, Bloque> bloques = new HashMap<>();
        for (Bloque b : new BloqueDAO().listarTodos()) {
            bloques.put(b.getIdBloque(), b);
        }

        response.setContentType("text/csv; charset=UTF-8");
        response.setHeader("Content-Disposition", "attachment; filename=\"usuarios_unidades.csv\"");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        PrintWriter out = response.getWriter();
        out.write('\uFEFF'); // BOM para que Excel reconozca UTF-8
        out.println("Nombre,Unidad,Correo,Telefono,Estado,FechaRegistro");
        for (Usuario u : residentes) {
            Apartamento apto = apartamentos.get(u.getIdApartamento());
            Bloque bloque = (apto != null) ? bloques.get(apto.getIdBloque()) : null;
            String unidad = (bloque != null ? "Torre " + bloque.getNombreBloque() : "") + " - Apto " + (apto != null ? apto.getNumero() : "");
            String fecha = (u.getFechaRegistro() != null) ? sdf.format(u.getFechaRegistro()) : "";
            out.println(csv(u.getNombre() + " " + u.getApellido()) + "," + csv(unidad) + "," + csv(u.getCorreo()) + ","
                    + csv(u.getTelefono()) + "," + csv(u.getTipoOcupante()) + "," + csv(fecha));
        }
        out.flush();
    }

    private String csv(String valor) {
        if (valor == null) {
            return "";
        }
        String v = valor.replace("\"", "\"\"");
        if (v.contains(",") || v.contains("\"") || v.contains("\n")) {
            return "\"" + v + "\"";
        }
        return v;
    }
}
