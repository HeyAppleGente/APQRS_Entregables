package servlet;

import Controlador.EmailService;
import Controlador.UsuarioDAO;
import Modelo.Usuario;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.security.SecureRandom;

/**
 * Recuperación de contraseña por código de verificación enviado al correo
 * real del usuario (reemplaza el esquema anterior de correo + documento).
 *
 * Flujo en 3 pasos, todo guardado en la sesión HTTP (no en la base de
 * datos) y con vencimiento de 10 minutos:
 *   1. El usuario escribe su correo -> se genera un código de 6 dígitos y
 *      se le envía por email (ver Controlador.EmailService).
 *   2. El usuario escribe el código que recibió -> se valida contra el
 *      guardado en sesión.
 *   3. Si el código es correcto, puede establecer una nueva contraseña.
 *
 * Si el servidor de correo no está configurado (ver mail.properties), el
 * código se genera igual pero el envío falla silenciosamente — el usuario
 * vería un mensaje de "código enviado" sin recibir nada. Es responsabilidad
 * de quien despliegue la app configurar mail.properties con una cuenta real.
 */
@WebServlet(name = "RecuperarPasswordServlet", urlPatterns = {"/RecuperarPasswordServlet"})
public class RecuperarPasswordServlet extends HttpServlet {

    private static final long VENTANA_CODIGO_MS = 10 * 60 * 1000; // 10 minutos

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect(request.getContextPath() + "/Vista/recuperar.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        HttpSession session = request.getSession(true);

        if ("enviarCodigo".equals(accion)) {
            String correo = request.getParameter("correo");
            if (correo == null || correo.trim().isEmpty()) {
                request.setAttribute("error", "Debes ingresar tu correo.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }

            UsuarioDAO usuarioDAO = new UsuarioDAO();
            Usuario usuario = usuarioDAO.consultarPorCorreo(correo.trim());

            if (usuario == null) {
                request.setAttribute("error", "No encontramos ninguna cuenta con ese correo.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }

            String codigo = generarCodigo();
            session.setAttribute("resetUsuarioId", usuario.getIdUsuario());
            session.setAttribute("resetUsuarioNombre", usuario.getNombre());
            session.setAttribute("resetCorreo", usuario.getCorreo());
            session.setAttribute("resetCodigo", codigo);
            session.setAttribute("resetCodigoTimestamp", System.currentTimeMillis());
            session.setAttribute("resetCodigoVerificado", false);

            boolean enviado = EmailService.enviarCodigoVerificacion(usuario.getCorreo(), usuario.getNombre(), codigo);
            if (!enviado) {
                request.setAttribute("error", "No se pudo enviar el correo con el código. Contacta a administración "
                        + "(es posible que el servidor de correo no esté configurado todavía).");
                limpiarSesion(session);
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }

            request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
            return;
        }

        if ("verificarCodigo".equals(accion)) {
            if (!codigoVigente(session)) {
                limpiarSesion(session);
                request.setAttribute("error", "El código expiró. Solicita uno nuevo.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }

            String codigoIngresado = request.getParameter("codigo");
            String codigoGuardado = (String) session.getAttribute("resetCodigo");

            if (codigoIngresado == null || !codigoIngresado.trim().equals(codigoGuardado)) {
                request.setAttribute("error", "El código no es correcto. Verifica que lo hayas copiado bien.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }

            session.setAttribute("resetCodigoVerificado", true);
            request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
            return;
        }

        if ("reenviarCodigo".equals(accion)) {
            Object idObj = session.getAttribute("resetUsuarioId");
            String correoGuardado = (String) session.getAttribute("resetCorreo");
            String nombreGuardado = (String) session.getAttribute("resetUsuarioNombre");
            if (idObj == null || correoGuardado == null) {
                response.sendRedirect(request.getContextPath() + "/Vista/recuperar.jsp");
                return;
            }
            String codigo = generarCodigo();
            session.setAttribute("resetCodigo", codigo);
            session.setAttribute("resetCodigoTimestamp", System.currentTimeMillis());
            session.setAttribute("resetCodigoVerificado", false);
            EmailService.enviarCodigoVerificacion(correoGuardado, nombreGuardado, codigo);
            request.setAttribute("mensaje", "Te reenviamos un nuevo código.");
            request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
            return;
        }

        if ("cambiar".equals(accion)) {
            Object idObj = session.getAttribute("resetUsuarioId");
            Boolean verificado = (Boolean) session.getAttribute("resetCodigoVerificado");

            if (idObj == null || verificado == null || !verificado || !codigoVigente(session)) {
                limpiarSesion(session);
                request.setAttribute("error", "La verificación expiró o no es válida. Por favor intenta de nuevo.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }

            String nueva = request.getParameter("nuevaPassword");
            String confirmar = request.getParameter("confirmarPassword");

            if (nueva == null || nueva.length() < 6) {
                request.setAttribute("error", "La nueva contraseña debe tener al menos 6 caracteres.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }
            if (!nueva.equals(confirmar)) {
                request.setAttribute("error", "Las contraseñas no coinciden.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
                return;
            }

            int idUsuario = (Integer) idObj;
            UsuarioDAO usuarioDAO = new UsuarioDAO();
            boolean exito = usuarioDAO.resetearContrasena(idUsuario, nueva);

            limpiarSesion(session);

            if (exito) {
                response.sendRedirect(request.getContextPath() + "/Vista/login.jsp?recuperada=1");
            } else {
                request.setAttribute("error", "No se pudo actualizar la contraseña. Intenta de nuevo.");
                request.getRequestDispatcher("/Vista/recuperar.jsp").forward(request, response);
            }
            return;
        }

        if ("cancelar".equals(accion)) {
            limpiarSesion(session);
            response.sendRedirect(request.getContextPath() + "/Vista/recuperar.jsp");
            return;
        }

        response.sendRedirect(request.getContextPath() + "/Vista/recuperar.jsp");
    }

    private boolean codigoVigente(HttpSession session) {
        Object tsObj = session.getAttribute("resetCodigoTimestamp");
        return tsObj != null && (System.currentTimeMillis() - (Long) tsObj) <= VENTANA_CODIGO_MS;
    }

    private void limpiarSesion(HttpSession session) {
        session.removeAttribute("resetUsuarioId");
        session.removeAttribute("resetUsuarioNombre");
        session.removeAttribute("resetCorreo");
        session.removeAttribute("resetCodigo");
        session.removeAttribute("resetCodigoTimestamp");
        session.removeAttribute("resetCodigoVerificado");
    }

    private String generarCodigo() {
        SecureRandom random = new SecureRandom();
        int numero = 100000 + random.nextInt(900000); // siempre 6 dígitos
        return String.valueOf(numero);
    }
}
