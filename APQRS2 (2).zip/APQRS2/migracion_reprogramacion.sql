-- ============================================================
-- MIGRACIÓN: solicitud de reprogramación de citas (por el residente)
-- ============================================================
-- Ejecuta este script SOLO si tu base de datos "mydb" ya existía.
-- Si vas a correr BD.sql desde cero, NO lo necesitas.
-- ============================================================

USE mydb;

ALTER TABLE Citas
  ADD COLUMN reprogramacion_solicitada TINYINT(1) NOT NULL DEFAULT 0 AFTER asistencia,
  ADD COLUMN mensaje_reprogramacion VARCHAR(300) NULL AFTER reprogramacion_solicitada;
