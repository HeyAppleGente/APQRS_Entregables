-- ============================================================
-- MIGRACIÓN: permitir cancelar citas
-- ============================================================
-- Ejecuta este script SOLO si tu base de datos "mydb" ya existía.
-- Si vas a correr BD.sql desde cero, NO lo necesitas.
--
-- Agrega una bandera "cancelada" a Citas. Al cancelar una cita no se
-- borra (se conserva para la trazabilidad/seguimiento), simplemente
-- se marca como cancelada y su horario vuelve a quedar disponible.
-- ============================================================

USE mydb;

ALTER TABLE Citas
  ADD COLUMN cancelada TINYINT(1) NOT NULL DEFAULT 0 AFTER notificada_residente;
