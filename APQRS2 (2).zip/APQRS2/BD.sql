-- ============================================================
-- APQRS - SISTEMA DE GESTIÓN RESIDENCIAL
-- Base de datos alineada con el proyecto Java (Modelo/DAO/Servlet)
-- Nombres de tabla y columna EXACTOS a los que usan los DAO generados.
-- Compatible con MySQL 8.x / MariaDB
-- ============================================================

DROP DATABASE IF EXISTS mydb;
CREATE DATABASE mydb
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE mydb;

SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE Rol (
  idRol INT NOT NULL AUTO_INCREMENT,
  nombre_rol VARCHAR(45) NOT NULL,
  PRIMARY KEY (idRol)
) ENGINE=InnoDB;

CREATE TABLE Tipo_Documento (
  id_tipo_documento INT NOT NULL AUTO_INCREMENT,
  nombre_tipo_documento VARCHAR(45) NOT NULL,
  PRIMARY KEY (id_tipo_documento)
) ENGINE=InnoDB;

CREATE TABLE Bloque (
  id_bloque INT NOT NULL AUTO_INCREMENT,
  nombre_bloque VARCHAR(45) NOT NULL,
  PRIMARY KEY (id_bloque)
) ENGINE=InnoDB;

CREATE TABLE Apartamento (
  id_apartamento INT NOT NULL AUTO_INCREMENT,
  numero VARCHAR(45) NOT NULL,
  Bloque_id_bloque INT NOT NULL,
  PRIMARY KEY (id_apartamento),
  CONSTRAINT fk_Apartamento_Bloque1
    FOREIGN KEY (Bloque_id_bloque)
    REFERENCES Bloque (id_bloque)
) ENGINE=InnoDB;

CREATE TABLE TIPOCITA (
  id_tipo_cita INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(45) NOT NULL,
  duracion INT NOT NULL,
  PRIMARY KEY (id_tipo_cita)
) ENGINE=InnoDB;

CREATE TABLE TIPONOTIFICACION (
  id_tipo_notificacion INT NOT NULL AUTO_INCREMENT,
  nombre_tipo_notificacion VARCHAR(45) NOT NULL,
  PRIMARY KEY (id_tipo_notificacion)
) ENGINE=InnoDB;

-- OJO: la columna se llama " nombre_tipo_pqrs" (con espacio inicial),
-- así la referencia TipoPqrsDAO.java (con backticks). Se conserva tal cual.
CREATE TABLE TipoPqrs (
  id_tipo_pqrs INT NOT NULL AUTO_INCREMENT,
  ` nombre_tipo_pqrs` VARCHAR(45) NOT NULL,
  dias_plazo INT NOT NULL DEFAULT 15,
  PRIMARY KEY (id_tipo_pqrs)
) ENGINE=InnoDB;

CREATE TABLE Usuario (
  idUsuario INT NOT NULL AUTO_INCREMENT,
  nombre VARCHAR(45) NOT NULL,
  apellido VARCHAR(45) NOT NULL,
  documento VARCHAR(45) NOT NULL,
  telefono VARCHAR(45) NOT NULL,
  correo VARCHAR(45) NOT NULL,
  contrasena VARCHAR(255) NOT NULL,
  Rol_idRol INT NOT NULL,
  Tipo_Documento_id_tipo_documento INT NOT NULL,
  Apartamento_id_apartamento INT NOT NULL,
  NOTIFICACIONES_id_notificaciones INT NULL,
  tipo_ocupante VARCHAR(20) NOT NULL DEFAULT 'Propietario',
  fecha_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (idUsuario),
  CONSTRAINT fk_Usuario_Rol
    FOREIGN KEY (Rol_idRol)
    REFERENCES Rol (idRol),
  CONSTRAINT fk_Usuario_Tipo_Documento1
    FOREIGN KEY (Tipo_Documento_id_tipo_documento)
    REFERENCES Tipo_Documento (id_tipo_documento),
  CONSTRAINT fk_Usuario_Apartamento1
    FOREIGN KEY (Apartamento_id_apartamento)
    REFERENCES Apartamento (id_apartamento)
) ENGINE=InnoDB;

CREATE TABLE Citas (
  id_citas INT NOT NULL AUTO_INCREMENT,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  observaciones VARCHAR(500) NOT NULL,
  respuesta VARCHAR(500) NOT NULL,
  fecha_creacion DATETIME NOT NULL,
  fecha_respuesta DATETIME NOT NULL,
  Usuario_idUsuario INT NOT NULL,
  TIPOCITA_id_tipo_cita INT NOT NULL,
  PQRS_id_pqrs INT NULL,
  notificada_residente TINYINT(1) NOT NULL DEFAULT 0,
  cancelada TINYINT(1) NOT NULL DEFAULT 0,
  asistencia VARCHAR(20) NULL,
  reprogramacion_solicitada TINYINT(1) NOT NULL DEFAULT 0,
  mensaje_reprogramacion VARCHAR(300) NULL,
  PRIMARY KEY (id_citas),
  CONSTRAINT fk_Cita_Usuario1
    FOREIGN KEY (Usuario_idUsuario)
    REFERENCES Usuario (idUsuario),
  CONSTRAINT fk_Citas_TIPOCITA1
    FOREIGN KEY (TIPOCITA_id_tipo_cita)
    REFERENCES TIPOCITA (id_tipo_cita)
) ENGINE=InnoDB;

CREATE TABLE PQRS (
  id_pqrs INT NOT NULL AUTO_INCREMENT,
  asunto VARCHAR(90) NOT NULL,
  descripcion VARCHAR(500) NOT NULL,
  respuesta VARCHAR(500) NOT NULL,
  fecha_registro DATETIME NOT NULL,
  fecha_respuesta DATETIME NOT NULL,
  TipoPqrs_id_tipo_pqrs INT NOT NULL,
  Usuario_idUsuario INT NOT NULL,
  PRIMARY KEY (id_pqrs),
  CONSTRAINT fk_PQRS_TipoPqrs1
    FOREIGN KEY (TipoPqrs_id_tipo_pqrs)
    REFERENCES TipoPqrs (id_tipo_pqrs),
  CONSTRAINT fk_PQRS_Usuario1
    FOREIGN KEY (Usuario_idUsuario)
    REFERENCES Usuario (idUsuario)
) ENGINE=InnoDB;

ALTER TABLE Citas
  ADD CONSTRAINT fk_Citas_PQRS1
    FOREIGN KEY (PQRS_id_pqrs)
    REFERENCES PQRS (id_pqrs);

CREATE TABLE NOTIFICACIONES (
  id_notificaciones INT NOT NULL AUTO_INCREMENT,
  titulo VARCHAR(45) NOT NULL,
  mensaje VARCHAR(500) NOT NULL,
  leido TINYINT NOT NULL,
  fecha_envio DATETIME NOT NULL,
  Citas_id_citas INT NULL,
  TIPONOTIFICACION_id_tipo_notificacion INT NOT NULL,
  PQRS_id_pqrs INT NULL,
  Usuario_idUsuario INT NULL,
  PRIMARY KEY (id_notificaciones),
  CONSTRAINT fk_NOTIFICACIONES_Citas1
    FOREIGN KEY (Citas_id_citas)
    REFERENCES Citas (id_citas),
  CONSTRAINT fk_NOTIFICACIONES_TIPONOTIFICACION1
    FOREIGN KEY (TIPONOTIFICACION_id_tipo_notificacion)
    REFERENCES TIPONOTIFICACION (id_tipo_notificacion),
  CONSTRAINT fk_NOTIFICACIONES_PQRS1
    FOREIGN KEY (PQRS_id_pqrs)
    REFERENCES PQRS (id_pqrs),
  CONSTRAINT fk_NOTIFICACIONES_Usuario1
    FOREIGN KEY (Usuario_idUsuario)
    REFERENCES Usuario (idUsuario)
) ENGINE=InnoDB;

ALTER TABLE Usuario
  ADD CONSTRAINT fk_Usuario_NOTIFICACIONES1
    FOREIGN KEY (NOTIFICACIONES_id_notificaciones)
    REFERENCES NOTIFICACIONES (id_notificaciones);

-- Configuración de disponibilidad para agendar citas (un solo registro global).
CREATE TABLE ConfiguracionAgenda (
  id_configuracion INT NOT NULL AUTO_INCREMENT,
  hora_inicio TIME NOT NULL DEFAULT '08:00:00',
  hora_fin TIME NOT NULL DEFAULT '17:00:00',
  duracion_slot_minutos INT NOT NULL DEFAULT 30,
  dias_laborales VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5,6',
  PRIMARY KEY (id_configuracion)
) ENGINE=InnoDB;

INSERT INTO ConfiguracionAgenda (id_configuracion, hora_inicio, hora_fin, duracion_slot_minutos, dias_laborales)
VALUES (1, '08:00:00', '17:00:00', 30, '1,2,3,4,5,6');

CREATE TABLE Seguimiento (
  id_seguimiento INT NOT NULL AUTO_INCREMENT,
  comentario VARCHAR(200) NOT NULL,
  fecha_registro DATETIME NOT NULL,
  Citas_id_citas INT NOT NULL,
  Usuario_idUsuario INT NOT NULL,
  PQRS_id_pqrs INT NULL,
  PRIMARY KEY (id_seguimiento),
  CONSTRAINT fk_Seguimiento_Citas1
    FOREIGN KEY (Citas_id_citas)
    REFERENCES Citas (id_citas),
  CONSTRAINT fk_Seguimiento_Usuario1
    FOREIGN KEY (Usuario_idUsuario)
    REFERENCES Usuario (idUsuario),
  CONSTRAINT fk_Seguimiento_PQRS1
    FOREIGN KEY (PQRS_id_pqrs)
    REFERENCES PQRS (id_pqrs)
) ENGINE=InnoDB;

INSERT INTO Rol (idRol, nombre_rol) VALUES
(1, 'Administrador'),
(2, 'Residente');

INSERT INTO Tipo_Documento (id_tipo_documento, nombre_tipo_documento) VALUES
(1, 'Cédula de Ciudadanía'),
(2, 'Tarjeta de Identidad'),
(3, 'Cédula de Extranjería'),
(4, 'Pasaporte');

INSERT INTO Bloque (id_bloque, nombre_bloque) VALUES
(1, '1'),
(2, '2'),
(3, '3');

INSERT INTO Apartamento (id_apartamento, numero, Bloque_id_bloque) VALUES
(1, '101', 1),
(2, '202', 1),
(3, '303', 2),
(4, '404', 2),
(5, '505', 3);

INSERT INTO TIPOCITA (id_tipo_cita, nombre, duracion) VALUES
(1, 'Atención administrativa', 30),
(2, 'Reunión con administración', 30),
(3, 'Solicitud de información', 20),
(4, 'Seguimiento de PQRS', 30);

INSERT INTO TIPONOTIFICACION (id_tipo_notificacion, nombre_tipo_notificacion) VALUES
(1, 'PQRS'),
(2, 'Cita'),
(3, 'Administración');

INSERT INTO TipoPqrs (id_tipo_pqrs, ` nombre_tipo_pqrs`, dias_plazo) VALUES
(1, 'Petición', 15),
(2, 'Queja', 15),
(3, 'Reclamo', 15),
(4, 'Sugerencia', 15);

INSERT INTO Usuario
  (idUsuario, nombre, apellido, documento, telefono, correo, contrasena,
   Rol_idRol, Tipo_Documento_id_tipo_documento, Apartamento_id_apartamento,
   NOTIFICACIONES_id_notificaciones, tipo_ocupante, fecha_registro)
VALUES
(1, 'Administrador', 'General', '1000000001', '3000000001',
 'admin@apqrs.local', 'Admin123*', 1, 1, 1, NULL, 'Propietario', '2019-01-05 08:00:00'),

(2, 'Carlos', 'Ramírez', '1000000002', '3000000002',
 'carlos.ramirez@apqrs.local', 'Residente123*', 2, 1, 1, NULL, 'Propietario', '2020-03-15 09:30:00'),

(3, 'Laura', 'Gómez', '1000000003', '3000000003',
 'laura.gomez@apqrs.local', 'Residente123*', 2, 1, 2, NULL, 'Arrendatario', '2022-06-20 10:15:00'),

(4, 'Andrés', 'Martínez', '1000000004', '3000000004',
 'andres.martinez@apqrs.local', 'Residente123*', 2, 1, 3, NULL, 'Propietario', '2019-11-10 14:00:00'),

(5, 'Natalia', 'Torres', '1000000005', '3000000005',
 'natalia.torres@apqrs.local', 'Residente123*', 2, 1, 4, NULL, 'Propietario', '2021-08-05 16:45:00'),

(6, 'Julián', 'Rodríguez', '1000000006', '3000000006',
 'julian.rodriguez@apqrs.local', 'Residente123*', 2, 1, 5, NULL, 'Arrendatario', '2023-01-12 11:20:00');

INSERT INTO Citas
  (id_citas, fecha, hora, observaciones, respuesta, fecha_creacion,
   fecha_respuesta, Usuario_idUsuario, TIPOCITA_id_tipo_cita)
VALUES
(1, '2026-09-02', '09:00:00', 'Consulta relacionada con documentación del apartamento.',
 'Cita confirmada.', '2026-08-27 08:00:00', '2026-08-27 08:00:00', 2, 1),

(2, '2026-09-02', '10:00:00', 'Seguimiento de la PQRS sobre ruido nocturno.',
 'Cita confirmada.', '2026-08-28 09:30:00', '2026-08-28 09:30:00', 3, 4),

(3, '2026-09-03', '11:00:00', 'Consulta sobre servicios disponibles para residentes.',
 'Pendiente de confirmación.', '2026-08-29 13:10:00', '2026-08-29 13:10:00', 4, 3),

(4, '2026-08-28', '15:00:00', 'Revisión de propuesta para zonas verdes.',
 'Reunión atendida.', '2026-08-25 12:00:00', '2026-08-28 15:00:00', 5, 2),

(5, '2026-08-29', '09:30:00', 'Cita cancelada por el residente.',
 'Cita cancelada.', '2026-08-27 15:45:00', '2026-08-29 09:30:00', 6, 1);

INSERT INTO PQRS
  (id_pqrs, asunto, descripcion, respuesta, fecha_registro, fecha_respuesta,
   TipoPqrs_id_tipo_pqrs, Usuario_idUsuario)
VALUES
(1, 'Solicitud de información sobre parqueaderos',
 'Solicito información sobre el procedimiento para asignación y uso de parqueaderos de visitantes.',
 '', '2026-08-25 09:15:00', '2026-08-25 09:15:00', 1, 2),

(2, 'Ruido en horario nocturno',
 'Se presenta ruido frecuente en horas de la noche que afecta el descanso de los residentes.',
 'En revisión por parte de la administración.', '2026-08-26 20:30:00', '2026-08-27 08:00:00', 2, 3),

(3, 'Falla en iluminación de zona común',
 'La iluminación del pasillo presenta fallas y requiere revisión.',
 'Se realizó la solicitud de mantenimiento y se programó la revisión del sistema eléctrico.',
 '2026-08-20 08:40:00', '2026-08-21 14:20:00', 3, 4),

(4, 'Propuesta para mejorar zonas verdes',
 'Sugiero implementar jornadas periódicas de mantenimiento y recuperación de las zonas verdes.',
 'La propuesta fue recibida y será incluida en la próxima reunión de administración.',
 '2026-08-10 11:00:00', '2026-08-12 10:00:00', 4, 5),

(5, 'Solicitud de certificado de residencia',
 'Solicito información sobre el proceso para obtener un certificado de residencia.',
 '', '2026-08-28 10:10:00', '2026-08-28 10:10:00', 1, 6);

INSERT INTO NOTIFICACIONES
  (id_notificaciones, titulo, mensaje, leido, fecha_envio,
   Citas_id_citas, TIPONOTIFICACION_id_tipo_notificacion, PQRS_id_pqrs)
VALUES
(1, 'PQRS registrada', 'Tu PQRS fue registrada correctamente.',
 0, '2026-08-25 09:16:00', 1, 1, 1),

(2, 'PQRS en revisión', 'Tu PQRS se encuentra en proceso de revisión.',
 0, '2026-08-27 08:30:00', 2, 1, 2),

(3, 'PQRS respondida', 'La administración respondió tu PQRS.',
 1, '2026-08-21 14:21:00', 3, 1, 3),

(4, 'PQRS cerrada', 'Tu PQRS fue cerrada.',
 1, '2026-08-13 16:01:00', 4, 1, 4),

(5, 'Cita confirmada', 'Tu cita del 02/09/2026 a las 09:00 fue confirmada.',
 1, '2026-08-30 09:00:00', 1, 2, 1),

(6, 'Cita confirmada', 'Tu cita del 02/09/2026 a las 10:00 fue confirmada.',
 1, '2026-08-30 09:05:00', 2, 2, 2),

(7, 'Nueva PQRS', 'Se registró una nueva PQRS pendiente de revisión.',
 0, '2026-08-28 10:11:00', 5, 3, 5);

UPDATE Usuario SET NOTIFICACIONES_id_notificaciones = 5 WHERE idUsuario = 2;
UPDATE Usuario SET NOTIFICACIONES_id_notificaciones = 6 WHERE idUsuario = 3;
UPDATE Usuario SET NOTIFICACIONES_id_notificaciones = 3 WHERE idUsuario = 4;
UPDATE Usuario SET NOTIFICACIONES_id_notificaciones = 4 WHERE idUsuario = 5;
UPDATE Usuario SET NOTIFICACIONES_id_notificaciones = 7 WHERE idUsuario = 6;

INSERT INTO Seguimiento
  (id_seguimiento, comentario, fecha_registro, Citas_id_citas, Usuario_idUsuario, PQRS_id_pqrs)
VALUES
(1, 'Se realizó visita técnica de mantenimiento en la zona común.',
 '2026-08-21 15:00:00', 3, 1, 3),

(2, 'Seguimiento telefónico a la solicitud de parqueaderos.',
 '2026-08-26 10:00:00', 1, 1, 1);

SET FOREIGN_KEY_CHECKS = 1;
