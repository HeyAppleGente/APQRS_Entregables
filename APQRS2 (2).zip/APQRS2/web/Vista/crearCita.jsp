<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="Modelo.Usuario" %>
<%
    // Esta vista quedó en desuso: ahora es el administrador quien agenda las
    // citas (ver /CitasServlet?accion=calendario). Se deja este redirect por
    // si algún enlace o marcador viejo todavía apunta aquí.
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    String ctx = request.getContextPath();
    if (usuario == null) {
        response.sendRedirect(ctx + "/Vista/login.jsp");
    } else if (usuario.getIdRol() == 1) {
        response.sendRedirect(ctx + "/CitasServlet?accion=calendario");
    } else {
        response.sendRedirect(ctx + "/Vista/menuResidente.jsp");
    }
%>
