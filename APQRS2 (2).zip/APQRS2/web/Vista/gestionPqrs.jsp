<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.TipoPqrs" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="Modelo.Seguimiento" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.Bloque" %>
<%@ page import="Modelo.Notificaciones" %>
<%@ page import="Controlador.UsuarioDAO" %>
<%@ page import="Controlador.TipoPqrsDAO" %>
<%@ page import="Controlador.CitasDAO" %>
<%@ page import="Controlador.TipocitaDAO" %>
<%@ page import="Controlador.SeguimientoDAO" %>
<%@ page import="Controlador.ApartamentoDAO" %>
<%@ page import="Controlador.BloqueDAO" %>
<%@ page import="Controlador.NotificacionesDAO" %>
<%@ page import="Controlador.PlazoUtil" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.HashMap" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null || usuario.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    Usuario usuarioActual = usuario;
    String rolLabel = "Administrador";

    List<Pqrs> todasPqrs = (List<Pqrs>) request.getAttribute("todasPqrs");
    UsuarioDAO usuarioDAO = new UsuarioDAO();
    TipoPqrsDAO tipoPqrsDAO = new TipoPqrsDAO();
    CitasDAO citasDAO = new CitasDAO();
    TipocitaDAO tipoCitaDAO = new TipocitaDAO();
    SeguimientoDAO seguimientoDAO = new SeguimientoDAO();
    ApartamentoDAO apartamentoDAO = new ApartamentoDAO();
    BloqueDAO bloqueDAO = new BloqueDAO();
    NotificacionesDAO notificacionesDAO = new NotificacionesDAO();
    SimpleDateFormat sdfCorta = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdfLarga = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    List<Notificaciones> notificacionesAdmin = notificacionesDAO.listarParaAdmin(10);
    int noLeidasAdmin = notificacionesDAO.contarNoLeidasParaAdmin();
    List<TipoPqrs> tiposPqrs = tipoPqrsDAO.listarTodos();

    // ---------- Precarga en memoria (evita N+1: antes cada PQRS de la lista
    // disparaba 4-5 consultas propias; ahora se hace UNA consulta por tabla
    // y se arma un mapa id -> objeto para usar durante el render). ----------
    Map<Integer, Usuario> usuariosPorId = new HashMap<>();
    for (Usuario u : usuarioDAO.listarTodos()) usuariosPorId.put(u.getIdUsuario(), u);

    Map<Integer, Apartamento> apartamentosPorId = new HashMap<>();
    for (Apartamento a : apartamentoDAO.listarTodos()) apartamentosPorId.put(a.getIdApartamento(), a);

    Map<Integer, Bloque> bloquesPorId = new HashMap<>();
    for (Bloque b : bloqueDAO.listarTodos()) bloquesPorId.put(b.getIdBloque(), b);

    Map<Integer, TipoPqrs> tiposPqrsPorId = new HashMap<>();
    for (TipoPqrs t : tiposPqrs) tiposPqrsPorId.put(t.getIdTipoPqrs(), t);

    Map<Integer, Tipocita> tiposCitaPorId = new HashMap<>();
    for (Tipocita t : tipoCitaDAO.listarTodos()) tiposCitaPorId.put(t.getIdTipoCita(), t);

    Map<Integer, List<Citas>> citasPorPqrs = new HashMap<>();
    for (Citas c : citasDAO.listarTodos()) {
        if (c.getIdPqrs() == null) continue;
        citasPorPqrs.computeIfAbsent(c.getIdPqrs(), k -> new java.util.ArrayList<>()).add(c);
    }

    Map<Integer, List<Seguimiento>> seguimientoPorPqrs = new HashMap<>();
    for (Seguimiento s : seguimientoDAO.listarTodos()) {
        seguimientoPorPqrs.computeIfAbsent(s.getIdPqrs(), k -> new java.util.ArrayList<>()).add(s);
    }

    Map<Integer, Integer> conteoPorResidente = new HashMap<>();
    if (todasPqrs != null) {
        for (Pqrs p : todasPqrs) conteoPorResidente.merge(p.getIdUsuario(), 1, Integer::sum);
    }

    int totalPqrs = todasPqrs != null ? todasPqrs.size() : 0;
    int pendientesCount = 0, enProcesoCount = 0, resueltasMesCount = 0, vencidasCount = 0;
    java.time.LocalDate hoy = java.time.LocalDate.now();
    if (todasPqrs != null) {
        for (Pqrs p : todasPqrs) {
            boolean r = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
            if (!r) {
                pendientesCount++;
                TipoPqrs tp = tiposPqrsPorId.get(p.getIdTipoPqrs());
                int dias = tp != null ? tp.getDiasPlazo() : 15;
                if (p.getFechaRegistro() != null) {
                    PlazoUtil.EstadoPlazo ep = PlazoUtil.calcularEstado(p.getFechaRegistro().toLocalDateTime(), dias);
                    if (ep.vencida) vencidasCount++;
                }
            }
            else if (p.getFechaRespuesta() != null) {
                java.time.LocalDate fr = p.getFechaRespuesta().toLocalDateTime().toLocalDate();
                if (fr.getMonthValue() == hoy.getMonthValue() && fr.getYear() == hoy.getYear()) resueltasMesCount++;
            }
        }
    }
    String mensaje = (String) request.getAttribute("mensaje");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de PQRS - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/DashAdmin.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/gestionUsuarios.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/dropdowns.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/masterDetail.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/timeline.css">
</head>
<body>
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<%= ctx %>/Vista/menuAdmin.jsp">
                    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                    Panel General
                </a></li>
                <li><a href="<%= ctx %>/UsuarioAdminServlet">
                    <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                    Usuarios y Unidades
                </a></li>
                <li class="active"><a href="<%= ctx %>/PqrsServlet?vista=admin">
                    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                    Gestión PQRS
                </a></li>
                <li><a href="<%= ctx %>/CitasServlet?vista=admin">
                    <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                    Control de Citas
                </a></li>
            </ul>
        </div>
        <div class="sidebar-footer">Administrador</div>
    </aside>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                <p>Administrador</p>
            </div>
            <div class="header-actions">
                <%@ include file="_notifBell.jspf" %>
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">
            <div class="page-title-row">
                <div>
                    <h1>Gestión de PQRS</h1>
                    <p class="page-subtitle">Administra solicitudes, quejas, reclamos y sugerencias</p>
                </div>
                <a class="btn-outline" href="<%= ctx %>/PqrsServlet?accion=plazos">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                    Configurar Plazos
                </a>
            </div>

            <% if (mensaje != null) { %><div class="alert alert-success"><%= mensaje %></div><% } %>
            <% if (error != null) { %><div class="alert alert-danger"><%= error %></div><% } %>

            <div class="metrics-usuarios">
                <div class="card"><div class="stat-label">Total PQRS</div><div class="stat-value"><%= totalPqrs %></div></div>
                <div class="card"><div class="stat-label">Pendientes</div><div class="stat-value"><%= pendientesCount %></div></div>
                <div class="card"><div class="stat-label">Resueltas (mes)</div><div class="stat-value stat-value-success"><%= resueltasMesCount %></div></div>
                <div class="card"><div class="stat-label">Vencidas</div><div class="stat-value" style="color:<%= vencidasCount > 0 ? "#dc2626" : "#0f172a" %>;"><%= vencidasCount %></div></div>
            </div>

            <div class="md-toolbar">
                <div class="md-search">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input type="text" id="buscador" placeholder="Buscar por ID, residente o unidad..." oninput="filtrarLista()">
                </div>
                <div class="md-filters">
                    <select id="filtroEstado" onchange="filtrarLista()">
                        <option value="">Todos los estados</option>
                        <option value="pendiente">Pendientes</option>
                        <option value="resuelta">Resueltas</option>
                        <option value="vencida">Vencidas</option>
                        <option value="porvencer">Por vencer</option>
                    </select>
                    <select id="filtroTipo" onchange="filtrarLista()">
                        <option value="">Todos los tipos</option>
                        <% for (TipoPqrs tp : tiposPqrs) { %>
                            <option value="<%= tp.getNombreTipoPqrs() %>"><%= tp.getNombreTipoPqrs() %></option>
                        <% } %>
                    </select>
                    <span class="md-results-count" id="contadorResultados"></span>
                </div>
            </div>

            <div class="md-layout">
                <div class="md-list" id="listaPqrs">
                    <% if (todasPqrs == null || todasPqrs.isEmpty()) { %>
                        <div class="md-empty-list">No hay PQRS radicadas todavía.</div>
                    <% } else {
                        for (Pqrs p : todasPqrs) {
                            boolean respondida = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
                            Usuario autor = usuariosPorId.get(p.getIdUsuario());
                            Apartamento apto = autor != null ? apartamentosPorId.get(autor.getIdApartamento()) : null;
                            Bloque bloque = apto != null ? bloquesPorId.get(apto.getIdBloque()) : null;
                            String unidad = (bloque != null ? "Torre " + bloque.getNombreBloque() : "") + " - Apto " + (apto != null ? apto.getNumero() : "-");
                            TipoPqrs tipo = tiposPqrsPorId.get(p.getIdTipoPqrs());
                            String nombreAutor = autor != null ? (autor.getNombre() + " " + autor.getApellido()) : "Residente";
                            String busqueda = ("pqrs-" + p.getIdPqrs() + " " + nombreAutor + " " + unidad + " " + p.getAsunto()).toLowerCase();

                            String plazoClass = "na";
                            PlazoUtil.EstadoPlazo estadoPlazo = null;
                            if (!respondida && p.getFechaRegistro() != null) {
                                int dias = tipo != null ? tipo.getDiasPlazo() : 15;
                                estadoPlazo = PlazoUtil.calcularEstado(p.getFechaRegistro().toLocalDateTime(), dias);
                                plazoClass = estadoPlazo.vencida ? "vencida" : (estadoPlazo.porVencer ? "porvencer" : "normal");
                            }
                    %>
                        <button class="md-item" id="item-<%= p.getIdPqrs() %>"
                                data-estado="<%= respondida ? "resuelta" : "pendiente" %>"
                                data-tipo="<%= tipo != null ? tipo.getNombreTipoPqrs() : "" %>"
                                data-plazo="<%= plazoClass %>"
                                data-search="<%= busqueda %>"
                                onclick="seleccionar('<%= p.getIdPqrs() %>')">
                            <div class="md-item-top">
                                <span class="md-item-id">PQRS-<%= String.format("%03d", p.getIdPqrs()) %></span>
                                <span class="badge-pill <%= respondida ? "badge-propietario" : "badge-arrendatario" %>">
                                    <%= respondida ? "Resuelta" : "Pendiente" %>
                                </span>
                            </div>
                            <div class="md-item-date"><%= p.getFechaRegistro() != null ? sdfCorta.format(p.getFechaRegistro()) : "" %></div>
                            <div class="md-item-title"><%= Controlador.Utilidades.esc(p.getAsunto()) %></div>
                            <div class="md-item-meta"><%= nombreAutor %> - <%= unidad %></div>
                            <div class="md-item-tags">
                                <span class="tipo-tag"><%= tipo != null ? tipo.getNombreTipoPqrs() : "-" %></span>
                                <% if (estadoPlazo != null) { %>
                                    <span class="plazo-tag plazo-<%= plazoClass.equals("porvencer") ? "por-vencer" : plazoClass %>">
                                        <%= estadoPlazo.vencida ? ("Vencida hace " + Math.abs(estadoPlazo.diasRestantes) + "d") : ("Vence en " + estadoPlazo.diasRestantes + "d") %>
                                    </span>
                                <% } %>
                            </div>
                        </button>
                    <%  }
                    } %>
                </div>

                <div class="md-detail-panel">
                    <div class="md-placeholder" id="placeholder">
                        <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        <p>Selecciona una PQRS para gestionar</p>
                    </div>

                    <% if (todasPqrs != null) {
                        for (Pqrs p : todasPqrs) {
                            boolean respondida = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
                            Usuario autor = usuariosPorId.get(p.getIdUsuario());
                            Apartamento apto = autor != null ? apartamentosPorId.get(autor.getIdApartamento()) : null;
                            Bloque bloque = apto != null ? bloquesPorId.get(apto.getIdBloque()) : null;
                            String unidad = (bloque != null ? "Torre " + bloque.getNombreBloque() : "") + " - Apto " + (apto != null ? apto.getNumero() : "-");
                            TipoPqrs tipo = tiposPqrsPorId.get(p.getIdTipoPqrs());
                            int totalDelResidente = conteoPorResidente.getOrDefault(p.getIdUsuario(), 1);
                            List<Citas> citasRelacionadas = citasPorPqrs.getOrDefault(p.getIdPqrs(), new java.util.ArrayList<Citas>());
                            List<Seguimiento> historial = seguimientoPorPqrs.getOrDefault(p.getIdPqrs(), new java.util.ArrayList<Seguimiento>());
                            boolean tieneCitaActiva = false;
                            for (Citas cc : citasRelacionadas) {
                                if (!cc.isCancelada()) { tieneCitaActiva = true; break; }
                            }

                            int diasPlazoTipo = tipo != null ? tipo.getDiasPlazo() : 15;
                            PlazoUtil.EstadoPlazo estadoPlazoDetalle = (p.getFechaRegistro() != null)
                                    ? PlazoUtil.calcularEstado(p.getFechaRegistro().toLocalDateTime(), diasPlazoTipo) : null;
                    %>
                        <div class="md-detail" id="detail-<%= p.getIdPqrs() %>">
                            <div class="md-detail-header">
                                <h2>PQRS-<%= String.format("%03d", p.getIdPqrs()) %> · <%= Controlador.Utilidades.esc(p.getAsunto()) %></h2>
                                <span class="badge-pill <%= respondida ? "badge-propietario" : "badge-arrendatario" %>">
                                    <%= respondida ? "Resuelta" : "Pendiente" %>
                                </span>
                            </div>
                            <div class="md-detail-meta">
                                <%= autor != null ? (autor.getNombre() + " " + autor.getApellido()) : "Residente" %> · <%= unidad %>
                                · <span class="trace-badge"><%= totalDelResidente %> PQRS en total</span>
                                · <%= tipo != null ? tipo.getNombreTipoPqrs() : "-" %>
                                · Radicada: <%= p.getFechaRegistro() %>
                            </div>

                            <div class="md-detail-section">
                                <div class="md-detail-label">Descripción</div>
                                <div class="md-detail-body"><%= Controlador.Utilidades.esc(p.getDescripcion()) %></div>
                            </div>

                            <% if (!respondida && estadoPlazoDetalle != null) {
                                String claseBanner = estadoPlazoDetalle.vencida ? "plazo-vencida" : (estadoPlazoDetalle.porVencer ? "plazo-por-vencer" : "plazo-a-tiempo");
                            %>
                                <div class="plazo-banner <%= claseBanner %>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                    <span>
                                        <% if (estadoPlazoDetalle.vencida) { %>
                                            Plazo vencido hace <%= Math.abs(estadoPlazoDetalle.diasRestantes) %> día(s) hábil(es) — venció el <%= estadoPlazoDetalle.fechaLimite %>
                                        <% } else { %>
                                            Vence en <%= estadoPlazoDetalle.diasRestantes %> día(s) hábil(es) (<%= estadoPlazoDetalle.fechaLimite %>) — <%= diasPlazoTipo %> días hábiles de plazo para "<%= tipo != null ? tipo.getNombreTipoPqrs() : "" %>"
                                        <% } %>
                                    </span>
                                </div>
                            <% } else if (respondida && p.getFechaRegistro() != null && p.getFechaRespuesta() != null) {
                                java.time.LocalDate limiteOriginal = PlazoUtil.sumarDiasHabiles(p.getFechaRegistro().toLocalDateTime().toLocalDate(), diasPlazoTipo);
                                boolean aTiempo = !p.getFechaRespuesta().toLocalDateTime().toLocalDate().isAfter(limiteOriginal);
                            %>
                                <div class="plazo-banner <%= aTiempo ? "plazo-a-tiempo" : "plazo-vencida" %>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                    <span><%= aTiempo ? "Se respondió dentro del plazo" : "Se respondió fuera del plazo (vencía el " + limiteOriginal + ")" %></span>
                                </div>
                            <% } %>

                            <% for (Citas c : citasRelacionadas) {
                                Tipocita tc = tiposCitaPorId.get(c.getIdTipoCita());
                            %>
                                <div class="related-card">
                                    <div class="related-icon">
                                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                                    </div>
                                    <div class="related-card-text">
                                        <strong><%= tc != null ? tc.getNombre() : "Cita" %> — <%= c.getFecha() %> a las <%= c.getHora().toString().substring(0,5) %></strong>
                                        <span><%= c.isCancelada() ? "Cancelada" : "Confirmada" %></span>
                                    </div>
                                </div>
                            <% } %>

                            <% if (respondida) { %>
                                <div class="md-detail-section">
                                    <div class="md-detail-label">Respuesta</div>
                                    <div class="respuesta"><%= Controlador.Utilidades.esc(p.getRespuesta()) %></div>
                                </div>
                            <% } else { %>
                                <% if (!tieneCitaActiva) { %>
                                    <div class="md-detail-section">
                                        <a class="btn-agendar" href="<%= ctx %>/CitasServlet?accion=calendario&idPqrs=<%= p.getIdPqrs() %>">Agendar cita para responder</a>
                                    </div>
                                <% } else { %>
                                    <div class="md-detail-section">
                                        <div class="alert alert-success" style="margin-bottom:0;">
                                            Ya hay una cita agendada para atender esta PQRS. Cuando la atiendas, responde por escrito aquí abajo para marcarla como resuelta.
                                        </div>
                                    </div>
                                <% } %>
                                <div class="md-detail-section">
                                    <div class="md-detail-label">Responder por escrito</div>
                                    <form action="<%= ctx %>/PqrsServlet" method="POST">
                                        <input type="hidden" name="accion" value="responder">
                                        <input type="hidden" name="idPqrs" value="<%= p.getIdPqrs() %>">
                                        <textarea name="respuesta" placeholder="Escribe la respuesta para el residente..." required></textarea>
                                        <button type="submit" class="btn-sm" style="margin-top:8px;">Responder</button>
                                    </form>
                                </div>
                            <% } %>

                            <% if (!historial.isEmpty()) { %>
                                <details class="timeline-toggle">
                                    <summary>Ver seguimiento completo (<%= historial.size() %>)</summary>
                                    <div class="timeline">
                                        <div class="timeline-node">
                                            <div class="timeline-dot dot-inicio">
                                                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                                            </div>
                                            <div class="timeline-node-title">PQRS radicada</div>
                                            <div class="timeline-node-meta"><%= p.getFechaRegistro() != null ? sdfLarga.format(p.getFechaRegistro()) : "" %></div>
                                        </div>
                                        <% for (Seguimiento s : historial) {
                                            Usuario quien = usuariosPorId.get(s.getIdUsuario());
                                        %>
                                            <div class="timeline-node">
                                                <div class="timeline-dot dot-cita">
                                                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line></svg>
                                                </div>
                                                <div class="timeline-node-title"><%= Controlador.Utilidades.esc(s.getComentario()) %></div>
                                                <div class="timeline-node-meta"><%= s.getFechaRegistro() != null ? sdfLarga.format(s.getFechaRegistro()) : "" %> · <%= quien != null ? quien.getNombre() : "Admin" %></div>
                                            </div>
                                        <% } %>
                                    </div>
                                </details>
                            <% } %>
                        </div>
                    <%  }
                    } %>
                </div>
            </div>
        </main>
    </div>

    <%@ include file="_dropdownScript.jspf" %>
    <script>
        function seleccionar(id) {
            document.querySelectorAll('.md-item').forEach(function (el) { el.classList.remove('selected'); });
            document.querySelectorAll('.md-detail').forEach(function (el) { el.classList.remove('active'); });
            var item = document.getElementById('item-' + id);
            var detail = document.getElementById('detail-' + id);
            if (item) item.classList.add('selected');
            if (detail) detail.classList.add('active');
            var placeholder = document.getElementById('placeholder');
            if (placeholder) placeholder.style.display = 'none';
        }

        function filtrarLista() {
            var texto = document.getElementById('buscador').value.toLowerCase();
            var estado = document.getElementById('filtroEstado').value;
            var tipo = document.getElementById('filtroTipo').value;
            var esFiltroPlazo = (estado === 'vencida' || estado === 'porvencer');
            var visibles = 0;
            document.querySelectorAll('.md-item').forEach(function (item) {
                var coincideTexto = item.dataset.search.indexOf(texto) !== -1;
                var coincideEstado = !estado || (esFiltroPlazo ? item.dataset.plazo === estado : item.dataset.estado === estado);
                var coincideTipo = !tipo || item.dataset.tipo === tipo;
                var visible = coincideTexto && coincideEstado && coincideTipo;
                item.style.display = visible ? 'block' : 'none';
                if (visible) visibles++;
            });
            document.getElementById('contadorResultados').textContent = visibles + ' resultado' + (visibles === 1 ? '' : 's');
        }
        filtrarLista();
    </script>
</body>
</html>
