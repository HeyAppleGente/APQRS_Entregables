<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.TipoPqrs" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="Modelo.Seguimiento" %>
<%@ page import="Controlador.TipoPqrsDAO" %>
<%@ page import="Controlador.CitasDAO" %>
<%@ page import="Controlador.TipocitaDAO" %>
<%@ page import="Controlador.SeguimientoDAO" %>
<%@ page import="Controlador.PlazoUtil" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.List" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    Usuario usuarioActual = usuario;
    String rolLabel = "Residente";

    List<Pqrs> misPqrs = (List<Pqrs>) request.getAttribute("misPqrs");
    TipoPqrsDAO tipoPqrsDAO = new TipoPqrsDAO();
    CitasDAO citasDAO = new CitasDAO();
    TipocitaDAO tipoCitaDAO = new TipocitaDAO();
    SeguimientoDAO seguimientoDAO = new SeguimientoDAO();
    SimpleDateFormat sdfCorta = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat sdfLarga = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    List<TipoPqrs> tiposPqrs = tipoPqrsDAO.listarTodos();

    // ---------- Precarga en memoria (evita N+1) ----------
    java.util.Map<Integer, TipoPqrs> tiposPqrsPorId = new java.util.HashMap<>();
    for (TipoPqrs t : tiposPqrs) tiposPqrsPorId.put(t.getIdTipoPqrs(), t);

    java.util.Map<Integer, Tipocita> tiposCitaPorId = new java.util.HashMap<>();
    for (Tipocita t : tipoCitaDAO.listarTodos()) tiposCitaPorId.put(t.getIdTipoCita(), t);

    java.util.Map<Integer, List<Citas>> citasPorPqrs = new java.util.HashMap<>();
    for (Citas c : citasDAO.listarTodos()) {
        if (c.getIdPqrs() == null) continue;
        citasPorPqrs.computeIfAbsent(c.getIdPqrs(), k -> new java.util.ArrayList<Citas>()).add(c);
    }
    java.util.Map<Integer, List<Seguimiento>> seguimientoPorPqrs = new java.util.HashMap<>();
    for (Seguimiento s : seguimientoDAO.listarTodos()) {
        seguimientoPorPqrs.computeIfAbsent(s.getIdPqrs(), k -> new java.util.ArrayList<Seguimiento>()).add(s);
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis PQRS - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/DashResidente.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/dropdowns.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/masterDetail.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/timeline.css">
</head>
<body>
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<%= ctx %>/Vista/menuResidente.jsp">
                    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                    Inicio
                </a></li>
                <li class="active"><a href="<%= ctx %>/PqrsServlet">
                    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                    Mis PQRS
                </a></li>
                <li><a href="<%= ctx %>/CitasServlet">
                    <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                    Citas Presenciales
                </a></li>
            </ul>
        </div>
        <div class="sidebar-footer">Residente</div>
    </aside>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                <p>Residente</p>
            </div>
            <div class="header-actions">
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">
            <div class="page-title-row">
                <div>
                    <h1>Mis PQRS</h1>
                    <p class="page-subtitle">Gestiona todas tus solicitudes, quejas, reclamos y sugerencias</p>
                </div>
                <a class="btn-primary" href="<%= ctx %>/Vista/crearPqrs.jsp">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    Nueva PQRS
                </a>
            </div>

            <% if (request.getAttribute("mensaje") != null) { %>
                <div class="alert alert-success"><%= request.getAttribute("mensaje") %></div>
            <% } %>
            <% if (request.getAttribute("error") != null) { %>
                <div class="alert alert-danger"><%= request.getAttribute("error") %></div>
            <% } %>

            <div class="md-toolbar">
                <div class="md-search">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input type="text" id="buscador" placeholder="Buscar por ID o asunto..." oninput="filtrarLista()">
                </div>
                <div class="md-filters">
                    <select id="filtroEstado" onchange="filtrarLista()">
                        <option value="">Todos los estados</option>
                        <option value="pendiente">En proceso</option>
                        <option value="resuelta">Resueltas</option>
                    </select>
                    <select id="filtroTipo" onchange="filtrarLista()">
                        <option value="">Todos los tipos</option>
                        <% for (TipoPqrs tp : tiposPqrs) { %>
                            <option value="<%= tp.getNombreTipoPqrs() %>"><%= tp.getNombreTipoPqrs() %></option>
                        <% } %>
                    </select>
                    <span class="md-results-count" id="contadorResultados"></span>
                </div>
            </div>

            <div class="md-layout">
                <div class="md-list" id="listaPqrs">
                    <% if (misPqrs == null || misPqrs.isEmpty()) { %>
                        <div class="md-empty-list">Todavía no has radicado ninguna PQRS.</div>
                    <% } else {
                        for (Pqrs p : misPqrs) {
                            boolean resuelta = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
                            TipoPqrs tipo = tiposPqrsPorId.get(p.getIdTipoPqrs());
                            String busqueda = ("pqrs-" + p.getIdPqrs() + " " + p.getAsunto()).toLowerCase();

                            PlazoUtil.EstadoPlazo estadoPlazo = null;
                            if (!resuelta && p.getFechaRegistro() != null) {
                                int dias = tipo != null ? tipo.getDiasPlazo() : 15;
                                estadoPlazo = PlazoUtil.calcularEstado(p.getFechaRegistro().toLocalDateTime(), dias);
                            }
                    %>
                        <button class="md-item" id="item-<%= p.getIdPqrs() %>"
                                data-estado="<%= resuelta ? "resuelta" : "pendiente" %>"
                                data-tipo="<%= tipo != null ? tipo.getNombreTipoPqrs() : "" %>"
                                data-search="<%= busqueda %>"
                                onclick="seleccionar('<%= p.getIdPqrs() %>')">
                            <div class="md-item-top">
                                <span class="md-item-id">PQRS-<%= String.format("%03d", p.getIdPqrs()) %></span>
                                <span class="badge-pill <%= resuelta ? "badge-propietario" : "badge-arrendatario" %>">
                                    <%= resuelta ? "Resuelto" : "En Proceso" %>
                                </span>
                            </div>
                            <div class="md-item-date"><%= p.getFechaRegistro() != null ? sdfCorta.format(p.getFechaRegistro()) : "" %></div>
                            <div class="md-item-title"><%= Controlador.Utilidades.esc(p.getAsunto()) %></div>
                            <div class="md-item-tags">
                                <span class="tipo-tag"><%= tipo != null ? tipo.getNombreTipoPqrs() : "-" %></span>
                                <% if (estadoPlazo != null) { %>
                                    <span class="plazo-tag <%= estadoPlazo.vencida ? "plazo-vencida" : (estadoPlazo.porVencer ? "plazo-por-vencer" : "plazo-a-tiempo") %>">
                                        <%= estadoPlazo.vencida ? "Plazo vencido" : ("Respuesta en " + estadoPlazo.diasRestantes + "d aprox.") %>
                                    </span>
                                <% } %>
                            </div>
                        </button>
                    <%  }
                    } %>
                </div>

                <div class="md-detail-panel">
                    <div class="md-placeholder" id="placeholder">
                        <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                        <p>Selecciona una PQRS para ver los detalles</p>
                    </div>

                    <% if (misPqrs != null) {
                        for (Pqrs p : misPqrs) {
                            boolean resuelta = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
                            TipoPqrs tipo = tiposPqrsPorId.get(p.getIdTipoPqrs());
                            List<Citas> citasRelacionadas = citasPorPqrs.getOrDefault(p.getIdPqrs(), new java.util.ArrayList<Citas>());
                            List<Seguimiento> historial = seguimientoPorPqrs.getOrDefault(p.getIdPqrs(), new java.util.ArrayList<Seguimiento>());
                            int diasPlazoTipo = tipo != null ? tipo.getDiasPlazo() : 15;
                            PlazoUtil.EstadoPlazo estadoPlazoDetalle = (!resuelta && p.getFechaRegistro() != null)
                                    ? PlazoUtil.calcularEstado(p.getFechaRegistro().toLocalDateTime(), diasPlazoTipo) : null;
                    %>
                        <div class="md-detail" id="detail-<%= p.getIdPqrs() %>">
                            <div class="md-detail-header">
                                <h2>PQRS-<%= String.format("%03d", p.getIdPqrs()) %> · <%= Controlador.Utilidades.esc(p.getAsunto()) %></h2>
                                <span class="badge-pill <%= resuelta ? "badge-propietario" : "badge-arrendatario" %>">
                                    <%= resuelta ? "Resuelto" : "En Proceso" %>
                                </span>
                            </div>
                            <div class="md-detail-meta">
                                <%= tipo != null ? tipo.getNombreTipoPqrs() : "-" %> · Radicada el <%= p.getFechaRegistro() != null ? sdfCorta.format(p.getFechaRegistro()) : "-" %>
                            </div>

                            <div class="md-detail-section">
                                <div class="md-detail-label">Descripción</div>
                                <div class="md-detail-body"><%= Controlador.Utilidades.esc(p.getDescripcion()) %></div>
                            </div>

                            <% if (estadoPlazoDetalle != null) {
                                String claseBanner = estadoPlazoDetalle.vencida ? "plazo-vencida" : (estadoPlazoDetalle.porVencer ? "plazo-por-vencer" : "plazo-a-tiempo");
                            %>
                                <div class="plazo-banner <%= claseBanner %>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                    <span>
                                        <% if (estadoPlazoDetalle.vencida) { %>
                                            Administración se pasó del plazo estimado (<%= estadoPlazoDetalle.fechaLimite %>). Puedes escribir de nuevo si necesitas seguimiento.
                                        <% } else { %>
                                            Tiempo estimado de respuesta: <%= estadoPlazoDetalle.diasRestantes %> día(s) hábil(es) más (antes del <%= estadoPlazoDetalle.fechaLimite %>)
                                        <% } %>
                                    </span>
                                </div>
                            <% } %>

                            <% for (Citas c : citasRelacionadas) {
                                Tipocita tc = tiposCitaPorId.get(c.getIdTipoCita());
                            %>
                                <div class="related-card">
                                    <div class="related-icon">
                                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                                    </div>
                                    <div class="related-card-text">
                                        <strong><%= tc != null ? tc.getNombre() : "Cita" %> — <%= c.getFecha() %> a las <%= c.getHora().toString().substring(0,5) %></strong>
                                        <span><%= c.isCancelada() ? "Cancelada" : (c.getRespuesta() != null && !c.getRespuesta().isEmpty() ? "Confirmada" : "Pendiente de confirmación") %></span>
                                    </div>
                                </div>
                            <% } %>

                            <% if (resuelta) { %>
                                <div class="md-detail-section">
                                    <div class="md-detail-label">Respuesta de administración</div>
                                    <div class="respuesta"><%= Controlador.Utilidades.esc(p.getRespuesta()) %></div>
                                </div>
                            <% } %>

                            <% if (!historial.isEmpty()) { %>
                                <details class="timeline-toggle">
                                    <summary>Ver seguimiento completo</summary>
                                    <div class="timeline">
                                        <div class="timeline-node">
                                            <div class="timeline-dot dot-inicio">
                                                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                                            </div>
                                            <div class="timeline-node-title">PQRS radicada</div>
                                            <div class="timeline-node-meta"><%= p.getFechaRegistro() != null ? sdfLarga.format(p.getFechaRegistro()) : "" %></div>
                                        </div>
                                        <% for (Seguimiento s : historial) { %>
                                            <div class="timeline-node">
                                                <div class="timeline-dot dot-cita">
                                                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line></svg>
                                                </div>
                                                <div class="timeline-node-title">Actualización de administración</div>
                                                <div class="timeline-node-meta"><%= s.getFechaRegistro() != null ? sdfLarga.format(s.getFechaRegistro()) : "" %></div>
                                                <div class="timeline-node-body"><%= Controlador.Utilidades.esc(s.getComentario()) %></div>
                                            </div>
                                        <% } %>
                                        <% if (resuelta) { %>
                                            <div class="timeline-node">
                                                <div class="timeline-dot dot-resuelta">
                                                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                                </div>
                                                <div class="timeline-node-title">PQRS resuelta</div>
                                                <div class="timeline-node-meta"><%= p.getFechaRespuesta() != null ? sdfLarga.format(p.getFechaRespuesta()) : "" %></div>
                                            </div>
                                        <% } %>
                                    </div>
                                </details>
                            <% } %>
                        </div>
                    <%  }
                    } %>
                </div>
            </div>
        </main>
    </div>

    <%@ include file="_dropdownScript.jspf" %>
    <script>
        function seleccionar(id) {
            document.querySelectorAll('.md-item').forEach(function (el) { el.classList.remove('selected'); });
            document.querySelectorAll('.md-detail').forEach(function (el) { el.classList.remove('active'); });
            var item = document.getElementById('item-' + id);
            var detail = document.getElementById('detail-' + id);
            if (item) item.classList.add('selected');
            if (detail) detail.classList.add('active');
            var placeholder = document.getElementById('placeholder');
            if (placeholder) placeholder.style.display = 'none';
        }
        function filtrarLista() {
            var texto = document.getElementById('buscador').value.toLowerCase();
            var estado = document.getElementById('filtroEstado').value;
            var tipo = document.getElementById('filtroTipo').value;
            var visibles = 0;
            document.querySelectorAll('.md-item').forEach(function (item) {
                var coincideTexto = item.dataset.search.indexOf(texto) !== -1;
                var coincideEstado = !estado || item.dataset.estado === estado;
                var coincideTipo = !tipo || item.dataset.tipo === tipo;
                var visible = coincideTexto && coincideEstado && coincideTipo;
                item.style.display = visible ? 'block' : 'none';
                if (visible) visibles++;
            });
            document.getElementById('contadorResultados').textContent = visibles + ' de ' + document.querySelectorAll('.md-item').length + ' resultados';
        }
        filtrarLista();
    </script>
</body>
</html>
