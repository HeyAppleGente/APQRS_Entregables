<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    Integer resetUsuarioId = (Integer) session.getAttribute("resetUsuarioId");
    String resetUsuarioNombre = (String) session.getAttribute("resetUsuarioNombre");
    String resetCorreo = (String) session.getAttribute("resetCorreo");
    Long resetCodigoTimestamp = (Long) session.getAttribute("resetCodigoTimestamp");
    Boolean resetCodigoVerificado = (Boolean) session.getAttribute("resetCodigoVerificado");

    // El código vence a los 10 minutos por seguridad
    boolean codigoVigente = resetUsuarioId != null && resetCodigoTimestamp != null
            && (System.currentTimeMillis() - resetCodigoTimestamp) <= (10 * 60 * 1000);

    if (resetUsuarioId != null && !codigoVigente) {
        session.removeAttribute("resetUsuarioId");
        session.removeAttribute("resetUsuarioNombre");
        session.removeAttribute("resetCorreo");
        session.removeAttribute("resetCodigo");
        session.removeAttribute("resetCodigoTimestamp");
        session.removeAttribute("resetCodigoVerificado");
        resetUsuarioId = null;
    }

    // paso 1 = pedir correo | paso 2 = pedir código | paso 3 = nueva contraseña
    int paso = 1;
    if (codigoVigente) {
        paso = (resetCodigoVerificado != null && resetCodigoVerificado) ? 3 : 2;
    }

    String error = (String) request.getAttribute("error");
    String mensaje = (String) request.getAttribute("mensaje");
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/Style.css">
</head>
<body>
    <div class="login-card">
        <div class="icon-wrap">
            <svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                <rect x="5" y="11" width="14" height="9" rx="2"/>
                <path d="M8 11V8a4 4 0 0 1 8 0v3"/>
            </svg>
        </div>

        <% if (paso == 1) { %>

            <h1>Recuperar contraseña</h1>
            <p class="subtitle">Te enviaremos un código a tu correo</p>

            <% if (error != null) { %><div class="error-msg"><%= error %></div><% } %>

            <p class="hint-msg">Ingresa el correo con el que te registraste. Te vamos a enviar un código de verificación de 6 dígitos.</p>

            <form action="<%= ctx %>/RecuperarPasswordServlet" method="post">
                <input type="hidden" name="accion" value="enviarCodigo">
                <div class="field">
                    <label for="correo">Correo</label>
                    <div class="input-wrap">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                            <path d="M3 6h18v12H3z"/>
                            <path d="M3 6l9 7 9-7"/>
                        </svg>
                        <input type="email" id="correo" name="correo" placeholder="correo@ejemplo.com" required>
                    </div>
                </div>

                <button type="submit" class="btn-login">Enviar código</button>
            </form>

            <a href="<%= ctx %>/Vista/login.jsp" class="forgot" style="text-align:center; margin-top:16px;">&larr; Volver a iniciar sesión</a>

        <% } else if (paso == 2) { %>

            <h1>Verifica tu código</h1>
            <p class="subtitle">Enviado a <%= resetCorreo %></p>

            <% if (error != null) { %><div class="error-msg"><%= error %></div><% } %>
            <% if (mensaje != null) { %><div class="success-msg"><%= mensaje %></div><% } %>

            <p class="hint-msg">Revisa tu bandeja de entrada (y la carpeta de spam) e ingresa el código de 6 dígitos que te enviamos. Vence en 10 minutos.</p>

            <form action="<%= ctx %>/RecuperarPasswordServlet" method="post">
                <input type="hidden" name="accion" value="verificarCodigo">
                <div class="field">
                    <label for="codigo">Código de verificación</label>
                    <div class="input-wrap">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                            <rect x="3" y="4" width="18" height="16" rx="2"/>
                            <line x1="7" y1="9" x2="17" y2="9"/>
                            <line x1="7" y1="13" x2="13" y2="13"/>
                        </svg>
                        <input type="text" id="codigo" name="codigo" placeholder="123456" maxlength="6"
                               inputmode="numeric" pattern="[0-9]{6}" style="text-align:center; letter-spacing:4px; font-weight:700;" required autofocus>
                    </div>
                </div>

                <button type="submit" class="btn-login">Verificar código</button>
            </form>

            <form action="<%= ctx %>/RecuperarPasswordServlet" method="post" style="margin-top:10px;">
                <input type="hidden" name="accion" value="reenviarCodigo">
                <button type="submit" class="forgot" style="background:none;border:none;width:100%;cursor:pointer;text-align:center;">¿No te llegó? Reenviar código</button>
            </form>

            <form action="<%= ctx %>/RecuperarPasswordServlet" method="post" style="margin-top:4px;">
                <input type="hidden" name="accion" value="cancelar">
                <button type="submit" class="forgot" style="background:none;border:none;width:100%;cursor:pointer;text-align:center;">Cancelar</button>
            </form>

        <% } else { %>

            <h1>Nueva contraseña</h1>
            <p class="subtitle">Hola, <%= resetUsuarioNombre %></p>

            <% if (error != null) { %><div class="error-msg"><%= error %></div><% } %>

            <p class="hint-msg">Tu código fue verificado. Crea tu nueva contraseña (mínimo 6 caracteres).</p>

            <form action="<%= ctx %>/RecuperarPasswordServlet" method="post">
                <input type="hidden" name="accion" value="cambiar">
                <div class="field">
                    <label for="nuevaPassword">Nueva contraseña</label>
                    <div class="input-wrap">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                            <rect x="5" y="11" width="14" height="9" rx="2"/>
                            <path d="M8 11V8a4 4 0 0 1 8 0v3"/>
                        </svg>
                        <input type="password" id="nuevaPassword" name="nuevaPassword" placeholder="••••••••" minlength="6" required>
                    </div>
                </div>

                <div class="field">
                    <label for="confirmarPassword">Confirmar contraseña</label>
                    <div class="input-wrap">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                            <rect x="5" y="11" width="14" height="9" rx="2"/>
                            <path d="M8 11V8a4 4 0 0 1 8 0v3"/>
                        </svg>
                        <input type="password" id="confirmarPassword" name="confirmarPassword" placeholder="••••••••" minlength="6" required>
                    </div>
                </div>

                <button type="submit" class="btn-login">Guardar nueva contraseña</button>
            </form>

            <form action="<%= ctx %>/RecuperarPasswordServlet" method="post" style="margin-top:12px;">
                <input type="hidden" name="accion" value="cancelar">
                <button type="submit" class="forgot" style="background:none;border:none;width:100%;cursor:pointer;text-align:center;">Cancelar</button>
            </form>

        <% } %>
    </div>
</body>
</html>
