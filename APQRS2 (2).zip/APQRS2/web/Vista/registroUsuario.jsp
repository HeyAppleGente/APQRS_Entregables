<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Cuenta de Residente - SISTEMA APQRS</title>
    
    <!-- Archivo CSS Externo -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/Vista/Css/registro.css">
    
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>

    <div class="logo-container">
        <div class="logo-icon"><i data-lucide="building-2"></i></div>
        SISTEMA APQRS
    </div>

    <div class="card">
        <div class="card-header">
            <h1>Crear Cuenta de Residente</h1>
            <p>Ingresa tus datos para registrarte en la copropiedad</p>
        </div>

        <div class="card-body">
            <% if (request.getAttribute("error") != null) { %>
                <div class="alert alert-danger"><%= request.getAttribute("error") %></div>
            <% } %>
            <% if (request.getAttribute("mensaje") != null) { %>
                <div class="alert alert-success"><%= request.getAttribute("mensaje") %></div>
            <% } %>

            <form action="${pageContext.request.contextPath}/UsuarioServlet" method="POST">
                
                <!-- DOCUMENTO DE IDENTIDAD -->
                <div class="section-title">
                    <span class="badge-num">1</span>
                    <span>Documento de Identidad</span>
                    <span class="line"></span>
                </div>
                <div class="grid-2">
                    <div class="form-group">
                        <label>Tipo de Documento <span class="req">*</span></label>
                        <select name="tipoDocumento" required>
                            <option value="" disabled selected>Seleccione tipo...</option>
                            <option value="1">Cédula de Ciudadanía</option>
                            <option value="2">Cédula de Extranjería</option>
                            <option value="3">Pasaporte</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Número de Documento <span class="req">*</span></label>
                        <div class="input-container">
                            <i data-lucide="hash" class="input-icon"></i>
                            <input type="text" name="numeroDocumento" class="has-icon" placeholder="Ej. 1000000001" required>
                        </div>
                    </div>
                </div>

                <!-- DATOS PERSONALES -->
                <div class="section-title">
                    <span class="badge-num">2</span>
                    <span>Datos Personales</span>
                    <span class="line"></span>
                </div>
                <div class="grid-2">
                    <div class="form-group">
                        <label>Nombre <span class="req">*</span></label>
                        <div class="input-container">
                            <i data-lucide="user" class="input-icon"></i>
                            <input type="text" name="nombre" class="has-icon" placeholder="Ej. Carlos" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Apellido <span class="req">*</span></label>
                        <div class="input-container">
                            <i data-lucide="user" class="input-icon"></i>
                            <input type="text" name="apellido" class="has-icon" placeholder="Ej. Ramírez" required>
                        </div>
                    </div>
                </div>

                <!-- UBICACIÓN EN LA COPROPIEDAD -->
                <div class="section-title">
                    <span class="badge-num">3</span>
                    <span>Ubicación en la Copropiedad</span>
                    <span class="line"></span>
                </div>
                <div class="location-box">
                    <div class="info-note">
                        <i data-lucide="building" class="info-note-icon"></i>
                        <span>Selecciona la unidad donde resides para asociarla a tu perfil</span>
                    </div>
                    <div class="grid-2">
                        <div class="form-group no-margin-bottom">
                            <label>Torre / Bloque <span class="req">*</span></label>
                            <div class="input-container">
                                <i data-lucide="building" class="input-icon"></i>
                                <input type="text" name="torre" class="has-icon" placeholder="Ej. 4, B, Interior 15..." required>
                            </div>
                            <span class="field-hint">Las torres 1, 10 y 32 solo tienen 2 apartamentos por piso (101, 102, 201, 202... hasta el 5º piso).</span>
                        </div>
                        <div class="form-group no-margin-bottom">
                            <label>Número de Apartamento <span class="req">*</span></label>
                            <div class="input-container">
                                <i data-lucide="hash" class="input-icon"></i>
                                <input type="text" name="numeroApartamento" class="has-icon" placeholder="Ej. 403" required>
                            </div>
                        </div>
                    </div>
                    <div class="grid-2" style="margin-top:16px;">
                        <div class="form-group no-margin-bottom">
                            <label>Ocupas el apartamento como <span class="req">*</span></label>
                            <select name="tipoOcupante" required>
                                <option value="Propietario" selected>Propietario</option>
                                <option value="Arrendatario">Arrendatario</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- CONTACTO Y CREDENCIALES -->
                <div class="section-title">
                    <span class="badge-num">4</span>
                    <span>Contacto y Credenciales</span>
                    <span class="line"></span>
                </div>
                <div class="grid-2">
                    <div class="form-group">
                        <label>Teléfono <span class="req">*</span></label>
                        <div class="input-container">
                            <i data-lucide="phone" class="input-icon"></i>
                            <input type="tel" name="telefono" class="has-icon" placeholder="Ej. 3000000001" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Correo Electrónico <span class="req">*</span></label>
                        <div class="input-container">
                            <i data-lucide="mail" class="input-icon"></i>
                            <input type="email" name="correo" class="has-icon" placeholder="correo@ejemplo.com" required>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>Contraseña <span class="req">*</span></label>
                    <div class="input-container">
                        <i data-lucide="lock" class="input-icon"></i>
                        <input type="password" name="password" minlength="8" class="has-icon" placeholder="Mínimo 8 caracteres" required>
                    </div>
                </div>

                <button type="submit" class="btn-submit">Registrarse</button>
            </form>

            <div class="login-link">
                ¿Ya tienes cuenta? <a href="${pageContext.request.contextPath}/Vista/login.jsp">Inicia sesión aquí</a>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>