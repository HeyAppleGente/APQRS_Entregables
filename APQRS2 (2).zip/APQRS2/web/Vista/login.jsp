<%@ page contentType="text/html; charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conjunto Residencial - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/Vista/Css/Style.css">
</head>
<body>
    <div class="login-card">
        <div class="icon-wrap">
            <svg viewBox="0 0 24 24" fill="none" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                <path d="M9 21V9a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v12"/>
                <path d="M5 21V6a1 1 0 0 1 1-1h3v16"/>
                <path d="M15 21V6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v15"/>
                <line x1="3" y1="21" x2="21" y2="21"/>
                <line x1="10.5" y1="11" x2="12.5" y2="11"/>
                <line x1="10.5" y1="14" x2="12.5" y2="14"/>
                <line x1="10.5" y1="17" x2="12.5" y2="17"/>
            </svg>
        </div>

        <h1>Conjunto Residencial</h1>
        <p class="subtitle">Sistema APQRS</p>

        <%
            if ("1".equals(request.getParameter("recuperada"))) {
        %>
            <div class="success-msg">Tu contraseña fue actualizada. Ya puedes iniciar sesión con ella.</div>
        <%
            }
        %>

        <%
            String error = request.getParameter("error");
            if (error != null) {
        %>
            <div class="error-msg">
                <%
                    if ("credenciales".equals(error)) {
                %>
                    Correo o contraseña incorrectos.
                <%
                    } else if ("vacio".equals(error)) {
                %>
                    Debes ingresar correo y contraseña.
                <%
                    } else {
                %>
                    Ocurrió un error al iniciar sesión. Intenta de nuevo.
                <%
                    }
                %>
            </div>
        <%
            }
        %>

        <form action="<%= request.getContextPath() %>/login" method="post">
            <div class="field">
                <label for="email">Email</label>
                <div class="input-wrap">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                        <path d="M3 6h18v12H3z"/>
                        <path d="M3 6l9 7 9-7"/>
                    </svg>
                    <input type="email" id="email" name="email" placeholder="correo@ejemplo.com" required>
                </div>
            </div>

            <div class="field">
                <label for="password">Contraseña</label>
                <div class="input-wrap">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
                        <rect x="5" y="11" width="14" height="9" rx="2"/>
                        <path d="M8 11V8a4 4 0 0 1 8 0v3"/>
                    </svg>
                    <input type="password" id="password" name="password" placeholder="••••••••" required>
                </div>
            </div>
            <a href="<%= request.getContextPath() %>/Vista/recuperar.jsp" class="forgot">¿Olvidaste tu contraseña?</a>
            <button type="submit" class="btn-login">Iniciar Sesión</button>
            <a href="<%= request.getContextPath() %>/Vista/registroUsuario.jsp" class="forgot">Regístrate aquí</a>
        </form>
    </div>
</body>
</html>
