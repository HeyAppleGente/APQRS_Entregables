<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.ConfiguracionAgenda" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null || usuario.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    ConfiguracionAgenda configAgenda = (ConfiguracionAgenda) request.getAttribute("configAgenda");
    String error = (String) request.getAttribute("error");
    String[] nombresDias = {"", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Disponibilidad - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <a href="<%= ctx %>/CitasServlet?vista=admin&tab=horario">&larr; Volver a Control de Citas</a>
        </div>

        <div class="card">
            <h1>Configurar Disponibilidad</h1>
            <p class="sub">Define el horario de atención y los cupos disponibles para agendar citas.</p>

            <% if (error != null) { %><div class="alert alert-danger"><%= error %></div><% } %>

            <form method="post" action="<%= ctx %>/CitasServlet">
                <input type="hidden" name="accion" value="guardarDisponibilidad">

                <div class="form-row">
                    <div class="form-group">
                        <label for="horaInicio">Hora de inicio</label>
                        <input type="time" id="horaInicio" name="horaInicio" value="<%= configAgenda.getHoraInicio().toString().substring(0,5) %>" required>
                    </div>
                    <div class="form-group">
                        <label for="horaFin">Hora de fin</label>
                        <input type="time" id="horaFin" name="horaFin" value="<%= configAgenda.getHoraFin().toString().substring(0,5) %>" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="duracionSlot">Duración de cada cupo (minutos)</label>
                    <select id="duracionSlot" name="duracionSlot">
                        <option value="15" <%= configAgenda.getDuracionSlotMinutos() == 15 ? "selected" : "" %>>15 minutos</option>
                        <option value="30" <%= configAgenda.getDuracionSlotMinutos() == 30 ? "selected" : "" %>>30 minutos</option>
                        <option value="45" <%= configAgenda.getDuracionSlotMinutos() == 45 ? "selected" : "" %>>45 minutos</option>
                        <option value="60" <%= configAgenda.getDuracionSlotMinutos() == 60 ? "selected" : "" %>>60 minutos</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Días laborales</label>
                    <div class="dias-checklist">
                        <% for (int d = 1; d <= 7; d++) { %>
                            <label class="dia-check">
                                <input type="checkbox" name="dias" value="<%= d %>" <%= configAgenda.esDiaLaboral(d) ? "checked" : "" %>>
                                <%= nombresDias[d] %>
                            </label>
                        <% } %>
                    </div>
                </div>

                <button type="submit" class="btn">Guardar disponibilidad</button>
            </form>
        </div>
    </div>
</body>
</html>
