<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    boolean esAdmin = usuario.getIdRol() == 1;
    String volverA = esAdmin ? ctx + "/Vista/menuAdmin.jsp" : ctx + "/Vista/menuResidente.jsp";
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuración - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <a href="<%= volverA %>">&larr; Volver al panel</a>
        </div>
        <div class="card">
            <h1>Configuración</h1>
            <p class="sub">Preferencias de tu cuenta</p>
            <div class="detail-grid">
                <div><span class="detail-label">Correo de la cuenta</span><span class="detail-value"><%= usuario.getCorreo() %></span></div>
                <div><span class="detail-label">Rol</span><span class="detail-value"><%= esAdmin ? "Administrador" : "Residente" %></span></div>
            </div>
            <p class="hint" style="margin-top:20px;">
                Para cambiar tu contraseña o tu teléfono, ve a <a href="<%= ctx %>/Vista/perfil.jsp">Mi Perfil</a>.
                <% if (esAdmin) { %>
                    Para cambiar el horario de atención de citas, ve a
                    <a href="<%= ctx %>/CitasServlet?accion=disponibilidad">Configurar Disponibilidad</a>.
                <% } %>
            </p>
        </div>
    </div>
</body>
</html>
