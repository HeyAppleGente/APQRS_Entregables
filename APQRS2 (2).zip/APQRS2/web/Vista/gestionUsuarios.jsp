<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.Bloque" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%
    Usuario admin = (Usuario) session.getAttribute("usuario");
    if (admin == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    if (admin.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/menuResidente.jsp");
        return;
    }

    List<Usuario> residentes = (List<Usuario>) request.getAttribute("residentes");
    Map<Integer, Apartamento> apartamentos = (Map<Integer, Apartamento>) request.getAttribute("apartamentos");
    Map<Integer, Bloque> bloques = (Map<Integer, Bloque>) request.getAttribute("bloques");
    int totalResidentes = (Integer) request.getAttribute("totalResidentes");
    int propietarios = (Integer) request.getAttribute("propietarios");
    int arrendatarios = (Integer) request.getAttribute("arrendatarios");
    int porcentajeOcupacion = (Integer) request.getAttribute("porcentajeOcupacion");
    String q = (String) request.getAttribute("q");
    String estadoFiltro = (String) request.getAttribute("estado");
    int pagina = (Integer) request.getAttribute("pagina");
    int totalPaginas = (Integer) request.getAttribute("totalPaginas");
    int desdeMostrado = (Integer) request.getAttribute("desdeMostrado");
    int hastaMostrado = (Integer) request.getAttribute("hastaMostrado");
    int totalFiltrados = (Integer) request.getAttribute("totalFiltrados");
    String mensaje = (String) request.getAttribute("mensaje");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuarios y Unidades - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/DashAdmin.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/gestionUsuarios.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/dropdowns.css">
</head>
<body>

    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li>
                    <a href="<%= ctx %>/Vista/menuAdmin.jsp">
                        <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                        Panel General
                    </a>
                </li>
                <li class="active">
                    <a href="<%= ctx %>/UsuarioAdminServlet">
                        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        Usuarios y Unidades
                    </a>
                </li>
                <li>
                    <a href="<%= ctx %>/PqrsServlet?vista=admin">
                        <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                        Gestión PQRS
                    </a>
                </li>
                <li>
                    <a href="<%= ctx %>/CitasServlet?accion=calendario">
                        <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                        Control de Citas
                    </a>
                </li>
            </ul>
        </div>
        <div class="sidebar-footer">Administrador</div>
    </aside>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= Controlador.Utilidades.esc(admin.getNombre()) %> <%= admin.getApellido() != null ? admin.getApellido() : "" %></h2>
                <p>Administrador</p>
            </div>
            <div class="header-actions">
                <%
                    Usuario usuarioActual = admin;
                    String rolLabel = "Administrador";
                    Controlador.NotificacionesDAO notificacionesDAO = new Controlador.NotificacionesDAO();
                    java.util.List<Modelo.Notificaciones> notificacionesAdmin = notificacionesDAO.listarParaAdmin(10);
                    int noLeidasAdmin = notificacionesDAO.contarNoLeidasParaAdmin();
                %>
                <%@ include file="_notifBell.jspf" %>
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">

            <div class="page-title-row">
                <div>
                    <h1>Gestión de Usuarios y Unidades</h1>
                    <p class="page-subtitle">Administra residentes y propiedades del conjunto</p>
                </div>
                <div class="page-title-actions">
                    <a class="btn-outline" href="<%= ctx %>/UsuarioAdminServlet?accion=exportar">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
                        Exportar
                    </a>
                    <a class="btn-primary" href="<%= ctx %>/UsuarioAdminServlet?accion=nuevo">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                        Nuevo Residente
                    </a>
                </div>
            </div>

            <% if (mensaje != null) { %>
                <div class="alert alert-success"><%= mensaje %></div>
            <% } %>

            <div class="metrics-usuarios">
                <div class="card">
                    <div class="stat-label">Total Residentes</div>
                    <div class="stat-value"><%= totalResidentes %></div>
                </div>
                <div class="card">
                    <div class="stat-label">Propietarios</div>
                    <div class="stat-value"><%= propietarios %></div>
                </div>
                <div class="card">
                    <div class="stat-label">Arrendatarios</div>
                    <div class="stat-value"><%= arrendatarios %></div>
                </div>
                <div class="card">
                    <div class="stat-label">Unidades Ocupadas</div>
                    <div class="stat-value stat-value-success"><%= porcentajeOcupacion %>%</div>
                </div>
            </div>

            <div class="panel">
                <form method="get" action="<%= ctx %>/UsuarioAdminServlet" class="filter-bar">
                    <div class="search-box">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        <input type="text" name="q" placeholder="Buscar por nombre, unidad, correo..." value="<%= q != null ? q : "" %>">
                    </div>
                    <select name="estado" class="filter-select" onchange="this.form.submit()">
                        <option value="Todos" <%= "Todos".equals(estadoFiltro) ? "selected" : "" %>>Todos</option>
                        <option value="Propietario" <%= "Propietario".equals(estadoFiltro) ? "selected" : "" %>>Propietarios</option>
                        <option value="Arrendatario" <%= "Arrendatario".equals(estadoFiltro) ? "selected" : "" %>>Arrendatarios</option>
                    </select>
                    <button type="submit" class="btn-outline btn-search">Buscar</button>
                </form>

                <% if (residentes == null || residentes.isEmpty()) { %>
                    <div class="empty-state">No se encontraron residentes con esos criterios.</div>
                <% } else { %>
                <table class="usuarios-table">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Unidad</th>
                            <th>Correo</th>
                            <th>Teléfono</th>
                            <th>Estado</th>
                            <th>Fecha Registro</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (Usuario u : residentes) {
                            Apartamento apto = apartamentos.get(u.getIdApartamento());
                            Bloque bloque = (apto != null) ? bloques.get(apto.getIdBloque()) : null;
                            String unidad = (bloque != null ? "Torre " + bloque.getNombreBloque() : "Torre -") + " - Apto " + (apto != null ? apto.getNumero() : "-");
                            boolean arrendatario = "Arrendatario".equalsIgnoreCase(u.getTipoOcupante());
                        %>
                        <tr>
                            <td class="cell-nombre"><%= Controlador.Utilidades.esc(u.getNombre()) %> <%= Controlador.Utilidades.esc(u.getApellido()) %></td>
                            <td><%= unidad %></td>
                            <td class="cell-muted"><%= Controlador.Utilidades.esc(u.getCorreo()) %></td>
                            <td class="cell-muted"><%= u.getTelefono() %></td>
                            <td>
                                <span class="badge-pill <%= arrendatario ? "badge-arrendatario" : "badge-propietario" %>">
                                    <%= u.getTipoOcupante() %>
                                </span>
                            </td>
                            <td class="cell-muted"><%= u.getFechaRegistro() != null ? sdf.format(u.getFechaRegistro()) : "-" %></td>
                            <td>
                                <div class="row-actions">
                                    <a href="<%= ctx %>/UsuarioAdminServlet?accion=ver&id=<%= u.getIdUsuario() %>" title="Ver">
                                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                    </a>
                                    <a href="<%= ctx %>/UsuarioAdminServlet?accion=editar&id=<%= u.getIdUsuario() %>" title="Editar">
                                        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"></path></svg>
                                    </a>
                                    <form method="post" action="<%= ctx %>/UsuarioAdminServlet" class="inline-form"
                                          onsubmit="return confirm('¿Restablecer la contraseña de este residente al valor por defecto?');">
                                        <input type="hidden" name="accion" value="resetear">
                                        <input type="hidden" name="idUsuario" value="<%= u.getIdUsuario() %>">
                                        <button type="submit" title="Restablecer contraseña">
                                            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"></polyline><path d="M3.51 15a9 9 0 1 0 .49-9.36L1 10"></path></svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>

                <div class="pagination-bar">
                    <span class="pagination-info">Mostrando <%= desdeMostrado %>–<%= hastaMostrado %> de <%= totalFiltrados %></span>
                    <div class="pagination-controls">
                        <a class="page-btn <%= pagina <= 1 ? "disabled" : "" %>"
                           href="<%= ctx %>/UsuarioAdminServlet?pagina=<%= Math.max(1, pagina - 1) %>&q=<%= q != null ? q : "" %>&estado=<%= estadoFiltro %>">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
                        </a>
                        <a class="page-btn <%= pagina >= totalPaginas ? "disabled" : "" %>"
                           href="<%= ctx %>/UsuarioAdminServlet?pagina=<%= Math.min(totalPaginas, pagina + 1) %>&q=<%= q != null ? q : "" %>&estado=<%= estadoFiltro %>">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>
                        </a>
                    </div>
                </div>
                <% } %>
            </div>
        </main>
    </div>
    <%@ include file="_dropdownScript.jspf" %>
</body>
</html>
