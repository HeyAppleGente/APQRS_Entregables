<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.Seguimiento" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.Bloque" %>
<%@ page import="Modelo.ConfiguracionAgenda" %>
<%@ page import="Modelo.Notificaciones" %>
<%@ page import="Controlador.UsuarioDAO" %>
<%@ page import="Controlador.TipocitaDAO" %>
<%@ page import="Controlador.PqrsDAO" %>
<%@ page import="Controlador.ApartamentoDAO" %>
<%@ page import="Controlador.BloqueDAO" %>
<%@ page import="Controlador.SeguimientoDAO" %>
<%@ page import="Controlador.NotificacionesDAO" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.time.format.TextStyle" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Locale" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null || usuario.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    Usuario usuarioActual = usuario;
    String rolLabel = "Administrador";
    Locale es = new Locale("es", "ES");

    UsuarioDAO usuarioDAO = new UsuarioDAO();
    TipocitaDAO tipoCitaDAO = new TipocitaDAO();
    PqrsDAO pqrsDAO = new PqrsDAO();
    ApartamentoDAO apartamentoDAO = new ApartamentoDAO();
    BloqueDAO bloqueDAO = new BloqueDAO();
    SeguimientoDAO seguimientoDAO = new SeguimientoDAO();
    NotificacionesDAO notificacionesDAO = new NotificacionesDAO();
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    List<Notificaciones> notificacionesAdmin = notificacionesDAO.listarParaAdmin(10);
    int noLeidasAdmin = notificacionesDAO.contarNoLeidasParaAdmin();

    String tab = (String) request.getAttribute("tab");
    if (tab == null) tab = "hoy";
    List<Citas> citasHoy = (List<Citas>) request.getAttribute("citasHoy");
    List<Citas> citasProximas = (List<Citas>) request.getAttribute("citasProximas");
    int totalCitasHoy = (Integer) request.getAttribute("totalCitasHoy");
    int totalEstaSemana = (Integer) request.getAttribute("totalEstaSemana");
    int tasaAsistencia = (Integer) request.getAttribute("tasaAsistencia");
    ConfiguracionAgenda configAgenda = (ConfiguracionAgenda) request.getAttribute("configAgenda");
    String mensaje = (String) request.getAttribute("mensaje");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control de Citas Presenciales - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/DashAdmin.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/gestionUsuarios.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/calendarioCitas.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/dropdowns.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/timeline.css">
</head>
<body>
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<%= ctx %>/Vista/menuAdmin.jsp">
                    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                    Panel General
                </a></li>
                <li><a href="<%= ctx %>/UsuarioAdminServlet">
                    <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                    Usuarios y Unidades
                </a></li>
                <li><a href="<%= ctx %>/PqrsServlet?vista=admin">
                    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                    Gestión PQRS
                </a></li>
                <li class="active"><a href="<%= ctx %>/CitasServlet?vista=admin">
                    <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                    Control de Citas
                </a></li>
            </ul>
        </div>
        <div class="sidebar-footer">Administrador</div>
    </aside>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                <p>Administrador</p>
            </div>
            <div class="header-actions">
                <%@ include file="_notifBell.jspf" %>
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">
            <div class="page-title-row">
                <div>
                    <h1>Control de Citas Presenciales</h1>
                    <p class="page-subtitle">Gestiona las citas programadas con residentes</p>
                </div>
                <div class="page-title-actions">
                    <a class="btn-outline" href="<%= ctx %>/CitasServlet?accion=calendario">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                        Ver Calendario
                    </a>
                    <a class="btn-primary" href="<%= ctx %>/CitasServlet?accion=disponibilidad">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                        Configurar Disponibilidad
                    </a>
                </div>
            </div>

            <% if (mensaje != null) { %><div class="alert alert-success"><%= mensaje %></div><% } %>

            <div class="metrics-usuarios metrics-tres-columnas">
                <div class="card"><div class="stat-label">Citas Hoy</div><div class="stat-value"><%= totalCitasHoy %></div></div>
                <div class="card"><div class="stat-label">Esta Semana</div><div class="stat-value"><%= totalEstaSemana %></div></div>
                <div class="card"><div class="stat-label">Tasa Asistencia</div><div class="stat-value stat-value-success"><%= tasaAsistencia %>%</div></div>
            </div>

            <div class="tabs-bar">
                <a class="tab-link <%= "hoy".equals(tab) ? "active" : "" %>" href="<%= ctx %>/CitasServlet?vista=admin&tab=hoy">Hoy</a>
                <a class="tab-link <%= "proximas".equals(tab) ? "active" : "" %>" href="<%= ctx %>/CitasServlet?vista=admin&tab=proximas">Próximas Citas</a>
                <a class="tab-link <%= "horario".equals(tab) ? "active" : "" %>" href="<%= ctx %>/CitasServlet?vista=admin&tab=horario">Horario Semanal</a>
            </div>

            <% if ("hoy".equals(tab)) { %>
                <div class="calendar-card">
                    <h2 class="day-title">Línea de Tiempo - Hoy</h2>
                    <p class="page-subtitle" style="margin-bottom:20px;">
                        <%
                            java.time.LocalDate hoy = java.time.LocalDate.now();
                            String nombreDiaHoy = hoy.getDayOfWeek().getDisplayName(TextStyle.FULL, es);
                            String nombreMesHoy = hoy.getMonth().getDisplayName(TextStyle.FULL, es);
                        %>
                        <%= nombreDiaHoy.substring(0,1).toUpperCase() + nombreDiaHoy.substring(1) %>, <%= hoy.getDayOfMonth() %> de <%= nombreMesHoy %> <%= hoy.getYear() %>
                    </p>

                    <% if (citasHoy == null || citasHoy.isEmpty()) { %>
                        <p class="empty-state">No hay citas agendadas para hoy.</p>
                        <% if (citasProximas != null && !citasProximas.isEmpty()) { %>
                            <div class="alert alert-success" style="margin-top:0;">
                                Tienes <%= citasProximas.size() %> cita<%= citasProximas.size() == 1 ? "" : "s" %> próxima<%= citasProximas.size() == 1 ? "" : "s" %> agendada<%= citasProximas.size() == 1 ? "" : "s" %> para otros días.
                                <a href="<%= ctx %>/CitasServlet?vista=admin&tab=proximas" style="font-weight:700;">Ver Próximas Citas &rarr;</a>
                            </div>
                        <% } %>
                    <% } else { %>
                        <div class="agenda-timeline">
                            <% for (Citas c : citasHoy) {
                                Usuario titular = usuarioDAO.consultar(c.getIdUsuario());
                                Apartamento apto = titular != null ? apartamentoDAO.consultar(titular.getIdApartamento()) : null;
                                Bloque bloque = apto != null ? bloqueDAO.consultar(apto.getIdBloque()) : null;
                                Pqrs pqrsLigada = (c.getIdPqrs() != null) ? pqrsDAO.consultar(c.getIdPqrs()) : null;
                                List<Seguimiento> historial = seguimientoDAO.listarPorCitas(c.getIdCitas());
                            %>
                            <div class="agenda-item">
                                <div class="agenda-time-circle"><%= c.getHora().toString().substring(0,5) %></div>
                                <div class="agenda-line"></div>
                                <div class="agenda-body">
                                    <div class="agenda-top">
                                        <div>
                                            <strong><%= titular != null ? (titular.getNombre() + " " + titular.getApellido()) : "Residente" %></strong>
                                            <div class="agenda-unidad">Torre <%= bloque != null ? bloque.getNombreBloque() : "-" %> - Apto <%= apto != null ? apto.getNumero() : "-" %></div>
                                        </div>
                                        <span class="badge-pill <%= c.isCancelada() ? "badge-cancelada" : "badge-propietario" %>">
                                            <%= c.isCancelada() ? "Cancelada" : "Confirmada" %>
                                        </span>
                                    </div>
                                    <div class="agenda-location">
                                        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                        Oficina de Administración
                                    </div>
                                    <div class="agenda-motivo"><strong>Motivo:</strong> <%= Controlador.Utilidades.esc(c.getObservaciones()) %></div>
                                    <% if (pqrsLigada != null) { %>
                                        <div class="pqrs-link">Vinculado a PQRS: "<%= Controlador.Utilidades.esc(pqrsLigada.getAsunto()) %>"</div>
                                    <% } %>
                                    <% if (c.isReprogramacionSolicitada()) { %>
                                        <div class="alert alert-danger" style="margin-bottom:10px;">
                                            <strong>El residente pidió reprogramar esta cita.</strong>
                                            <% if (c.getMensajeReprogramacion() != null) { %>
                                                <div style="margin-top:4px; font-style:italic;">"<%= Controlador.Utilidades.esc(c.getMensajeReprogramacion()) %>"</div>
                                            <% } %>
                                            <a href="<%= ctx %>/CitasServlet?accion=editar&id=<%= c.getIdCitas() %>" style="font-weight:700;">Reprogramar ahora &rarr;</a>
                                        </div>
                                    <% } %>

                                    <% if (!c.isCancelada()) { %>
                                        <% if (c.getAsistencia() == null) { %>
                                            <div class="agenda-actions">
                                                <form method="post" action="<%= ctx %>/CitasServlet" class="inline-cancel">
                                                    <input type="hidden" name="accion" value="asistencia">
                                                    <input type="hidden" name="idCitas" value="<%= c.getIdCitas() %>">
                                                    <input type="hidden" name="valor" value="Asistio">
                                                    <input type="hidden" name="tab" value="hoy">
                                                    <button type="submit" class="btn-confirm">✓ Confirmar Asistencia</button>
                                                </form>
                                                <form method="post" action="<%= ctx %>/CitasServlet" class="inline-cancel">
                                                    <input type="hidden" name="accion" value="asistencia">
                                                    <input type="hidden" name="idCitas" value="<%= c.getIdCitas() %>">
                                                    <input type="hidden" name="valor" value="Inasistencia">
                                                    <input type="hidden" name="tab" value="hoy">
                                                    <button type="submit" class="btn-outline">✕ Marcar Inasistencia</button>
                                                </form>
                                                <a href="<%= ctx %>/CitasServlet?accion=editar&id=<%= c.getIdCitas() %>" class="btn-outline">Editar</a>
                                            </div>
                                        <% } else { %>
                                            <span class="badge-pill <%= "Asistio".equals(c.getAsistencia()) ? "badge-propietario" : "badge-cancelada" %>">
                                                <%= "Asistio".equals(c.getAsistencia()) ? "Asistió" : "No asistió" %>
                                            </span>
                                        <% } %>
                                    <% } %>

                                    <% if (!historial.isEmpty()) { %>
                                        <details class="timeline-toggle">
                                            <summary>Ver seguimiento (<%= historial.size() %>)</summary>
                                            <div class="timeline">
                                                <% for (Seguimiento s : historial) { %>
                                                    <div class="timeline-node">
                                                        <div class="timeline-dot dot-cita">
                                                            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                                        </div>
                                                        <div class="timeline-node-meta"><%= s.getFechaRegistro() != null ? sdf.format(s.getFechaRegistro()) : "" %></div>
                                                        <div class="timeline-node-body"><%= Controlador.Utilidades.esc(s.getComentario()) %></div>
                                                    </div>
                                                <% } %>
                                            </div>
                                        </details>
                                    <% } %>
                                </div>
                            </div>
                            <% } %>
                        </div>
                    <% } %>
                </div>
            <% } else if ("proximas".equals(tab)) { %>
                <div class="calendar-card">
                    <h2 class="day-title">Próximas Citas</h2>
                    <% if (citasProximas == null || citasProximas.isEmpty()) { %>
                        <p class="empty-state">No hay citas próximas agendadas.</p>
                    <% } else { %>
                        <table class="usuarios-table">
                            <thead><tr><th>Fecha</th><th>Hora</th><th>Residente</th><th>Tipo</th><th>Motivo</th><th>Acciones</th></tr></thead>
                            <tbody>
                                <% for (Citas c : citasProximas) {
                                    Usuario titular = usuarioDAO.consultar(c.getIdUsuario());
                                    Tipocita tipo = tipoCitaDAO.consultar(c.getIdTipoCita());
                                %>
                                <tr <%= c.isReprogramacionSolicitada() ? "style=\"background:#fef2f2;\"" : "" %>>
                                    <td><%= c.getFecha() %></td>
                                    <td><%= c.getHora().toString().substring(0,5) %></td>
                                    <td class="cell-nombre">
                                        <%= titular != null ? (titular.getNombre() + " " + titular.getApellido()) : "-" %>
                                        <% if (c.isReprogramacionSolicitada()) { %>
                                            <span class="badge-pill badge-cancelada" title="<%= Controlador.Utilidades.esc(c.getMensajeReprogramacion()) %>">Pidió reprogramar</span>
                                        <% } %>
                                    </td>
                                    <td><%= tipo != null ? tipo.getNombre() : "-" %></td>
                                    <td class="cell-muted"><%= Controlador.Utilidades.esc(c.getObservaciones()) %></td>
                                    <td>
                                        <div class="row-actions">
                                            <a href="<%= ctx %>/CitasServlet?accion=editar&id=<%= c.getIdCitas() %>" title="Editar">
                                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"></path></svg>
                                            </a>
                                            <form method="post" action="<%= ctx %>/CitasServlet" class="inline-cancel" onsubmit="return confirm('¿Cancelar esta cita?');">
                                                <input type="hidden" name="accion" value="cancelar">
                                                <input type="hidden" name="idCitas" value="<%= c.getIdCitas() %>">
                                                <button type="submit" title="Cancelar" style="background:none;border:none;color:#b91c1c;cursor:pointer;">
                                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <% } %>
                            </tbody>
                        </table>
                    <% } %>
                </div>
            <% } else { %>
                <div class="calendar-card">
                    <h2 class="day-title">Horario Semanal</h2>
                    <p class="page-subtitle" style="margin-bottom:20px;">Disponibilidad actual configurada para agendar citas.</p>
                    <div class="horario-resumen">
                        <div class="horario-item"><span class="detail-label">Horario de atención</span><span class="detail-value"><%= configAgenda.getHoraInicio().toString().substring(0,5) %> - <%= configAgenda.getHoraFin().toString().substring(0,5) %></span></div>
                        <div class="horario-item"><span class="detail-label">Duración de cada cupo</span><span class="detail-value"><%= configAgenda.getDuracionSlotMinutos() %> minutos</span></div>
                        <div class="horario-item">
                            <span class="detail-label">Días laborales</span>
                            <span class="detail-value">
                                <%
                                    String[] nombresDias = {"", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"};
                                    StringBuilder diasTexto = new StringBuilder();
                                    for (int d = 1; d <= 7; d++) {
                                        if (configAgenda.esDiaLaboral(d)) {
                                            if (diasTexto.length() > 0) diasTexto.append(", ");
                                            diasTexto.append(nombresDias[d]);
                                        }
                                    }
                                %>
                                <%= diasTexto.toString() %>
                            </span>
                        </div>
                    </div>
                    <a class="btn-primary" style="margin-top:20px;" href="<%= ctx %>/CitasServlet?accion=disponibilidad">Configurar Disponibilidad</a>
                </div>
            <% } %>
        </main>
    </div>
    <%@ include file="_dropdownScript.jspf" %>
</body>
</html>
