<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.Bloque" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    Usuario usuarioActual = (Usuario) request.getAttribute("usuarioActual");
    if (usuarioActual == null) usuarioActual = usuario;
    String ctx = request.getContextPath();
    boolean esAdmin = usuarioActual.getIdRol() == 1;
    String volverA = esAdmin ? ctx + "/Vista/menuAdmin.jsp" : ctx + "/Vista/menuResidente.jsp";

    String ubicacion = null;
    if (!esAdmin && usuarioActual.getIdApartamento() > 0) {
        Apartamento apto = new Controlador.ApartamentoDAO().consultar(usuarioActual.getIdApartamento());
        if (apto != null) {
            Bloque bloque = new Controlador.BloqueDAO().consultar(apto.getIdBloque());
            ubicacion = "Torre " + (bloque != null ? bloque.getNombreBloque() : "-") + " - Apto " + apto.getNumero();
        }
    }
    String mensaje = (String) request.getAttribute("mensaje");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Perfil - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <a href="<%= volverA %>">&larr; Volver al panel</a>
        </div>

        <div class="card">
            <h1>Mi Perfil</h1>
            <p class="sub"><%= esAdmin ? "Administrador" : "Residente" %><% if (ubicacion != null) { %> · <%= ubicacion %><% } %></p>

            <% if (mensaje != null) { %><div class="alert alert-success"><%= mensaje %></div><% } %>
            <% if (error != null) { %><div class="alert alert-danger"><%= error %></div><% } %>

            <div class="detail-grid">
                <div><span class="detail-label">Nombre completo</span><span class="detail-value"><%= usuarioActual.getNombre() %> <%= usuarioActual.getApellido() %></span></div>
                <div><span class="detail-label">Documento</span><span class="detail-value"><%= usuarioActual.getDocumento() %></span></div>
                <div><span class="detail-label">Correo</span><span class="detail-value"><%= usuarioActual.getCorreo() %></span></div>
                <div><span class="detail-label">Rol</span><span class="detail-value"><%= esAdmin ? "Administrador" : "Residente" %></span></div>
            </div>
        </div>

        <div class="card">
            <h2 class="section-mini-title">Actualizar datos</h2>
            <form method="post" action="<%= ctx %>/PerfilServlet">
                <div class="form-group">
                    <label for="telefono">Teléfono</label>
                    <input type="text" id="telefono" name="telefono" value="<%= usuarioActual.getTelefono() %>">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="nuevaPassword">Nueva contraseña (opcional)</label>
                        <input type="password" id="nuevaPassword" name="nuevaPassword" placeholder="Déjalo en blanco para no cambiarla">
                    </div>
                    <div class="form-group">
                        <label for="confirmarPassword">Confirmar contraseña</label>
                        <input type="password" id="confirmarPassword" name="confirmarPassword">
                    </div>
                </div>
                <button type="submit" class="btn">Guardar cambios</button>
            </form>
        </div>
    </div>
</body>
</html>
