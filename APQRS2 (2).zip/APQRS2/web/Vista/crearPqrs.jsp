<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Controlador.TipoPqrsDAO" %>
<%@ page import="Modelo.TipoPqrs" %>
<%@ page import="java.util.List" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    Usuario usuarioActual = usuario;
    String rolLabel = "Residente";
    List<TipoPqrs> tipos = new TipoPqrsDAO().listarTodos();
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva PQRS - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/DashResidente.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/dropdowns.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/masterDetail.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/crearPqrs.css">
</head>
<body>
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<%= ctx %>/Vista/menuResidente.jsp">
                    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                    Inicio
                </a></li>
                <li class="active"><a href="<%= ctx %>/PqrsServlet">
                    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                    Mis PQRS
                </a></li>
                <li><a href="<%= ctx %>/CitasServlet">
                    <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                    Citas Presenciales
                </a></li>
            </ul>
        </div>
        <div class="sidebar-footer">Residente</div>
    </aside>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                <p>Residente</p>
            </div>
            <div class="header-actions">
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">
            <div class="page-title-row">
                <div>
                    <h1>Nueva PQRS</h1>
                    <p class="page-subtitle">Petición, Queja, Reclamo o Sugerencia</p>
                </div>
                <a class="btn-outline" href="<%= ctx %>/PqrsServlet">Ver mis PQRS</a>
            </div>

            <% if (request.getAttribute("error") != null) { %>
                <div class="alert alert-danger"><%= request.getAttribute("error") %></div>
            <% } %>

            <div class="form-card-wrap">
                <div class="form-card">
                    <form action="<%= ctx %>/PqrsServlet" method="POST">
                        <input type="hidden" name="accion" value="crear">

                        <div class="form-group">
                            <label>Tipo <span style="color:#dc2626">*</span></label>
                            <select name="tipoPqrs" required>
                                <option value="" disabled selected>Selecciona el tipo...</option>
                                <% for (TipoPqrs t : tipos) { %>
                                    <option value="<%= t.getIdTipoPqrs() %>"><%= t.getNombreTipoPqrs() %></option>
                                <% } %>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Asunto <span style="color:#dc2626">*</span></label>
                            <input type="text" name="asunto" placeholder="Ej. Ruido excesivo en el apartamento 302" required>
                        </div>

                        <div class="form-group">
                            <label>Descripción <span style="color:#dc2626">*</span></label>
                            <textarea name="descripcion" placeholder="Describe con el mayor detalle posible..." required></textarea>
                        </div>

                        <button type="submit" class="btn">Enviar PQRS</button>
                    </form>
                </div>
            </div>
        </main>
    </div>

    <%@ include file="_dropdownScript.jspf" %>
</body>
</html>
