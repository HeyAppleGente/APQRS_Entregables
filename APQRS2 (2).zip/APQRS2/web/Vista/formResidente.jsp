<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.Bloque" %>
<%@ page import="Modelo.TipoDocumento" %>
<%@ page import="java.util.List" %>
<%
    Usuario admin = (Usuario) session.getAttribute("usuario");
    if (admin == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    if (admin.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/menuResidente.jsp");
        return;
    }

    String modo = (String) request.getAttribute("modo"); // "crear" | "editar"
    Usuario residente = (Usuario) request.getAttribute("residente");
    List<TipoDocumento> tiposDocumento = (List<TipoDocumento>) request.getAttribute("tiposDocumento");
    String error = (String) request.getAttribute("error");
    boolean editar = "editar".equals(modo);
    String ctx = request.getContextPath();

    Bloque residenteBloque = null;
    Apartamento residenteApto = null;
    if (residente != null && residente.getIdApartamento() > 0) {
        residenteApto = new Controlador.ApartamentoDAO().consultar(residente.getIdApartamento());
        if (residenteApto != null) {
            residenteBloque = new Controlador.BloqueDAO().consultar(residenteApto.getIdBloque());
        }
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><%= editar ? "Editar Residente" : "Nuevo Residente" %> - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <a href="<%= ctx %>/UsuarioAdminServlet">&larr; Volver a Usuarios y Unidades</a>
        </div>

        <div class="card">
            <h1><%= editar ? "Editar Residente" : "Nuevo Residente" %></h1>
            <p class="sub"><%= editar ? "Actualiza los datos del residente." : "Registra un nuevo residente y asígnalo a una unidad." %></p>

            <% if (error != null) { %>
                <div class="alert alert-danger"><%= error %></div>
            <% } %>

            <form method="post" action="<%= ctx %>/UsuarioAdminServlet">
                <input type="hidden" name="accion" value="<%= editar ? "actualizar" : "crear" %>">
                <% if (editar) { %>
                    <input type="hidden" name="idUsuario" value="<%= residente.getIdUsuario() %>">
                <% } %>

                <div class="form-row">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input type="text" id="nombre" name="nombre" required
                               value="<%= (residente != null && residente.getNombre() != null) ? residente.getNombre() : "" %>">
                    </div>
                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input type="text" id="apellido" name="apellido" required
                               value="<%= (residente != null && residente.getApellido() != null) ? residente.getApellido() : "" %>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="tipoDocumento">Tipo de documento</label>
                        <select id="tipoDocumento" name="tipoDocumento" required>
                            <% for (TipoDocumento td : tiposDocumento) { %>
                                <option value="<%= td.getIdTipoDocumento() %>"
                                    <%= (residente != null && residente.getIdTipoDocumento() == td.getIdTipoDocumento()) ? "selected" : "" %>>
                                    <%= td.getNombreTipoDocumento() %>
                                </option>
                            <% } %>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="numeroDocumento">Número de documento</label>
                        <input type="text" id="numeroDocumento" name="numeroDocumento" required
                               value="<%= (residente != null && residente.getDocumento() != null) ? residente.getDocumento() : "" %>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input type="text" id="telefono" name="telefono" required
                               value="<%= (residente != null && residente.getTelefono() != null) ? residente.getTelefono() : "" %>">
                    </div>
                    <div class="form-group">
                        <label for="correo">Correo</label>
                        <input type="email" id="correo" name="correo" required
                               value="<%= (residente != null && residente.getCorreo() != null) ? residente.getCorreo() : "" %>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="torre">Torre / Bloque</label>
                        <input type="text" id="torre" name="torre" required placeholder="Ej: 4, B, Torre Norte..."
                               value="<%= residenteBloque != null ? residenteBloque.getNombreBloque() : "" %>">
                        <span class="field-hint">Si la torre no existe todavía, se crea automáticamente. Las torres 1, 10 y 32 solo tienen 2 apartamentos por piso.</span>
                    </div>
                    <div class="form-group">
                        <label for="numeroApartamento">Número de apartamento</label>
                        <input type="text" id="numeroApartamento" name="numeroApartamento" required placeholder="Ej: 501"
                               value="<%= residenteApto != null ? residenteApto.getNumero() : "" %>">
                    </div>
                </div>

                <div class="form-group">
                    <label for="tipoOcupante">Tipo de ocupante</label>
                    <select id="tipoOcupante" name="tipoOcupante" required>
                        <option value="Propietario" <%= (residente == null || "Propietario".equals(residente.getTipoOcupante())) ? "selected" : "" %>>Propietario</option>
                        <option value="Arrendatario" <%= (residente != null && "Arrendatario".equals(residente.getTipoOcupante())) ? "selected" : "" %>>Arrendatario</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="password"><%= editar ? "Nueva contraseña (opcional)" : "Contraseña" %></label>
                    <input type="password" id="password" name="password" <%= editar ? "" : "required" %>
                           placeholder="<%= editar ? "Déjalo en blanco para mantener la actual" : "" %>">
                </div>

                <button type="submit" class="btn"><%= editar ? "Guardar Cambios" : "Crear Residente" %></button>
            </form>
        </div>
    </div>
</body>
</html>
