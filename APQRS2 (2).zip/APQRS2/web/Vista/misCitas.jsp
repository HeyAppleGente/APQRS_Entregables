<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="Modelo.Seguimiento" %>
<%@ page import="Controlador.TipocitaDAO" %>
<%@ page import="Controlador.PqrsDAO" %>
<%@ page import="Controlador.SeguimientoDAO" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.util.List" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    Usuario usuarioActual = usuario;
    String rolLabel = "Residente";

    List<Citas> misCitas = (List<Citas>) request.getAttribute("misCitas");
    TipocitaDAO tipoCitaDAO = new TipocitaDAO();
    PqrsDAO pqrsDAO = new PqrsDAO();
    SeguimientoDAO seguimientoDAO = new SeguimientoDAO();
    SimpleDateFormat sdfLarga = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    LocalDate hoy = LocalDate.now();
    List<Tipocita> tiposCita = tipoCitaDAO.listarTodos();

    String mensaje = (String) request.getAttribute("mensaje");
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis citas - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/DashResidente.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/dropdowns.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/masterDetail.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/timeline.css">
</head>
<body>
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<%= ctx %>/Vista/menuResidente.jsp">
                    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                    Inicio
                </a></li>
                <li><a href="<%= ctx %>/PqrsServlet">
                    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                    Mis PQRS
                </a></li>
                <li class="active"><a href="<%= ctx %>/CitasServlet">
                    <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                    Citas Presenciales
                </a></li>
            </ul>
        </div>
        <div class="sidebar-footer">Residente</div>
    </aside>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                <p>Residente</p>
            </div>
            <div class="header-actions">
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">
            <div class="page-title-row">
                <div>
                    <h1>Mis Citas</h1>
                    <p class="page-subtitle">Estas son las citas que administración ha agendado para ti</p>
                </div>
            </div>

            <% if (mensaje != null) { %><div class="alert alert-success"><%= mensaje %></div><% } %>
            <% if (error != null) { %><div class="alert alert-danger"><%= error %></div><% } %>

            <% if (misCitas == null || misCitas.isEmpty()) { %>
                <div class="md-empty-list" style="background:#fff; border:1px solid #e2e8f0; border-radius:14px;">
                    Todavía no tienes ninguna cita agendada. Cuando administración agende una para atender tu PQRS, aparecerá aquí.
                </div>
            <% } else { %>

                <div class="md-toolbar">
                    <div class="md-search">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        <input type="text" id="buscador" placeholder="Buscar por fecha o motivo..." oninput="filtrarLista()">
                    </div>
                    <div class="md-filters">
                        <select id="filtroEstado" onchange="filtrarLista()">
                            <option value="">Todos los estados</option>
                            <option value="proxima">Próximas</option>
                            <option value="pasada">Pasadas</option>
                            <option value="cancelada">Canceladas</option>
                        </select>
                        <select id="filtroTipo" onchange="filtrarLista()">
                            <option value="">Todos los tipos</option>
                            <% for (Tipocita t : tiposCita) { %>
                                <option value="<%= t.getNombre() %>"><%= t.getNombre() %></option>
                            <% } %>
                        </select>
                        <span class="md-results-count" id="contadorResultados"></span>
                    </div>
                </div>

                <div class="md-layout">
                    <div class="md-list" id="listaCitas">
                        <% for (Citas c : misCitas) {
                            Tipocita tipo = tipoCitaDAO.consultar(c.getIdTipoCita());
                            boolean esFutura = c.getFecha() != null && !c.getFecha().toLocalDate().isBefore(hoy);
                            String estadoFiltro = c.isCancelada() ? "cancelada" : (esFutura ? "proxima" : "pasada");
                            String busqueda = (c.getFecha() + " " + c.getObservaciones() + " " + (tipo != null ? tipo.getNombre() : "")).toLowerCase();
                            boolean respondidaCita = c.getRespuesta() != null && !c.getRespuesta().trim().isEmpty();
                        %>
                        <button class="md-item" id="item-<%= c.getIdCitas() %>"
                                data-estado="<%= estadoFiltro %>"
                                data-tipo="<%= tipo != null ? tipo.getNombre() : "" %>"
                                data-search="<%= busqueda %>"
                                onclick="seleccionar('<%= c.getIdCitas() %>')">
                            <div class="md-item-top">
                                <span class="md-item-id"><%= c.getFecha() %></span>
                                <% if (c.isCancelada()) { %>
                                    <span class="badge-pill badge-arrendatario">Cancelada</span>
                                <% } else { %>
                                    <span class="badge-pill <%= respondidaCita ? "badge-propietario" : "badge-arrendatario" %>">
                                        <%= respondidaCita ? "Confirmada" : "Pendiente" %>
                                    </span>
                                <% } %>
                            </div>
                            <div class="md-item-date"><%= c.getHora().toString().substring(0,5) %> <% if (!c.isNotificadaResidente()) { %><span class="badge-nueva">Nueva</span><% } %></div>
                            <div class="md-item-title"><%= tipo != null ? tipo.getNombre() : "Cita" %></div>
                            <div class="md-item-meta"><%= Controlador.Utilidades.esc(c.getObservaciones()) %></div>
                        </button>
                        <% } %>
                    </div>

                    <div class="md-detail-panel">
                        <div class="md-placeholder" id="placeholder">
                            <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                            <p>Selecciona una cita para ver los detalles</p>
                        </div>

                        <% for (Citas c : misCitas) {
                            Tipocita tipo = tipoCitaDAO.consultar(c.getIdTipoCita());
                            Pqrs pqrsLigada = (c.getIdPqrs() != null) ? pqrsDAO.consultar(c.getIdPqrs()) : null;
                            List<Seguimiento> historialCita = seguimientoDAO.listarPorCitas(c.getIdCitas());
                            boolean respondidaCita = c.getRespuesta() != null && !c.getRespuesta().trim().isEmpty();
                            boolean citaEsFutura = c.getFecha() != null && !c.getFecha().toLocalDate().isBefore(hoy);
                        %>
                            <div class="md-detail" id="detail-<%= c.getIdCitas() %>">
                                <div class="md-detail-header">
                                    <h2><%= tipo != null ? tipo.getNombre() : "Cita" %></h2>
                                    <% if (c.isCancelada()) { %>
                                        <span class="badge-pill badge-arrendatario">Cancelada</span>
                                    <% } else { %>
                                        <span class="badge-pill <%= respondidaCita ? "badge-propietario" : "badge-arrendatario" %>">
                                            <%= respondidaCita ? "Confirmada" : "Pendiente de confirmación" %>
                                        </span>
                                    <% } %>
                                </div>
                                <div class="md-detail-meta">
                                    <%= c.getFecha() %> a las <%= c.getHora().toString().substring(0,5) %>
                                </div>

                                <div class="md-detail-section">
                                    <div class="md-detail-label">Motivo</div>
                                    <div class="md-detail-body"><%= Controlador.Utilidades.esc(c.getObservaciones()) %></div>
                                </div>

                                <% if (pqrsLigada != null) { %>
                                    <div class="related-card">
                                        <div class="related-icon">
                                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                                        </div>
                                        <div class="related-card-text">
                                            <strong>PQRS relacionada</strong>
                                            <span>"<%= Controlador.Utilidades.esc(pqrsLigada.getAsunto()) %>"</span>
                                        </div>
                                    </div>
                                <% } %>

                                <% if (respondidaCita && !c.isCancelada()) { %>
                                    <div class="md-detail-section">
                                        <div class="md-detail-label">Estado</div>
                                        <div class="respuesta"><%= Controlador.Utilidades.esc(c.getRespuesta()) %></div>
                                    </div>
                                <% } %>

                                <% if (c.getAsistencia() != null) { %>
                                    <div class="md-detail-section">
                                        <span class="badge-pill <%= "Asistio".equals(c.getAsistencia()) ? "badge-propietario" : "badge-arrendatario" %>">
                                            <%= "Asistio".equals(c.getAsistencia()) ? "Asististe a esta cita" : "No asististe a esta cita" %>
                                        </span>
                                    </div>
                                <% } %>

                                <% if (!c.isCancelada() && citaEsFutura) { %>
                                    <div class="md-detail-section">
                                        <% if (c.isReprogramacionSolicitada()) { %>
                                            <div class="alert alert-success" style="margin-bottom:0;">
                                                Ya enviaste una solicitud de reprogramación para esta cita. Administración la va a revisar.
                                                <% if (c.getMensajeReprogramacion() != null) { %>
                                                    <div style="margin-top:6px; font-style:italic;">"<%= Controlador.Utilidades.esc(c.getMensajeReprogramacion()) %>"</div>
                                                <% } %>
                                            </div>
                                        <% } else { %>
                                            <details class="timeline-toggle">
                                                <summary>¿No puedes asistir? Pedir reprogramación</summary>
                                                <form method="post" action="<%= ctx %>/CitasServlet" style="margin-top:12px;">
                                                    <input type="hidden" name="accion" value="solicitarReprogramacion">
                                                    <input type="hidden" name="idCitas" value="<%= c.getIdCitas() %>">
                                                    <textarea name="mensaje" placeholder="Cuéntale a administración por qué necesitas cambiar la fecha/hora..." required
                                                              style="width:100%; min-height:80px; padding:10px 12px; border:1px solid #cbd5e1; border-radius:10px; font-family:inherit; font-size:0.85rem; resize:vertical;"></textarea>
                                                    <button type="submit" class="btn-sm" style="margin-top:8px;">Enviar solicitud</button>
                                                </form>
                                            </details>
                                        <% } %>
                                    </div>
                                <% } %>

                                <% if (!historialCita.isEmpty()) { %>
                                    <details class="timeline-toggle">
                                        <summary>Ver seguimiento completo</summary>
                                        <div class="timeline">
                                            <div class="timeline-node">
                                                <div class="timeline-dot dot-inicio">
                                                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line></svg>
                                                </div>
                                                <div class="timeline-node-title">Cita agendada</div>
                                                <div class="timeline-node-meta"><%= c.getFechaCreacion() != null ? sdfLarga.format(c.getFechaCreacion()) : "" %></div>
                                            </div>
                                            <% for (Seguimiento s : historialCita) { %>
                                                <div class="timeline-node">
                                                    <div class="timeline-dot <%= c.isCancelada() ? "dot-cancelada" : "dot-cita" %>">
                                                        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                                    </div>
                                                    <div class="timeline-node-title">Actualización de administración</div>
                                                    <div class="timeline-node-meta"><%= s.getFechaRegistro() != null ? sdfLarga.format(s.getFechaRegistro()) : "" %></div>
                                                    <div class="timeline-node-body"><%= Controlador.Utilidades.esc(s.getComentario()) %></div>
                                                </div>
                                            <% } %>
                                        </div>
                                    </details>
                                <% } %>
                            </div>
                        <% } %>
                    </div>
                </div>
            <% } %>
        </main>
    </div>

    <%@ include file="_dropdownScript.jspf" %>
    <script>
        function seleccionar(id) {
            document.querySelectorAll('.md-item').forEach(function (el) { el.classList.remove('selected'); });
            document.querySelectorAll('.md-detail').forEach(function (el) { el.classList.remove('active'); });
            var item = document.getElementById('item-' + id);
            var detail = document.getElementById('detail-' + id);
            if (item) item.classList.add('selected');
            if (detail) detail.classList.add('active');
            var placeholder = document.getElementById('placeholder');
            if (placeholder) placeholder.style.display = 'none';
        }
        function filtrarLista() {
            var buscadorEl = document.getElementById('buscador');
            var texto = buscadorEl ? buscadorEl.value.toLowerCase() : '';
            var estado = document.getElementById('filtroEstado').value;
            var tipo = document.getElementById('filtroTipo').value;
            var visibles = 0;
            document.querySelectorAll('.md-item').forEach(function (item) {
                var coincideTexto = item.dataset.search.indexOf(texto) !== -1;
                var coincideEstado = !estado || item.dataset.estado === estado;
                var coincideTipo = !tipo || item.dataset.tipo === tipo;
                var visible = coincideTexto && coincideEstado && coincideTipo;
                item.style.display = visible ? 'block' : 'none';
                if (visible) visibles++;
            });
            document.getElementById('contadorResultados').textContent = visibles + ' de ' + document.querySelectorAll('.md-item').length + ' resultados';
        }
        if (document.getElementById('filtroEstado')) { filtrarLista(); }
    </script>
</body>
</html>
