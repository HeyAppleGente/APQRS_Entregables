<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="Controlador.UsuarioDAO" %>
<%@ page import="java.time.YearMonth" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.DayOfWeek" %>
<%@ page import="java.time.format.TextStyle" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="java.util.Locale" %>
<%
    Usuario admin = (Usuario) session.getAttribute("usuario");
    if (admin == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    if (admin.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/menuResidente.jsp");
        return;
    }

    String ctx = request.getContextPath();
    Locale es = new Locale("es", "ES");

    String fechaSeleccionada = (String) request.getAttribute("fechaSeleccionada");
    boolean vistaDia = fechaSeleccionada != null;

    String idPqrsParam = (String) request.getAttribute("idPqrs");
    if (idPqrsParam == null) idPqrsParam = request.getParameter("idPqrs");
    Pqrs pqrsAsociada = (Pqrs) request.getAttribute("pqrsAsociada");
    String qsPqrs = (idPqrsParam != null && !idPqrsParam.isEmpty()) ? "&idPqrs=" + idPqrsParam : "";

    UsuarioDAO usuarioDAO = new UsuarioDAO();
    String mensaje = "agendada".equals(request.getParameter("msg")) ? "¡Cita agendada con éxito!" : null;
    String error = (String) request.getAttribute("error");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control de Citas - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/DashAdmin.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/calendarioCitas.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/dropdowns.css">
</head>
<body>
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li><a href="<%= ctx %>/Vista/menuAdmin.jsp">
                    <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                    Panel General
                </a></li>
                <li><a href="<%= ctx %>/UsuarioAdminServlet">
                    <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                    Usuarios y Unidades
                </a></li>
                <li><a href="<%= ctx %>/PqrsServlet?vista=admin">
                    <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                    Gestión PQRS
                </a></li>
                <li class="active"><a href="<%= ctx %>/CitasServlet?accion=calendario">
                    <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                    Control de Citas
                </a></li>
            </ul>
        </div>
        <div class="sidebar-footer">Administrador</div>
    </aside>

    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= admin.getNombre() %> <%= admin.getApellido() != null ? admin.getApellido() : "" %></h2>
                <p>Administrador</p>
            </div>
            <div class="header-actions">
                <%
                    Usuario usuarioActual = admin;
                    String rolLabel = "Administrador";
                    Controlador.NotificacionesDAO notificacionesDAO = new Controlador.NotificacionesDAO();
                    java.util.List<Modelo.Notificaciones> notificacionesAdmin = notificacionesDAO.listarParaAdmin(10);
                    int noLeidasAdmin = notificacionesDAO.contarNoLeidasParaAdmin();
                %>
                <%@ include file="_notifBell.jspf" %>
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">
            <div class="page-title-row">
                <div>
                    <h1>Control de Citas</h1>
                    <p class="page-subtitle">Agenda citas con los residentes y revisa tu disponibilidad</p>
                </div>
                <a class="btn-outline" href="<%= ctx %>/CitasServlet?vista=admin">Ver lista de citas</a>
            </div>

            <% if (mensaje != null) { %><div class="alert alert-success"><%= mensaje %></div><% } %>
            <% if (error != null) { %><div class="alert alert-danger"><%= error %></div><% } %>

            <% if (pqrsAsociada != null) {
                Usuario autorPqrs = usuarioDAO.consultar(pqrsAsociada.getIdUsuario());
            %>
                <div class="pqrs-context-banner">
                    <div>
                        <strong>Agendando cita para responder una PQRS</strong>
                        <p>"<%= Controlador.Utilidades.esc(pqrsAsociada.getAsunto()) %>" — <%= autorPqrs != null ? (autorPqrs.getNombre() + " " + autorPqrs.getApellido()) : "Residente" %></p>
                    </div>
                    <a href="<%= ctx %>/PqrsServlet?vista=admin">Cancelar</a>
                </div>
            <% } %>

            <% if (!vistaDia) {
                YearMonth mes = (YearMonth) request.getAttribute("mesActual");
                if (mes == null) mes = YearMonth.now();
                Map<Integer, Integer> citasPorDia = (Map<Integer, Integer>) request.getAttribute("citasPorDia");
                YearMonth mesAnterior = mes.minusMonths(1);
                YearMonth mesSiguiente = mes.plusMonths(1);
                LocalDate primerDia = mes.atDay(1);
                int diasEnMes = mes.lengthOfMonth();
                int offsetInicial = primerDia.getDayOfWeek().getValue() % 7; // 0 = domingo
                LocalDate hoy = LocalDate.now();
                String nombreMes = mes.getMonth().getDisplayName(TextStyle.FULL, es);
            %>
            <div class="calendar-card">
                <div class="calendar-nav">
                    <a class="btn-outline" href="<%= ctx %>/CitasServlet?accion=calendario&mes=<%= mesAnterior %><%= qsPqrs %>">&larr;</a>
                    <h2><%= nombreMes.substring(0,1).toUpperCase() + nombreMes.substring(1) %> <%= mes.getYear() %></h2>
                    <a class="btn-outline" href="<%= ctx %>/CitasServlet?accion=calendario&mes=<%= mesSiguiente %><%= qsPqrs %>">&rarr;</a>
                </div>

                <div class="calendar-grid calendar-weekdays">
                    <div>Dom</div><div>Lun</div><div>Mar</div><div>Mié</div><div>Jue</div><div>Vie</div><div>Sáb</div>
                </div>

                <div class="calendar-grid">
                    <% for (int i = 0; i < offsetInicial; i++) { %>
                        <div class="calendar-cell empty"></div>
                    <% }
                    for (int dia = 1; dia <= diasEnMes; dia++) {
                        LocalDate fechaCelda = mes.atDay(dia);
                        Integer cantidad = citasPorDia != null ? citasPorDia.get(dia) : null;
                        boolean esPasado = fechaCelda.isBefore(hoy);
                        boolean esHoy = fechaCelda.isEqual(hoy);
                    %>
                        <% if (esPasado) { %>
                            <div class="calendar-cell past">
                                <span class="day-number"><%= dia %></span>
                                <% if (cantidad != null) { %><span class="day-badge">(<%= cantidad %>)</span><% } %>
                            </div>
                        <% } else { %>
                            <a class="calendar-cell <%= esHoy ? "today" : "" %>"
                               href="<%= ctx %>/CitasServlet?accion=dia&fecha=<%= fechaCelda %><%= qsPqrs %>">
                                <span class="day-number"><%= dia %></span>
                                <% if (cantidad != null) { %><span class="day-badge"><%= cantidad %> cita<%= cantidad == 1 ? "" : "s" %></span><% } %>
                            </a>
                        <% }
                    } %>
                </div>
            </div>

            <% } else {
                LocalDate fecha = LocalDate.parse(fechaSeleccionada);
                String nombreDia = fecha.getDayOfWeek().getDisplayName(TextStyle.FULL, es);
                String nombreMesDia = fecha.getMonth().getDisplayName(TextStyle.FULL, es);
                List<Citas> citasDelDia = (List<Citas>) request.getAttribute("citasDelDia");
                List<Usuario> residentes = (List<Usuario>) request.getAttribute("residentes");
                List<Tipocita> tiposCita = (List<Tipocita>) request.getAttribute("tiposCita");
                YearMonth mesDeVuelta = YearMonth.from(fecha);
            %>
            <a class="link-volver" href="<%= ctx %>/CitasServlet?accion=calendario&mes=<%= mesDeVuelta %><%= qsPqrs %>">&larr; Volver al calendario</a>

            <div class="day-grid">
                <div class="calendar-card">
                    <h2 class="day-title"><%= nombreDia.substring(0,1).toUpperCase() + nombreDia.substring(1) %>, <%= fecha.getDayOfMonth() %> de <%= nombreMesDia %></h2>

                    <% if (citasDelDia == null || citasDelDia.isEmpty()) { %>
                        <p class="empty-state">No hay citas agendadas este día.</p>
                    <% } else { %>
                        <div class="day-timeline">
                            <% for (Citas c : citasDelDia) {
                                Usuario titularFila = usuarioDAO.consultar(c.getIdUsuario());
                            %>
                            <div class="timeline-item <%= c.isCancelada() ? "cancelada" : "" %>">
                                <div class="timeline-hora"><%= c.getHora().toString().substring(0,5) %></div>
                                <div class="timeline-info">
                                    <strong><%= titularFila != null ? (titularFila.getNombre() + " " + titularFila.getApellido()) : "Residente" %></strong>
                                    <p><%= Controlador.Utilidades.esc(c.getObservaciones()) %></p>
                                    <% if (c.isCancelada()) { %>
                                        <span class="badge-pill badge-cancelada">Cancelada</span>
                                    <% } else { %>
                                        <div class="timeline-actions">
                                            <a href="<%= ctx %>/CitasServlet?accion=editar&id=<%= c.getIdCitas() %>">Editar</a>
                                            <form class="timeline-inline-form" method="post" action="<%= ctx %>/CitasServlet"
                                                  onsubmit="return confirm('¿Cancelar esta cita?');">
                                                <input type="hidden" name="accion" value="cancelar">
                                                <input type="hidden" name="idCitas" value="<%= c.getIdCitas() %>">
                                                <button type="submit" class="link-danger">Cancelar</button>
                                            </form>
                                        </div>
                                    <% } %>
                                </div>
                            </div>
                            <% } %>
                        </div>
                    <% } %>
                </div>

                <div class="calendar-card">
                    <h2 class="day-title">Agendar nueva cita</h2>

                    <% List<java.sql.Time> todosSlots = (List<java.sql.Time>) request.getAttribute("todosSlots");
                       List<java.sql.Time> horasOcupadas = (List<java.sql.Time>) request.getAttribute("horasOcupadas");
                       boolean hayAlgunaLibre = todosSlots != null && horasOcupadas != null && todosSlots.size() > horasOcupadas.size();
                    %>

                    <% if (!hayAlgunaLibre) { %>
                        <p class="empty-state">No quedan horarios disponibles este día.</p>
                    <% } else { %>
                        <form method="post" action="<%= ctx %>/CitasServlet" class="form-cita">
                            <input type="hidden" name="accion" value="crearAdmin">
                            <input type="hidden" name="fecha" value="<%= fechaSeleccionada %>">
                            <% if (pqrsAsociada != null) { %>
                                <input type="hidden" name="idPqrs" value="<%= pqrsAsociada.getIdPqrs() %>">
                                <div class="form-group">
                                    <label>Residente</label>
                                    <div class="static-value">
                                        <% Usuario autor = usuarioDAO.consultar(pqrsAsociada.getIdUsuario()); %>
                                        <%= autor != null ? (autor.getNombre() + " " + autor.getApellido()) : "-" %> (por PQRS)
                                    </div>
                                </div>
                            <% } else { %>
                                <div class="form-group">
                                    <label for="idUsuarioResidente">Residente</label>
                                    <select id="idUsuarioResidente" name="idUsuarioResidente" required>
                                        <option value="">Selecciona un residente</option>
                                        <% for (Usuario r : residentes) { %>
                                            <option value="<%= r.getIdUsuario() %>"><%= r.getNombre() %> <%= r.getApellido() %></option>
                                        <% } %>
                                    </select>
                                </div>
                            <% } %>

                            <div class="form-group">
                                <label>Hora disponible</label>
                                <div class="seat-legend">
                                    <span><i class="dot dot-libre"></i> Libre</span>
                                    <span><i class="dot dot-elegida"></i> Elegida</span>
                                    <span><i class="dot dot-ocupada"></i> Ocupada</span>
                                </div>
                                <div class="seat-grid">
                                    <% boolean marcada = false;
                                       int contador = 0;
                                       for (java.sql.Time slot : todosSlots) {
                                           boolean ocupado = horasOcupadas.contains(slot);
                                           contador++;
                                    %>
                                        <% if (ocupado) { %>
                                            <div class="seat seat-ocupada">
                                                <label><%= slot.toString().substring(0,5) %></label>
                                            </div>
                                        <% } else { %>
                                            <div class="seat">
                                                <input type="radio" id="hora<%= contador %>" name="hora" value="<%= slot %>"
                                                       <%= !marcada ? "checked" : "" %> required>
                                                <label for="hora<%= contador %>"><%= slot.toString().substring(0,5) %></label>
                                            </div>
                                            <% marcada = true; %>
                                        <% } %>
                                    <% } %>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="tipoCita">Tipo de cita</label>
                                <select id="tipoCita" name="tipoCita" required>
                                    <% for (Tipocita t : tiposCita) { %>
                                        <option value="<%= t.getIdTipoCita() %>"><%= t.getNombre() %></option>
                                    <% } %>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="observaciones">Motivo / observaciones</label>
                                <textarea id="observaciones" name="observaciones" required><%= pqrsAsociada != null ? ("Cita para atender la PQRS: " + Controlador.Utilidades.esc(pqrsAsociada.getAsunto())) : "" %></textarea>
                            </div>

                            <button type="submit" class="btn-primary btn-block">Agendar cita</button>
                        </form>
                    <% } %>
                </div>
            </div>
            <% } %>
        </main>
    </div>
    <%@ include file="_dropdownScript.jspf" %>
</body>
</html>
