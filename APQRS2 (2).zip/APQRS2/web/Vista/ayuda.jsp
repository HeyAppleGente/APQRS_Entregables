<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    boolean esAdmin = usuario.getIdRol() == 1;
    String volverA = esAdmin ? ctx + "/Vista/menuAdmin.jsp" : ctx + "/Vista/menuResidente.jsp";
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ayuda - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <a href="<%= volverA %>">&larr; Volver al panel</a>
        </div>
        <div class="card">
            <h1>Ayuda</h1>
            <p class="sub">Preguntas frecuentes</p>

            <% if (esAdmin) { %>
                <div class="detail-grid" style="grid-template-columns: 1fr; gap: 16px;">
                    <div><span class="detail-label">¿Cómo agendo una cita?</span><span class="detail-value">Desde "Control de Citas" → botón "Agendar", o desde una PQRS pendiente con el botón "Agendar cita para responder".</span></div>
                    <div><span class="detail-label">¿Cómo cambio el horario de atención?</span><span class="detail-value">En "Configurar Disponibilidad", dentro de Control de Citas.</span></div>
                    <div><span class="detail-label">¿Cómo doy de alta un residente?</span><span class="detail-value">En "Usuarios y Unidades" → botón "Nuevo Residente".</span></div>
                </div>
            <% } else { %>
                <div class="detail-grid" style="grid-template-columns: 1fr; gap: 16px;">
                    <div><span class="detail-label">¿Cómo radico una PQRS?</span><span class="detail-value">Desde tu panel, botón "Nueva PQRS".</span></div>
                    <div><span class="detail-label">¿Puedo agendar mi propia cita?</span><span class="detail-value">No. Administración agenda las citas para atender tus solicitudes y te avisa desde "Mis citas".</span></div>
                    <div><span class="detail-label">¿Olvidaste tu contraseña?</span><span class="detail-value">Usa "¿Olvidaste tu contraseña?" en la pantalla de inicio de sesión.</span></div>
                </div>
            <% } %>

            <p class="hint" style="margin-top:24px;">¿Necesitas algo más? Escríbele directamente a administración desde una nueva PQRS de tipo "Petición".</p>
        </div>
    </div>
</body>
</html>
