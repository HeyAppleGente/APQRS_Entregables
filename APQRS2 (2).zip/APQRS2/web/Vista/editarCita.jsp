<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="Controlador.PqrsDAO" %>
<%@ page import="java.util.List" %>
<%
    Usuario admin = (Usuario) session.getAttribute("usuario");
    if (admin == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    if (admin.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/menuResidente.jsp");
        return;
    }

    String ctx = request.getContextPath();
    Citas cita = (Citas) request.getAttribute("citaEditar");
    if (cita == null) {
        response.sendRedirect(ctx + "/CitasServlet?vista=admin");
        return;
    }
    Usuario titular = (Usuario) request.getAttribute("titular");
    String fechaConsulta = (String) request.getAttribute("fechaConsulta");
    List<java.sql.Time> todosSlots = (List<java.sql.Time>) request.getAttribute("todosSlots");
    List<java.sql.Time> horasOcupadas = (List<java.sql.Time>) request.getAttribute("horasOcupadas");
    List<Tipocita> tiposCita = (List<Tipocita>) request.getAttribute("tiposCita");
    String error = (String) request.getAttribute("error");
    Pqrs pqrsLigada = (cita.getIdPqrs() != null) ? new PqrsDAO().consultar(cita.getIdPqrs()) : null;
    boolean hayAlgunaLibre = todosSlots != null && horasOcupadas != null && todosSlots.size() > horasOcupadas.size();
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Cita - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/calendarioCitas.css">
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body style="background: linear-gradient(180deg, #f8fafc 0%, #eef1f6 100%); padding: 32px;">
    <div class="wrap">
        <div class="topbar">
            <a href="<%= ctx %>/CitasServlet?vista=admin">&larr; Volver a Gestión de Citas</a>
        </div>

        <div class="card">
            <h1>Editar / reprogramar cita</h1>
            <p class="sub">
                Residente: <strong><%= titular != null ? (titular.getNombre() + " " + titular.getApellido()) : "-" %></strong>
                <% if (pqrsLigada != null) { %>
                    &nbsp;·&nbsp; <span class="pqrs-tag">PQRS: "<%= Controlador.Utilidades.esc(pqrsLigada.getAsunto()) %>"</span>
                <% } %>
            </p>

            <% if (error != null) { %><div class="alert alert-danger"><%= error %></div><% } %>

            <form method="get" action="<%= ctx %>/CitasServlet" style="margin-bottom: 22px;">
                <input type="hidden" name="accion" value="editar">
                <input type="hidden" name="id" value="<%= cita.getIdCitas() %>">
                <div class="form-group">
                    <label for="fecha">Fecha</label>
                    <input type="date" id="fecha" name="fecha" value="<%= fechaConsulta %>">
                </div>
                <button type="submit" class="btn" style="background:#eff6ff; color:#1e3a8a; border:1px solid #bfdbfe;">Ver disponibilidad para esta fecha</button>
            </form>

            <% if (!hayAlgunaLibre) { %>
                <p class="empty-state">No quedan horarios disponibles ese día. Elige otra fecha.</p>
            <% } else { %>
                <form method="post" action="<%= ctx %>/CitasServlet">
                    <input type="hidden" name="accion" value="actualizarAdmin">
                    <input type="hidden" name="idCitas" value="<%= cita.getIdCitas() %>">
                    <input type="hidden" name="fecha" value="<%= fechaConsulta %>">

                    <div class="form-group">
                        <label>Hora</label>
                        <div class="seat-legend">
                            <span><i class="dot dot-libre"></i> Libre</span>
                            <span><i class="dot dot-elegida"></i> Elegida</span>
                            <span><i class="dot dot-ocupada"></i> Ocupada</span>
                        </div>
                        <div class="seat-grid">
                            <% int contador = 0;
                               for (java.sql.Time slot : todosSlots) {
                                   boolean ocupado = horasOcupadas.contains(slot);
                                   boolean esActual = slot.equals(cita.getHora());
                                   contador++;
                            %>
                                <% if (ocupado) { %>
                                    <div class="seat seat-ocupada">
                                        <label><%= slot.toString().substring(0,5) %></label>
                                    </div>
                                <% } else { %>
                                    <div class="seat">
                                        <input type="radio" id="hora<%= contador %>" name="hora" value="<%= slot %>"
                                               <%= esActual ? "checked" : "" %> required>
                                        <label for="hora<%= contador %>"><%= slot.toString().substring(0,5) %></label>
                                    </div>
                                <% } %>
                            <% } %>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="tipoCita">Tipo de cita</label>
                        <select id="tipoCita" name="tipoCita" required>
                            <% for (Tipocita t : tiposCita) { %>
                                <option value="<%= t.getIdTipoCita() %>" <%= t.getIdTipoCita() == cita.getIdTipoCita() ? "selected" : "" %>>
                                    <%= t.getNombre() %>
                                </option>
                            <% } %>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="observaciones">Motivo / observaciones</label>
                        <textarea id="observaciones" name="observaciones" required><%= Controlador.Utilidades.esc(cita.getObservaciones()) %></textarea>
                    </div>

                    <button type="submit" class="btn">Guardar cambios</button>
                </form>
            <% } %>
        </div>
    </div>
</body>
</html>
