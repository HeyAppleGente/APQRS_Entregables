<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.TipoPqrs" %>
<%@ page import="java.util.List" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null || usuario.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    String ctx = request.getContextPath();
    List<TipoPqrs> tiposPqrs = (List<TipoPqrs>) request.getAttribute("tiposPqrs");
    String mensaje = (String) request.getAttribute("mensaje");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Plazos - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <a href="<%= ctx %>/PqrsServlet?vista=admin">&larr; Volver a Gestión de PQRS</a>
        </div>

        <div class="card">
            <h1>Configurar Plazos de Atención</h1>
            <p class="sub">Días hábiles que tiene administración para responder cada tipo de PQRS antes de que se marque como vencida. Por defecto, 15 días hábiles (el estándar más usado en Colombia para peticiones, quejas y reclamos).</p>

            <% if (mensaje != null) { %><div class="alert alert-success"><%= mensaje %></div><% } %>

            <form method="post" action="<%= ctx %>/PqrsServlet">
                <input type="hidden" name="accion" value="guardarPlazos">

                <% if (tiposPqrs != null) {
                    for (TipoPqrs t : tiposPqrs) {
                %>
                    <div class="form-group">
                        <label for="dias_<%= t.getIdTipoPqrs() %>"><%= t.getNombreTipoPqrs() %></label>
                        <input type="number" min="1" max="90" id="dias_<%= t.getIdTipoPqrs() %>"
                               name="dias_<%= t.getIdTipoPqrs() %>" value="<%= t.getDiasPlazo() %>" required>
                        <span class="field-hint">días hábiles (lunes a viernes)</span>
                    </div>
                <%  }
                } %>

                <button type="submit" class="btn">Guardar plazos</button>
            </form>
        </div>
    </div>
</body>
</html>
