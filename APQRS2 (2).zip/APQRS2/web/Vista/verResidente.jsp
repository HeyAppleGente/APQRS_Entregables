<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.Bloque" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.List" %>
<%
    Usuario admin = (Usuario) session.getAttribute("usuario");
    if (admin == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }
    if (admin.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/menuResidente.jsp");
        return;
    }

    Usuario residente = (Usuario) request.getAttribute("residente");
    Apartamento apto = (Apartamento) request.getAttribute("apto");
    Bloque bloque = (Bloque) request.getAttribute("bloque");
    List<Pqrs> misPqrs = (List<Pqrs>) request.getAttribute("misPqrs");
    List<Citas> misCitas = (List<Citas>) request.getAttribute("misCitas");
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String ctx = request.getContextPath();

    int pqrsResueltas = 0;
    for (Pqrs p : misPqrs) {
        if (p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty()) pqrsResueltas++;
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Residente - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= ctx %>/Vista/Css/formResidente.css">
</head>
<body>
    <div class="wrap">
        <div class="topbar">
            <a href="<%= ctx %>/UsuarioAdminServlet">&larr; Volver a Usuarios y Unidades</a>
            <a href="<%= ctx %>/UsuarioAdminServlet?accion=editar&id=<%= residente.getIdUsuario() %>">Editar</a>
        </div>

        <div class="card">
            <h1><%= Controlador.Utilidades.esc(residente.getNombre()) %> <%= Controlador.Utilidades.esc(residente.getApellido()) %></h1>
            <p class="sub">
                <span class="badge-pill <%= "Arrendatario".equalsIgnoreCase(residente.getTipoOcupante()) ? "badge-arrendatario" : "badge-propietario" %>">
                    <%= residente.getTipoOcupante() %>
                </span>
                &nbsp;·&nbsp; Torre <%= bloque != null ? bloque.getNombreBloque() : "-" %> - Apto <%= apto != null ? apto.getNumero() : "-" %>
            </p>

            <div class="detail-grid">
                <div><span class="detail-label">Documento</span><span class="detail-value"><%= residente.getDocumento() %></span></div>
                <div><span class="detail-label">Teléfono</span><span class="detail-value"><%= residente.getTelefono() %></span></div>
                <div><span class="detail-label">Correo</span><span class="detail-value"><%= Controlador.Utilidades.esc(residente.getCorreo()) %></span></div>
                <div><span class="detail-label">Fecha de registro</span><span class="detail-value"><%= residente.getFechaRegistro() != null ? sdf.format(residente.getFechaRegistro()) : "-" %></span></div>
            </div>
        </div>

        <div class="card">
            <h2 class="section-mini-title">Actividad en el sistema</h2>
            <div class="mini-stats">
                <div class="mini-stat"><span class="mini-value"><%= misPqrs.size() %></span><span class="mini-label">PQRS radicadas</span></div>
                <div class="mini-stat"><span class="mini-value"><%= pqrsResueltas %></span><span class="mini-label">PQRS resueltas</span></div>
                <div class="mini-stat"><span class="mini-value"><%= misCitas.size() %></span><span class="mini-label">Citas agendadas</span></div>
            </div>
        </div>
    </div>
</body>
</html>
