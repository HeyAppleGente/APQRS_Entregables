<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.Bloque" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.TipoPqrs" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="Controlador.ApartamentoDAO" %>
<%@ page import="Controlador.BloqueDAO" %>
<%@ page import="Controlador.PqrsDAO" %>
<%@ page import="Controlador.TipoPqrsDAO" %>
<%@ page import="Controlador.CitasDAO" %>
<%@ page import="Controlador.TipocitaDAO" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.time.LocalDateTime" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.Calendar" %>
<%@ page import="java.util.Collections" %>
<%@ page import="java.util.Comparator" %>
<%@ page import="java.util.List" %>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }

    // ---------- Saludo según la hora del día ----------
    int horaDia = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    String saludo = horaDia < 12 ? "Buenos días" : (horaDia < 19 ? "Buenas tardes" : "Buenas noches");

    // ---------- Ubicación real del residente (Bloque / Apartamento) ----------
    String ubicacion = null;
    Apartamento apto = new ApartamentoDAO().consultar(usuario.getIdApartamento());
    if (apto != null) {
        Bloque bloque = new BloqueDAO().consultar(apto.getIdBloque());
        ubicacion = (bloque != null ? bloque.getNombreBloque() : "Bloque") + " · Apto " + apto.getNumero();
    }

    // ---------- PQRS del residente ----------
    PqrsDAO pqrsDAO = new PqrsDAO();
    TipoPqrsDAO tipoPqrsDAO = new TipoPqrsDAO();
    List<Pqrs> misPqrs = pqrsDAO.listarPorUsuario(usuario.getIdUsuario());

    int totalPqrs = misPqrs.size();
    int pqrsEnProceso = 0;
    int pqrsResueltas = 0;
    for (Pqrs p : misPqrs) {
        if (p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty()) {
            pqrsResueltas++;
        } else {
            pqrsEnProceso++;
        }
    }

    List<Pqrs> pqrsRecientes = new ArrayList<Pqrs>(misPqrs);
    Collections.sort(pqrsRecientes, new Comparator<Pqrs>() {
        public int compare(Pqrs a, Pqrs b) {
            if (a.getFechaRegistro() == null || b.getFechaRegistro() == null) return 0;
            return b.getFechaRegistro().compareTo(a.getFechaRegistro());
        }
    });
    if (pqrsRecientes.size() > 4) {
        pqrsRecientes = pqrsRecientes.subList(0, 4);
    }
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    // ---------- Citas del residente ----------
    CitasDAO citasDAO = new CitasDAO();
    TipocitaDAO tipoCitaDAO = new TipocitaDAO();
    List<Citas> misCitas = citasDAO.listarPorUsuario(usuario.getIdUsuario());

    Citas proximaCita = null;
    LocalDateTime ahora = LocalDateTime.now();
    LocalDateTime mejorMomento = null;
    int citasPendientes = 0;
    for (Citas c : misCitas) {
        if (c.getRespuesta() == null || c.getRespuesta().trim().isEmpty()) {
            citasPendientes++;
        }
        if (c.getFecha() == null || c.getHora() == null) continue;
        LocalDateTime dt = LocalDateTime.of(c.getFecha().toLocalDate(), c.getHora().toLocalTime());
        if (!dt.isBefore(ahora) && (mejorMomento == null || dt.isBefore(mejorMomento))) {
            mejorMomento = dt;
            proximaCita = c;
        }
    }
    Tipocita tipoProxima = (proximaCita != null) ? tipoCitaDAO.consultar(proximaCita.getIdTipoCita()) : null;

    int citasNuevas = 0;
    for (Citas c : misCitas) {
        if (!c.isNotificadaResidente()) citasNuevas++;
    }

    int notificaciones = pqrsEnProceso + citasNuevas;

    // Se marcan como vistas DESPUÉS de calcular citasNuevas, para que esta
    // carga del panel sí alcance a mostrar la alerta; la próxima ya no.
    citasDAO.marcarNotificadas(usuario.getIdUsuario());
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Residente - Sistema APQRS</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/Vista/Css/DashResidente.css">
    <link rel="stylesheet" href="<%= request.getContextPath() %>/Vista/Css/dropdowns.css">
</head>
<body>

    <!-- Barra Lateral -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li class="active">
                    <a href="<%= request.getContextPath() %>/Vista/menuResidente.jsp">
                        <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                        Inicio
                    </a>
                </li>
                <li>
                    <a href="<%= request.getContextPath() %>/PqrsServlet">
                        <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                        Mis PQRS
                    </a>
                </li>
                <li>
                    <a href="<%= request.getContextPath() %>/CitasServlet">
                        <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                        Citas Presenciales
                    </a>
                </li>
            </ul>
        </div>
        <div class="sidebar-footer">
            Residente
        </div>
    </aside>

    <!-- Sección Principal -->
    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                <p>Residente</p>
            </div>
            <div class="header-actions">
                <button class="icon-button">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                    <% if (notificaciones > 0) { %>
                        <span class="badge"><%= notificaciones %></span>
                    <% } %>
                </button>
                <% String ctx = request.getContextPath();
                   Usuario usuarioActual = usuario;
                   String rolLabel = "Residente";
                %>
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">

            <% if (citasNuevas > 0) { %>
                <div class="notif-banner">
                    <div class="notif-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                    </div>
                    <div class="notif-text">
                        <strong><%= citasNuevas %> cita<%= citasNuevas == 1 ? "" : "s" %> nueva<%= citasNuevas == 1 ? "" : "s" %> agendada<%= citasNuevas == 1 ? "" : "s" %> por administración</strong>
                        <p>Revisa la fecha y hora en "Mis citas".</p>
                    </div>
                    <a href="<%= request.getContextPath() %>/CitasServlet" class="notif-link">Ver &rarr;</a>
                </div>
            <% } %>

            <!-- Banner de bienvenida -->
            <div class="welcome-banner">
                <div class="banner-text">
                    <p class="banner-greeting"><%= saludo %></p>
                    <h2 class="banner-name"><%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                    <% if (ubicacion != null) { %>
                        <p class="banner-meta"><%= ubicacion %></p>
                    <% } %>
                    <div class="banner-actions">
                        <a href="<%= request.getContextPath() %>/Vista/crearPqrs.jsp" class="btn-banner btn-banner-primary">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                            Nueva PQRS
                        </a>
                        <a href="<%= request.getContextPath() %>/CitasServlet" class="btn-banner btn-banner-secondary">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                            Ver mis citas
                        </a>
                    </div>
                </div>
                <div class="banner-blob"></div>
            </div>

            <!-- Métricas -->
            <div class="metrics-resident">
                <div class="card">
                    <div class="card-stat">
                        <div class="stat-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                        </div>
                        <div class="stat-value"><%= totalPqrs %></div>
                    </div>
                    <div class="stat-label">Total Enviadas</div>
                </div>

                <div class="card">
                    <div class="card-stat">
                        <div class="stat-icon stat-icon-warning">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                        </div>
                        <div class="stat-value"><%= pqrsEnProceso %></div>
                    </div>
                    <div class="stat-label">En Proceso</div>
                </div>

                <div class="card">
                    <div class="card-stat">
                        <div class="stat-icon stat-icon-success">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                        </div>
                        <div class="stat-value"><%= pqrsResueltas %></div>
                    </div>
                    <div class="stat-label">Resueltas</div>
                </div>
            </div>

            <!-- Grid principal -->
            <div class="dashboard-grid">
                <!-- Mis PQRS recientes -->
                <div>
                    <div class="section-header">
                        <h3 class="section-title">Mis PQRS Recientes</h3>
                        <a href="<%= request.getContextPath() %>/PqrsServlet" class="link-ver-todas">Ver todas &rarr;</a>
                    </div>

                    <% if (pqrsRecientes.isEmpty()) { %>
                        <div class="empty-card">Aún no has radicado ninguna PQRS.</div>
                    <% } else { %>
                        <div class="table-card">
                            <table class="pqrs-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tipo</th>
                                        <th>Asunto</th>
                                        <th>Fecha</th>
                                        <th>Estado</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <% for (Pqrs p : pqrsRecientes) {
                                        boolean resuelta = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
                                        TipoPqrs tp = tipoPqrsDAO.consultar(p.getIdTipoPqrs());
                                    %>
                                    <tr>
                                        <td class="cell-id">PQRS-<%= String.format("%03d", p.getIdPqrs()) %></td>
                                        <td><%= tp != null ? tp.getNombreTipoPqrs() : "-" %></td>
                                        <td class="cell-asunto"><%= Controlador.Utilidades.esc(p.getAsunto()) %></td>
                                        <td><%= p.getFechaRegistro() != null ? sdf.format(p.getFechaRegistro()) : "-" %></td>
                                        <td>
                                            <span class="badge-pill <%= resuelta ? "badge-resuelto" : "badge-proceso" %>">
                                                <%= resuelta ? "Resuelto" : "En Proceso" %>
                                            </span>
                                        </td>
                                    </tr>
                                    <% } %>
                                </tbody>
                            </table>
                        </div>
                    <% } %>
                </div>

                <!-- Panel lateral -->
                <div class="right-panel">
                    <div>
                        <h3 class="section-title">Próxima Cita</h3>
                        <% if (proximaCita != null) {
                            boolean confirmada = proximaCita.getRespuesta() != null && !proximaCita.getRespuesta().trim().isEmpty();
                        %>
                            <div class="appointment-card">
                                <div class="appt-date"><%= proximaCita.getFecha() %></div>
                                <div class="appt-time">
                                    <%= proximaCita.getHora().toString().substring(0, 5) %> — <%= tipoProxima != null ? tipoProxima.getNombre() : "Cita" %>
                                </div>
                                <div class="appt-meta">
                                    <span class="badge-pill <%= confirmada ? "badge-resuelto" : "badge-proceso" %>">
                                        <%= confirmada ? "Confirmada" : "Pendiente de confirmación" %>
                                    </span>
                                </div>
                            </div>
                        <% } else { %>
                            <div class="appointment-card appointment-empty">
                                No tienes citas próximas agendadas.
                            </div>
                        <% } %>
                        <a href="<%= request.getContextPath() %>/CitasServlet" class="btn-block-outline">Ver mis citas &rarr;</a>
                    </div>

                    <div>
                        <h3 class="section-title">Avisos</h3>
                        <div class="notice-list">
                            <% if (pqrsEnProceso > 0) { %>
                                <div class="notice-card">
                                    <h4><%= pqrsEnProceso %> PQRS en proceso</h4>
                                    <p>Nuestro equipo de administración las está revisando.</p>
                                </div>
                            <% } %>
                            <% if (citasPendientes > 0) { %>
                                <div class="notice-card">
                                    <h4><%= citasPendientes %> cita(s) pendiente(s) de confirmación</h4>
                                    <p>Te avisaremos apenas administración las confirme.</p>
                                </div>
                            <% } %>
                            <% if (pqrsEnProceso == 0 && citasPendientes == 0) { %>
                                <div class="notice-card notice-ok">
                                    <h4>Estás al día</h4>
                                    <p>No tienes PQRS ni citas pendientes en este momento.</p>
                                </div>
                            <% } %>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <%@ include file="_dropdownScript.jspf" %>
</body>
</html>
