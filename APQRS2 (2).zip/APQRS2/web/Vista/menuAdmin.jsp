<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuario" %>
<%@ page import="Modelo.Pqrs" %>
<%@ page import="Modelo.Citas" %>
<%@ page import="Modelo.Apartamento" %>
<%@ page import="Modelo.TipoPqrs" %>
<%@ page import="Modelo.Tipocita" %>
<%@ page import="Controlador.PqrsDAO" %>
<%@ page import="Controlador.CitasDAO" %>
<%@ page import="Controlador.UsuarioDAO" %>
<%@ page import="Controlador.ApartamentoDAO" %>
<%@ page import="Controlador.BloqueDAO" %>
<%@ page import="Controlador.TipoPqrsDAO" %>
<%@ page import="Controlador.TipocitaDAO" %>
<%@ page import="Controlador.PlazoUtil" %>
<%@ page import="java.sql.Timestamp" %>
<%@ page import="java.time.LocalDate" %>
<%@ page import="java.time.LocalDateTime" %>
<%@ page import="java.time.temporal.ChronoUnit" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="java.util.Collections" %>
<%@ page import="java.util.Comparator" %>
<%@ page import="java.util.List" %>
<%!
    // Pequeño contenedor para unificar PQRS/Citas/Residentes en un solo feed de actividad
    class Evento {
        Timestamp momento;
        String titulo;
        String detalle;
        String tipo; // pqrs | cita | residente | resuelta
        Evento(Timestamp momento, String titulo, String detalle, String tipo) {
            this.momento = momento; this.titulo = titulo; this.detalle = detalle; this.tipo = tipo;
        }
    }

    String tiempoRelativo(Timestamp t) {
        if (t == null) return "";
        long minutos = ChronoUnit.MINUTES.between(t.toLocalDateTime(), LocalDateTime.now());
        if (minutos < 1) return "Hace instantes";
        if (minutos < 60) return "Hace " + minutos + " min";
        long horas = minutos / 60;
        if (horas < 24) return "Hace " + horas + (horas == 1 ? " hora" : " horas");
        long dias = horas / 24;
        return "Hace " + dias + (dias == 1 ? " día" : " días");
    }
%>
<%
    Usuario usuario = (Usuario) session.getAttribute("usuario");
    if (usuario == null || usuario.getIdRol() != 1) {
        response.sendRedirect(request.getContextPath() + "/Vista/login.jsp");
        return;
    }

    PqrsDAO pqrsDAO = new PqrsDAO();
    CitasDAO citasDAO = new CitasDAO();
    UsuarioDAO usuarioDAO = new UsuarioDAO();

    List<Pqrs> todasPqrs = pqrsDAO.listarTodos();
    List<Citas> todasCitas = citasDAO.listarTodos();
    List<Usuario> residentes = usuarioDAO.listarPorRol(2);

    // ---------- Métricas principales ----------
    int residentesActivos = residentes.size();

    int pqrsPendientes = 0;
    int pqrsVencidas = 0;
    TipoPqrsDAO tipoPqrsDAOAlertas = new TipoPqrsDAO();
    for (Pqrs p : todasPqrs) {
        if (p.getRespuesta() == null || p.getRespuesta().trim().isEmpty()) {
            pqrsPendientes++;
            if (p.getFechaRegistro() != null) {
                TipoPqrs tpAlerta = tipoPqrsDAOAlertas.consultar(p.getIdTipoPqrs());
                int diasAlerta = tpAlerta != null ? tpAlerta.getDiasPlazo() : 15;
                PlazoUtil.EstadoPlazo epAlerta = PlazoUtil.calcularEstado(p.getFechaRegistro().toLocalDateTime(), diasAlerta);
                if (epAlerta.vencida) pqrsVencidas++;
            }
        }
    }

    LocalDate hoy = LocalDate.now();
    int citasHoy = 0;
    for (Citas c : todasCitas) {
        if (c.getFecha() != null && c.getFecha().toLocalDate().equals(hoy)) citasHoy++;
    }

    java.util.Set<Integer> apartamentosOcupados = new java.util.HashSet<>();
    for (Usuario u : residentes) apartamentosOcupados.add(u.getIdApartamento());
    int totalApartamentos = new ApartamentoDAO().listarTodos().size();
    int porcentajeOcupacion = totalApartamentos > 0
            ? (int) Math.round((apartamentosOcupados.size() * 100.0) / totalApartamentos) : 0;

    // ---------- Métricas secundarias (con tendencia real semana/mes anterior) ----------
    LocalDateTime ahora = LocalDateTime.now();
    int pqrsSemanaActual = 0, pqrsSemanaAnterior = 0;
    for (Pqrs p : todasPqrs) {
        if (p.getFechaRegistro() == null) continue;
        long diasAtras = ChronoUnit.DAYS.between(p.getFechaRegistro().toLocalDateTime(), ahora);
        if (diasAtras >= 0 && diasAtras < 7) pqrsSemanaActual++;
        else if (diasAtras >= 7 && diasAtras < 14) pqrsSemanaAnterior++;
    }

    int citasMesActual = 0, citasMesAnterior = 0;
    for (Citas c : todasCitas) {
        if (c.getFecha() == null || c.getRespuesta() == null || c.getRespuesta().trim().isEmpty()) continue;
        LocalDate f = c.getFecha().toLocalDate();
        if (f.getMonthValue() == hoy.getMonthValue() && f.getYear() == hoy.getYear()) citasMesActual++;
        else if (f.getMonthValue() == hoy.minusMonths(1).getMonthValue() && f.getYear() == hoy.minusMonths(1).getYear()) citasMesAnterior++;
    }

    int pqrsResueltasTotal = 0;
    long sumaHorasRespuesta = 0;
    int cantidadConTiempo = 0;
    for (Pqrs p : todasPqrs) {
        boolean resuelta = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
        if (resuelta) {
            pqrsResueltasTotal++;
            if (p.getFechaRegistro() != null && p.getFechaRespuesta() != null) {
                long horas = ChronoUnit.HOURS.between(p.getFechaRegistro().toLocalDateTime(), p.getFechaRespuesta().toLocalDateTime());
                if (horas >= 0) { sumaHorasRespuesta += horas; cantidadConTiempo++; }
            }
        }
    }
    int tasaRespuesta = todasPqrs.isEmpty() ? 0 : (int) Math.round((pqrsResueltasTotal * 100.0) / todasPqrs.size());
    double promedioHoras = cantidadConTiempo > 0 ? (sumaHorasRespuesta / (double) cantidadConTiempo) : 0;

    // ---------- Actividad reciente (PQRS + Citas + Residentes nuevos) ----------
    TipoPqrsDAO tipoPqrsDAO = new TipoPqrsDAO();
    TipocitaDAO tipocitaDAO = new TipocitaDAO();
    ApartamentoDAO apartamentoDAO = new ApartamentoDAO();
    BloqueDAO bloqueDAO = new BloqueDAO();

    List<Evento> eventos = new ArrayList<Evento>();
    for (Pqrs p : todasPqrs) {
        boolean resuelta = p.getRespuesta() != null && !p.getRespuesta().trim().isEmpty();
        Usuario autor = usuarioDAO.consultar(p.getIdUsuario());
        String nombreAutor = autor != null ? (autor.getNombre() + " " + autor.getApellido()) : "Residente";
        if (resuelta) {
            eventos.add(new Evento(p.getFechaRespuesta(), "PQRS resuelta", p.getAsunto() + " · " + nombreAutor, "resuelta"));
        } else {
            eventos.add(new Evento(p.getFechaRegistro(), "Nueva PQRS registrada", p.getAsunto() + " · " + nombreAutor, "pqrs"));
        }
    }
    for (Citas c : todasCitas) {
        Usuario autor = usuarioDAO.consultar(c.getIdUsuario());
        String nombreAutor = autor != null ? (autor.getNombre() + " " + autor.getApellido()) : "Residente";
        boolean gestionada = c.getRespuesta() != null && !c.getRespuesta().trim().isEmpty();
        Timestamp momento = gestionada && c.getFechaRespuesta() != null ? c.getFechaRespuesta() : c.getFechaCreacion();
        String titulo = gestionada ? "Cita gestionada" : "Nueva cita solicitada";
        eventos.add(new Evento(momento, titulo, nombreAutor + " · " + c.getFecha(), "cita"));
    }
    for (Usuario r : residentes) {
        if (r.getFechaRegistro() == null) continue;
        Apartamento apto = apartamentoDAO.consultar(r.getIdApartamento());
        String unidad = apto != null ? ("Apto " + apto.getNumero()) : "";
        eventos.add(new Evento(r.getFechaRegistro(), "Nuevo residente registrado", r.getNombre() + " " + r.getApellido() + " · " + unidad, "residente"));
    }
    Collections.sort(eventos, new Comparator<Evento>() {
        public int compare(Evento a, Evento b) {
            if (a.momento == null || b.momento == null) return 0;
            return b.momento.compareTo(a.momento);
        }
    });
    List<Evento> eventosRecientes = eventos.size() > 4 ? eventos.subList(0, 4) : eventos;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel General - APQRS</title>
    <link rel="stylesheet" href="<%= request.getContextPath() %>/Vista/Css/DashAdmin.css">
    <link rel="stylesheet" href="<%= request.getContextPath() %>/Vista/Css/dropdowns.css">
</head>
<body>

    <!-- Lateral Bar -->
    <aside class="sidebar">
        <div>
            <div class="sidebar-header">
                <div class="brand-title">APQRS</div>
                <div class="brand-subtitle">Sistema de Gestión</div>
            </div>
            <ul class="sidebar-menu">
                <li class="active">
                    <a href="<%= request.getContextPath() %>/Vista/menuAdmin.jsp">
                        <svg viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                        Panel General
                    </a>
                </li>
                <li>
                    <a href="<%= request.getContextPath() %>/UsuarioAdminServlet">
                        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                        Usuarios y Unidades
                    </a>
                </li>
                <li>
                    <a href="<%= request.getContextPath() %>/PqrsServlet?vista=admin">
                        <svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                        Gestión PQRS
                    </a>
                </li>
                <li>
                    <a href="<%= request.getContextPath() %>/CitasServlet?accion=calendario">
                        <svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
                        Control de Citas
                    </a>
                </li>
            </ul>
        </div>
        <div class="sidebar-footer">
            Administrador
        </div>
    </aside>

    <!-- Main Section -->
    <div class="main-wrapper">
        <header class="top-header">
            <div class="user-welcome">
                <h2>Bienvenido, <%= usuario.getNombre() %> <%= usuario.getApellido() != null ? usuario.getApellido() : "" %></h2>
                <p>Administrador</p>
            </div>
            <div class="header-actions">
                <%
                    String ctx = request.getContextPath();
                    Usuario usuarioActual = usuario;
                    String rolLabel = "Administrador";
                    Controlador.NotificacionesDAO notificacionesDAO = new Controlador.NotificacionesDAO();
                    java.util.List<Modelo.Notificaciones> notificacionesAdmin = notificacionesDAO.listarParaAdmin(10);
                    int noLeidasAdmin = notificacionesDAO.contarNoLeidasParaAdmin();
                %>
                <%@ include file="_notifBell.jspf" %>
                <%@ include file="_avatarMenu.jspf" %>
            </div>
        </header>

        <main class="content">
            <div class="page-title">
                <h1>Panel General</h1>
                <p>Vista general del conjunto residencial</p>
            </div>

            <!-- Métricas Superiores -->
            <div class="metrics-primary">
                <div class="card">
                    <div class="card-stat">
                        <div class="stat-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
                        </div>
                        <div class="stat-value"><%= residentesActivos %></div>
                    </div>
                    <div class="stat-label">Residentes Activos</div>
                </div>

                <div class="card">
                    <div class="card-stat">
                        <div class="stat-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                        </div>
                        <div class="stat-value"><%= pqrsPendientes %></div>
                    </div>
                    <div class="stat-label">PQRS Pendientes</div>
                </div>

                <div class="card">
                    <div class="card-stat">
                        <div class="stat-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line></svg>
                        </div>
                        <div class="stat-value"><%= citasHoy %></div>
                    </div>
                    <div class="stat-label">Citas Programadas Hoy</div>
                </div>

                <div class="card">
                    <div class="card-stat">
                        <div class="stat-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path></svg>
                        </div>
                        <div class="stat-value"><%= porcentajeOcupacion %>%</div>
                    </div>
                    <div class="stat-label">Unidades Ocupadas</div>
                </div>
            </div>

            <!-- Métricas Secundarias -->
            <div class="metrics-secondary">
                <div class="card secondary-card">
                    <span class="sec-label">Nuevas PQRS (esta semana)</span>
                    <div class="sec-body">
                        <span class="sec-value"><%= pqrsSemanaActual %></span>
                        <% if (pqrsSemanaAnterior > 0) {
                            int variacion = (int) Math.round(((pqrsSemanaActual - pqrsSemanaAnterior) * 100.0) / pqrsSemanaAnterior);
                        %>
                            <span class="trend-badge <%= variacion >= 0 ? "trend-up" : "trend-down" %>">
                                <%= variacion >= 0 ? "↗ +" : "↘ " %><%= variacion %>%
                            </span>
                        <% } %>
                    </div>
                </div>

                <div class="card secondary-card">
                    <span class="sec-label">Citas atendidas (mes)</span>
                    <div class="sec-body">
                        <span class="sec-value"><%= citasMesActual %></span>
                        <% if (citasMesAnterior > 0) {
                            int variacion = (int) Math.round(((citasMesActual - citasMesAnterior) * 100.0) / citasMesAnterior);
                        %>
                            <span class="trend-badge <%= variacion >= 0 ? "trend-up" : "trend-down" %>">
                                <%= variacion >= 0 ? "↗ +" : "↘ " %><%= variacion %>%
                            </span>
                        <% } %>
                    </div>
                </div>

                <div class="card secondary-card">
                    <span class="sec-label">Tasa de respuesta PQRS</span>
                    <div class="sec-body">
                        <span class="sec-value"><%= tasaRespuesta %>%</span>
                    </div>
                </div>

                <div class="card secondary-card">
                    <span class="sec-label">Tiempo promedio respuesta</span>
                    <div class="sec-body">
                        <span class="sec-value"><%= cantidadConTiempo > 0 ? String.format("%.1fh", promedioHoras) : "-" %></span>
                    </div>
                </div>
            </div>

            <!-- Grid de Contenido -->
            <div class="dashboard-grid">
                <!-- Actividad Reciente -->
                <div>
                    <h3 class="section-title">Actividad Reciente</h3>
                    <div class="activity-card">
                        <% if (eventosRecientes.isEmpty()) { %>
                            <div class="activity-item"><div class="activity-details"><p>Aún no hay actividad registrada.</p></div></div>
                        <% } else {
                            for (Evento e : eventosRecientes) {
                                String iconClass = "icon-gray";
                                String pathIcon = "<path d=\"M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2\"></path>";
                                if ("pqrs".equals(e.tipo)) { iconClass = "icon-red"; pathIcon = "<path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"></path>"; }
                                else if ("resuelta".equals(e.tipo)) { iconClass = "icon-green"; pathIcon = "<polyline points=\"20 6 9 17 4 12\"></polyline>"; }
                                else if ("cita".equals(e.tipo)) { iconClass = "icon-blue"; pathIcon = "<rect x=\"3\" y=\"4\" width=\"18\" height=\"18\" rx=\"2\" ry=\"2\"></rect>"; }
                        %>
                        <div class="activity-item">
                            <div class="activity-left">
                                <div class="activity-icon <%= iconClass %>">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><%= pathIcon %></svg>
                                </div>
                                <div class="activity-details">
                                    <h4><%= e.titulo %></h4>
                                    <p><%= e.detalle %></p>
                                    <div class="activity-time"><%= tiempoRelativo(e.momento) %></div>
                                </div>
                            </div>
                        </div>
                        <% } } %>
                    </div>
                </div>

                <!-- Panel Lateral -->
                <div class="right-panel">
                    <div>
                        <h3 class="section-title">Alertas</h3>
                        <% if (pqrsPendientes == 0 && citasHoy == 0) { %>
                            <div class="alert-card">
                                <h4>Todo al día</h4>
                                <p>No hay PQRS pendientes ni citas para hoy.</p>
                            </div>
                        <% } else { %>
                            <% if (pqrsVencidas > 0) { %>
                                <div class="alert-card" style="border-left: 3px solid #dc2626;">
                                    <h4 style="color:#dc2626;"><%= pqrsVencidas %> PQRS vencida<%= pqrsVencidas == 1 ? "" : "s" %></h4>
                                    <p><a href="<%= request.getContextPath() %>/PqrsServlet?vista=admin" style="color:#dc2626;font-weight:600;">Ya pasaron su plazo de atención &rarr;</a></p>
                                </div>
                            <% } %>
                            <% if (pqrsPendientes > 0) { %>
                                <div class="alert-card">
                                    <h4><%= pqrsPendientes %> PQRS pendiente<%= pqrsPendientes == 1 ? "" : "s" %></h4>
                                    <p>Requieren respuesta de administración</p>
                                </div>
                            <% } %>
                            <% if (citasHoy > 0) { %>
                                <div class="alert-card">
                                    <h4><%= citasHoy %> cita<%= citasHoy == 1 ? "" : "s" %> para hoy</h4>
                                    <p>Revisa el cronograma</p>
                                </div>
                            <% } %>
                        <% } %>
                    </div>

                    <div>
                        <h3 class="section-title">Accesos Rápidos</h3>
                        <div class="quick-actions-card">
                            <a href="<%= request.getContextPath() %>/PqrsServlet?vista=admin" class="quick-btn">
                                <span>Gestionar PQRS</span>
                                <span>→</span>
                            </a>
                            <a href="<%= request.getContextPath() %>/UsuarioAdminServlet" class="quick-btn">
                                <span>Ver Usuarios</span>
                                <span>→</span>
                            </a>
                            <a href="<%= request.getContextPath() %>/CitasServlet?accion=calendario" class="quick-btn">
                                <span>Control de Citas</span>
                                <span>→</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <%@ include file="_dropdownScript.jspf" %>
</body>
</html>
