-- ============================================================
-- MIGRACIÓN: contraseñas cifradas
-- ============================================================
-- Ejecuta este script SOLO si tu base de datos "mydb" ya existía.
-- Si vas a correr BD.sql desde cero, NO lo necesitas.
--
-- Qué hace: amplía la columna `contrasena` para que quepa un hash
-- cifrado (antes solo cabían 45 caracteres de texto plano).
--
-- Las contraseñas existentes NO se pierden ni hay que hacer nada más:
-- la primera vez que cada usuario inicie sesión, el sistema detecta que
-- su contraseña todavía está en texto plano, la valida como antes, y la
-- vuelve a guardar ya cifrada automáticamente. No se requiere que nadie
-- vuelva a escribir su contraseña.
-- ============================================================

USE mydb;

ALTER TABLE Usuario
  MODIFY COLUMN contrasena VARCHAR(255) NOT NULL;
