-- ============================================================
-- MIGRACIÓN: notificaciones reales, asistencia y disponibilidad
-- ============================================================
-- Ejecuta este script SOLO si tu base de datos "mydb" ya existía.
-- Si vas a correr BD.sql desde cero, NO lo necesitas.
-- ============================================================

USE mydb;

-- 1) NOTIFICACIONES: permitir notificaciones sin cita/PQRS asociada,
--    y agregar a quién van dirigidas.
ALTER TABLE NOTIFICACIONES
  MODIFY COLUMN Citas_id_citas INT NULL,
  MODIFY COLUMN PQRS_id_pqrs INT NULL,
  ADD COLUMN Usuario_idUsuario INT NULL AFTER PQRS_id_pqrs;

ALTER TABLE NOTIFICACIONES
  ADD CONSTRAINT fk_NOTIFICACIONES_Usuario1
    FOREIGN KEY (Usuario_idUsuario)
    REFERENCES Usuario (idUsuario);

-- 2) Citas: registrar si el residente asistió o no a la cita.
ALTER TABLE Citas
  ADD COLUMN asistencia VARCHAR(20) NULL AFTER cancelada;

-- 3) Disponibilidad configurable del administrador (antes estaba fija
--    en el código: 08:00 a 17:00 cada 30 min).
CREATE TABLE IF NOT EXISTS ConfiguracionAgenda (
  id_configuracion INT NOT NULL AUTO_INCREMENT,
  hora_inicio TIME NOT NULL DEFAULT '08:00:00',
  hora_fin TIME NOT NULL DEFAULT '17:00:00',
  duracion_slot_minutos INT NOT NULL DEFAULT 30,
  dias_laborales VARCHAR(20) NOT NULL DEFAULT '1,2,3,4,5,6',
  PRIMARY KEY (id_configuracion)
) ENGINE=InnoDB;

INSERT INTO ConfiguracionAgenda (id_configuracion, hora_inicio, hora_fin, duracion_slot_minutos, dias_laborales)
SELECT 1, '08:00:00', '17:00:00', 30, '1,2,3,4,5,6'
WHERE NOT EXISTS (SELECT 1 FROM ConfiguracionAgenda WHERE id_configuracion = 1);
