-- ============================================================
-- MIGRACIÓN: agenda de citas gestionada por el administrador
-- ============================================================
-- Ejecuta este script SOLO si tu base de datos "mydb" ya existía
-- (creada con una versión anterior de BD.sql) y no quieres
-- borrarla. Si vas a correr BD.sql desde cero, NO necesitas esto.
--
-- Qué hace, sin borrar ni un solo dato:
--   1. Le agrega a Citas la posibilidad de quedar ligada a una PQRS
--      (para que al agendar una cita para responder una PQRS, quede
--      registrado ese vínculo).
--   2. Le agrega a Citas una bandera para saber si el residente ya
--      vio en su panel que le agendaron esa cita.
--   3. Permite que Seguimiento registre bitácora de citas generales
--      (sin PQRS asociada), no solo las relacionadas a una PQRS.
-- ============================================================

USE mydb;

ALTER TABLE Citas
  ADD COLUMN PQRS_id_pqrs INT NULL AFTER TIPOCITA_id_tipo_cita,
  ADD COLUMN notificada_residente TINYINT(1) NOT NULL DEFAULT 0 AFTER PQRS_id_pqrs;

ALTER TABLE Citas
  ADD CONSTRAINT fk_Citas_PQRS1
    FOREIGN KEY (PQRS_id_pqrs)
    REFERENCES PQRS (id_pqrs);

ALTER TABLE Seguimiento
  MODIFY COLUMN PQRS_id_pqrs INT NULL;

-- Las citas que ya existían se dan por "notificadas" para que no le
-- aparezca al residente una alerta retroactiva de citas viejas.
UPDATE Citas SET notificada_residente = 1;
